(() => {
  'use strict';

  const state = {
    bridge: null,
    page: 'home',
    games: [],
    catalog: [],
    catalogIndex: new Map(),
    catalogLocalSearchTimer: null,
    catalogSearchTimer: null,
    catalogSearchSequence: 0,
    catalogSearchQuery: '',
    catalogMode: 'discovery',
    catalogPage: 1,
    catalogPageSize: 8,
    catalogPages: 1,
    catalogDiscoveryCache: new Map(),
    catalogDiscoveryBusy: false,
    catalogErrorToastAt: 0,
    discoverySection: 'browse',
    discoveryRanking: {},
    catalogInsights: null,
    catalogInsightsBusy: false,
    catalogInsightsLoadedAt: 0,
    catalogFilters: new Set(),
    catalogSort: 'relevance',
    onlineFixCatalogTotal: 0,
    oldGames: [],
    oldGamesLoaded: false,
    oldGamesBusy: false,
    oldGamesSequence: 0,
    oldGamesSearchTimer: null,
    oldGamesPage: 1,
    oldGamesPages: 1,
    oldGamesPageSize: 24,
    oldGamesQuery: '',
    oldGamesSort: 'top_downloads',
    oldGamesImagesOnly: false,
    oldGamesGenre: '',
    oldGamesYear: '',
    oldGamesFiltersReady: false,
    oldGamesStatus: null,
    tvChannels: [],
    tvCountries: [],
    tvGroups: [],
    tvEpgAvailable: false,
    tvVisibleLimit: 80,
    tvRenderKey: '',
    tvLoaded: false,
    tvBusy: false,
    tvCountry: 'pl',
    tvGroup: 'all',
    tvQuery: '',
    tvSelected: null,
    tvLiveChannel: null,
    tvGuideOpen: false,
    tvGuideBusy: false,
    tvGuideSequence: 0,
    tvGuideChannelId: '',
    tvGuideItems: [],
    tvGuideError: '',
    tvHls: null,
    tvDash: null,
    tvMpegTs: null,
    tvPlaybackSequence: 0,
    tvHealthTimer: null,
    tvLastPlaybackTime: 0,
    tvLastPlaybackProgressAt: 0,
    tvPlaybackHealthySince: 0,
    tvRecoveryPending: false,
    tvRecoveryCount: 0,
    tvNetworkRetries: 0,
    tvMediaRecovered: false,
    tvNativeFallbackUsed: false,
    tvRefreshedAt: 0,
    tvRemoteSequence: 0,
    tvConfigTimer: null,
    tvConfigBusy: false,
    selectedOldGame: null,
    oldGameDetailsSequence: 0,
    oldGameInstallTimer: null,
    oldGameInstallPollSequence: 0,
    oldGameInstallNotified: '',
    oldGameInstallStatus: null,
    selectedCatalogApp: null,
    selectedStorefrontApp: null,
    storefrontSequence: 0,
    storefrontCache: new Map(),
    installQueue: [],
    hubcap: { configured: false },
    cloudProvider: { connected: false, provider: 'gdrive' },
    cloudQuota: { state: 'disconnected' },
    cloudQuotaWarningShown: false,
    hubcapHealthTimer: null,
    settings: { theme: 'copper', language: 'pl', confirm_removal: true, show_advanced: false, backend_mode: 'auto', cloud_onboarding_seen: false, automatic_updates: true },
    pendingRemoval: null,
    selectedGameDetails: null,
    gameDrawerSequence: 0,
    onlineFixPlan: null,
    onlineFixPagePlan: null,
    pendingFixLocation: null,
    workshopStatus: null,
    workshopPreferredAppId: '',
    workshopPollTimer: null,
    workshopPollAppId: '',
    workshopPollBusy: false,
    workshopPollGeneration: 0,
    workshopPollCounts: '',
    cloudRedirectBusy: false,
    diagnostics: null,
    license: null,
    applicationUpdate: null,
    applicationUpdatePrompted: false,
    backendUpdate: null,
    watcherNotifications: [],
    watcherNotificationIds: new Set(),
    watcherNotificationsReady: false,
    watcherNotificationsBusy: false,
    watcherNotificationsTimer: null,
    pendingOnlineFixOffer: null,
    steamAccounts: null,
    libraryProfile: null,
    libraryWorkspace: { favorites: [], profiles: {}, activity: [] },
    libraryProfilePrompted: false,
    libraryProfileSyncTimer: null,
    initialized: false,
  };

  const pageMeta = {
    home: ['START', 'Dzień dobry'],
    add: ['DODAJ GRĘ', 'Katalog gier'],
    oldgames: ['STARE GRY', 'Archiwum klasyków'],
    tv: ['TELEWIZJA', 'Kanały na żywo'],
    manage: ['MOJE GRY', 'Twoja biblioteka'],
    mode: ['SILNIK', 'Stan i aktualizacje'],
    onlinefix: ['MULTIPLAYER', 'Graj ze znajomymi'],
    workshop: ['MODY', 'Workshop'],
    cloudsaves: ['ZAPISY', 'Google Drive'],
    diagnostics: ['DIAGNOSTYKA', 'Sprawdź i napraw'],
    plugin: ['ZAAWANSOWANE', 'Szczegóły silnika'],
    license: ['LICENCJA', 'Dostęp do programu'],
    limits: ['LIMITY', 'Użycie providerów'],
    settings: ['USTAWIENIA', 'Preferencje'],
  };

  function parseJson(raw, fallback = {}) {
    try { return JSON.parse(raw); } catch (_) { return fallback; }
  }

  function tr(value) {
    return window.KZT_I18N ? window.KZT_I18N.translate(value) : String(value ?? '');
  }

  function call(method, ...args) {
    if (!state.bridge || typeof state.bridge[method] !== 'function') {
      return Promise.reject(new Error(`Metoda aplikacji jest niedostępna: ${method}`));
    }
    try {
      return Promise.resolve(state.bridge[method](...args)).then(raw => {
        if (typeof raw === 'string' && !method.includes('license')) {
          const payload = parseJson(raw, null);
          if (payload && payload.license_required && payload.license) renderLicense(payload.license, true);
        }
        return raw;
      });
    }
    catch (error) { return Promise.reject(error); }
  }

  function escapeHtml(value) {
    const node = document.createElement('span');
    node.textContent = String(value ?? '');
    return node.innerHTML;
  }

  function toast(kind, title, message, warnings = []) {
    const host = document.getElementById('toasts');
    const node = document.createElement('div');
    node.className = `toast ${kind}`;
    node.innerHTML = `<strong>${escapeHtml(tr(title))}</strong><span>${escapeHtml(tr(message || ''))}</span>`;
    if (warnings.length) {
      const list = document.createElement('ul');
      warnings.slice(0, 3).forEach(warning => {
        const item = document.createElement('li');
        item.textContent = tr(warning);
        list.appendChild(item);
      });
      node.appendChild(list);
    }
    host.appendChild(node);
    setTimeout(() => node.remove(), 5200);
  }

  function watcherNotificationText(item, field) {
    const english = state.settings.language === 'en';
    return String(
      english
        ? (item[`${field}_en`] || item[field] || '')
        : (item[field] || item[`${field}_en`] || '')
    );
  }

  function formatWatcherNotificationTime(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return '';
    const locale = state.settings.language === 'en' ? 'en-US' : 'pl-PL';
    const elapsed = Date.now() - date.getTime();
    if (elapsed >= 0 && elapsed < 60_000) return tr('Przed chwilą');
    if (elapsed >= 0 && elapsed < 60 * 60_000) {
      const minutes = Math.max(1, Math.floor(elapsed / 60_000));
      return state.settings.language === 'en'
        ? `${minutes} min ago`
        : `${minutes} min temu`;
    }
    return date.toLocaleString(locale, {
      day: '2-digit',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  function watcherNotificationIcon(category) {
    return {
      onlinefix: 'online',
      workshop: 'workshop',
      update: 'refresh',
      games: 'library',
      cloud: 'cloud',
    }[category] || 'bell';
  }

  function renderWatcherNotifications() {
    const list = document.getElementById('notification-list');
    const empty = document.getElementById('notification-empty');
    const badge = document.getElementById('notification-badge');
    const unread = state.watcherNotifications.filter(item => !item.read).length;
    badge.hidden = unread === 0;
    badge.textContent = unread > 99 ? '99+' : String(unread);
    list.innerHTML = '';
    empty.classList.toggle('visible', state.watcherNotifications.length === 0);
    state.watcherNotifications.forEach(item => {
      const node = document.createElement('article');
      node.className = `notification-item ${escapeHtml(item.level || 'info')}${item.read ? '' : ' unread'}`;
      node.dataset.notificationId = item.id || '';
      node.dataset.notificationCategory = item.category || '';
      node.innerHTML = `
        <span class="notification-item-icon"><svg><use href="assets/icons.svg#${watcherNotificationIcon(item.category)}"></use></svg></span>
        <div class="notification-item-copy">
          <strong>${escapeHtml(watcherNotificationText(item, 'title'))}</strong>
          <p>${escapeHtml(watcherNotificationText(item, 'message'))}</p>
          <time>${escapeHtml(formatWatcherNotificationTime(item.created_at))}</time>
        </div>`;
      list.appendChild(node);
    });
  }

  async function loadWatcherNotifications(announce = false) {
    if (state.watcherNotificationsBusy) return;
    state.watcherNotificationsBusy = true;
    try {
      const result = parseJson(await call('get_watcher_notifications', 80), { items: [] });
      const items = Array.isArray(result.items) ? result.items : [];
      const unseen = items.filter(item => !item.read && !state.watcherNotificationIds.has(item.id));
      state.watcherNotifications = items;
      items.forEach(item => state.watcherNotificationIds.add(item.id));
      renderWatcherNotifications();
      if (announce && state.watcherNotificationsReady && unseen.length) {
        const latest = unseen[0];
        toast(
          latest.level === 'error' ? 'error' : latest.level === 'success' ? 'success' : 'info',
          watcherNotificationText(latest, 'title'),
          watcherNotificationText(latest, 'message'),
        );
      }
      state.watcherNotificationsReady = true;
    } catch (_) {
      // The inbox is an observability layer; its polling cannot interrupt the UI.
    } finally {
      state.watcherNotificationsBusy = false;
    }
  }

  function startWatcherNotificationPolling() {
    clearInterval(state.watcherNotificationsTimer);
    state.watcherNotificationsTimer = setInterval(
      () => void loadWatcherNotifications(true),
      7000,
    );
  }

  async function markWatcherNotificationsRead() {
    const unreadIds = state.watcherNotifications
      .filter(item => !item.read)
      .map(item => item.id)
      .filter(Boolean);
    if (!unreadIds.length) return;
    await call('mark_watcher_notifications_read', JSON.stringify(unreadIds));
    state.watcherNotifications.forEach(item => { item.read = true; });
    renderWatcherNotifications();
  }

  async function clearWatcherNotifications() {
    await call('clear_watcher_notifications');
    state.watcherNotifications = [];
    state.watcherNotificationIds.clear();
    renderWatcherNotifications();
  }

  function toggleWatcherNotifications(force) {
    const center = document.getElementById('notification-center');
    const button = document.getElementById('notification-bell');
    const open = typeof force === 'boolean' ? force : !center.classList.contains('open');
    center.classList.toggle('open', open);
    button.setAttribute('aria-expanded', String(open));
    document.getElementById('notification-panel').setAttribute('aria-hidden', String(!open));
    if (open) void loadWatcherNotifications(false);
  }

  function openOnlineFixAutomationOffer(app) {
    if (!app?.onlinefix_available) return;
    state.pendingOnlineFixOffer = { ...app };
    document.getElementById('onlinefix-auto-game').textContent = app.name || `App ${app.app_id}`;
    document.getElementById('onlinefix-auto-modal').classList.add('visible');
  }

  async function resolveOnlineFixForApp(app) {
    if (app?.onlinefix_available) return app;
    if (!app?.app_id || !app?.name) return app;
    try {
      const response = parseJson(
        await call(
          'check_online_fix_availability',
          JSON.stringify([{ app_id: app.app_id, name: app.name }]),
        ),
        { items: [] },
      );
      const match = (response.items || [])[0];
      if (match) {
        Object.assign(app, {
          onlinefix_available: Boolean(match.available),
          onlinefix_title: match.title || '',
          onlinefix_url: match.url || '',
        });
      }
    } catch (_) {
      // A provider outage must not turn a successful Lua import into a failure.
    }
    return app;
  }

  function closeOnlineFixAutomationOffer() {
    state.pendingOnlineFixOffer = null;
    document.getElementById('onlinefix-auto-modal').classList.remove('visible');
  }

  async function acceptOnlineFixAutomationOffer() {
    const app = state.pendingOnlineFixOffer;
    if (!app) return;
    const button = document.getElementById('onlinefix-auto-accept');
    const original = button.innerHTML;
    button.disabled = true;
    button.textContent = tr('Otwieranie Steam…');
    try {
      const result = parseJson(
        await call('schedule_onlinefix_install', JSON.stringify(app)),
        {},
      );
      if (!result.success) {
        toast('error', 'Nie uruchomiono automatycznej instalacji', result.message || '');
        return;
      }
      closeOnlineFixAutomationOffer();
      toast('success', 'Watcher Online‑Fix jest aktywny', result.message || '');
      await loadWatcherNotifications(false);
      toggleWatcherNotifications(true);
    } catch (error) {
      toast('error', 'Nie uruchomiono automatycznej instalacji', error.message || String(error));
    } finally {
      button.disabled = false;
      button.innerHTML = original;
    }
  }

  const tvGroupTranslations = {
    animation: ['Animacja', 'Animation'],
    business: ['Biznes', 'Business'],
    classic: ['Klasyka', 'Classic'],
    comedy: ['Komedia', 'Comedy'],
    cooking: ['Kuchnia', 'Cooking'],
    culture: ['Kultura', 'Culture'],
    documentary: ['Dokumentalne', 'Documentary'],
    education: ['Edukacja', 'Education'],
    entertainment: ['Rozrywka', 'Entertainment'],
    family: ['Rodzinne', 'Family'],
    general: ['Ogólne', 'General'],
    kids: ['Dla dzieci', 'Kids'],
    lifestyle: ['Styl życia', 'Lifestyle'],
    movies: ['Filmy', 'Movies'],
    music: ['Muzyka', 'Music'],
    news: ['Informacyjne', 'News'],
    religious: ['Religijne', 'Religious'],
    science: ['Nauka', 'Science'],
    series: ['Seriale', 'Series'],
    shop: ['Zakupy', 'Shopping'],
    sports: ['Sport', 'Sports'],
    travel: ['Podróże', 'Travel'],
    weather: ['Pogoda', 'Weather'],
    'pozostałe': ['Pozostałe', 'Other'],
  };

  function tvLocale() {
    return state.settings.language === 'en' ? 'en-US' : 'pl-PL';
  }

  function tvGroupLabel(value) {
    const text = String(value || 'Pozostałe');
    const translated = tvGroupTranslations[text.toLocaleLowerCase()];
    return translated ? translated[state.settings.language === 'en' ? 1 : 0] : text;
  }

  function tvCountryLabel(value) {
    return tr(String(value || 'Inne'));
  }

  function normalizeTvText(value) {
    return String(value || '')
      .normalize('NFKD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLocaleLowerCase();
  }

  function tvInitials(name) {
    const words = String(name || 'TV').match(/[\p{L}\p{N}]+/gu) || ['TV'];
    return words.slice(0, 2).map(word => word[0]).join('').toLocaleUpperCase();
  }

  function mountTvLogo(host, channel) {
    host.replaceChildren();
    if (!channel?.logo) {
      host.textContent = tvInitials(channel?.name);
      return;
    }
    const image = document.createElement('img');
    image.src = channel.logo;
    image.alt = '';
    image.loading = 'lazy';
    image.decoding = 'async';
    image.addEventListener('error', () => {
      host.replaceChildren();
      host.textContent = tvInitials(channel?.name);
    }, { once: true });
    host.appendChild(image);
  }

  function formatTvUpdated(value) {
    const date = new Date(Number(value || 0) * 1000);
    if (Number.isNaN(date.getTime()) || !value) return '—';
    return date.toLocaleTimeString(tvLocale(), { hour: '2-digit', minute: '2-digit' });
  }

  function setTvPlayerState(kind, message = '') {
    const empty = document.getElementById('tv-player-empty');
    const loading = document.getElementById('tv-player-loading');
    const error = document.getElementById('tv-player-error');
    empty.hidden = kind !== 'empty';
    loading.hidden = kind !== 'loading';
    error.hidden = kind !== 'error';
    if (kind === 'loading' && message) {
      document.getElementById('tv-loading-name').textContent = message;
    }
    if (kind === 'error' && message) {
      document.getElementById('tv-player-error-copy').textContent = message;
    }
  }

  function formatTvProgrammeTime(value) {
    const date = new Date(Number(value || 0) * 1000);
    if (Number.isNaN(date.getTime())) return '—';
    return date.toLocaleTimeString(tvLocale(), { hour: '2-digit', minute: '2-digit' });
  }

  function formatTvProgrammeDay(value) {
    const date = new Date(Number(value || 0) * 1000);
    if (Number.isNaN(date.getTime())) return tr('Program TV');
    return date.toLocaleDateString(tvLocale(), { weekday: 'long', day: 'numeric', month: 'long' });
  }

  function setTvGuideOpen(open) {
    state.tvGuideOpen = Boolean(open);
    const panel = document.getElementById('tv-guide-panel');
    const toggle = document.getElementById('tv-guide-toggle');
    panel.hidden = !state.tvGuideOpen;
    toggle.classList.toggle('active', state.tvGuideOpen);
    toggle.setAttribute('aria-expanded', String(state.tvGuideOpen));
    if (state.tvGuideOpen && state.tvLiveChannel && state.tvGuideChannelId !== state.tvLiveChannel.id) {
      void loadTvGuide(state.tvLiveChannel);
    }
  }

  function resetTvGuide({ close = false } = {}) {
    state.tvGuideSequence += 1;
    state.tvGuideBusy = false;
    state.tvGuideChannelId = '';
    state.tvGuideItems = [];
    state.tvGuideError = '';
    const toggle = document.getElementById('tv-guide-toggle');
    toggle.disabled = !state.tvLiveChannel;
    document.getElementById('tv-guide-toggle-status').textContent = state.tvEpgAvailable
      ? tr('RAMÓWKA')
      : tr('SPRAWDŹ EPG');
    if (close) setTvGuideOpen(false);
  }

  function updateTvCurrentProgramme() {
    const channel = state.tvLiveChannel;
    if (!channel || state.tvSelected?.is_catchup) return;
    const now = Math.floor(Date.now() / 1000);
    const current = state.tvGuideItems.find(item => Number(item.start) <= now && Number(item.stop) > now);
    const group = `${tvGroupLabel(channel.group)} · ${tvCountryLabel(channel.country_name)}`;
    document.getElementById('tv-now-group').textContent = current?.title
      ? `${current.title} · ${group}`
      : group;
  }

  function renderTvGuide() {
    const status = document.getElementById('tv-guide-status');
    const list = document.getElementById('tv-guide-list');
    const channel = state.tvLiveChannel;
    document.getElementById('tv-guide-channel').textContent = channel?.name || tr('Wybierz kanał');
    list.replaceChildren();
    if (state.tvGuideBusy || state.tvGuideError || !state.tvGuideItems.length) {
      status.hidden = false;
      const title = status.querySelector('strong');
      const copy = status.querySelector('small');
      if (state.tvGuideBusy) {
        title.textContent = tr('Ładowanie programu TV');
        copy.textContent = tr('Dopasowujemy kanał do przewodnika XMLTV.');
      } else if (state.tvGuideError) {
        title.textContent = tr('Brak programu dla tego kanału');
        copy.textContent = state.tvGuideError;
      } else {
        title.textContent = tr('Brak programu dla tego kanału');
        copy.textContent = tr('Przewodnik nie zawiera pasującej ramówki.');
      }
      return;
    }
    status.hidden = true;
    let currentDay = '';
    const fragment = document.createDocumentFragment();
    state.tvGuideItems.forEach(programme => {
      const day = new Date(Number(programme.start || 0) * 1000).toLocaleDateString('en-CA');
      if (day !== currentDay) {
        currentDay = day;
        const dayNode = document.createElement('div');
        dayNode.className = 'tv-guide-day';
        dayNode.textContent = formatTvProgrammeDay(programme.start);
        fragment.appendChild(dayNode);
      }
      const item = document.createElement(programme.playable ? 'button' : 'article');
      if (programme.playable) item.type = 'button';
      item.className = `tv-programme ${programme.state || ''}${programme.playable ? ' playable' : ''}`;
      const time = document.createElement('span');
      time.className = 'tv-programme-time';
      const start = document.createElement('strong');
      start.textContent = formatTvProgrammeTime(programme.start);
      const stop = document.createElement('span');
      stop.textContent = formatTvProgrammeTime(programme.stop);
      time.append(start, stop);
      const copy = document.createElement('span');
      copy.className = 'tv-programme-copy';
      const title = document.createElement('strong');
      title.textContent = programme.title || tr('Program TV');
      const subtitle = document.createElement('small');
      subtitle.textContent = programme.subtitle || programme.category || programme.description || tr('Brak opisu');
      copy.append(title, subtitle);
      const action = document.createElement('span');
      action.className = 'tv-programme-action';
      action.textContent = programme.playable
        ? (programme.state === 'current' ? tr('OD POCZĄTKU') : tr('OGLĄDAJ'))
        : (programme.state === 'current' ? tr('TERAZ') : programme.state === 'future' ? tr('WKRÓTCE') : tr('BRAK ARCHIWUM'));
      item.append(time, copy, action);
      if (programme.playable) item.addEventListener('click', () => playTvCatchup(programme));
      fragment.appendChild(item);
    });
    list.appendChild(fragment);
  }

  async function loadTvGuide(channel, force = false) {
    if (!channel?.id) return;
    const sequence = ++state.tvGuideSequence;
    state.tvGuideBusy = true;
    state.tvGuideError = '';
    state.tvGuideItems = [];
    state.tvGuideChannelId = '';
    document.getElementById('tv-guide-toggle').disabled = false;
    document.getElementById('tv-guide-toggle-status').textContent = tr('ŁADOWANIE');
    renderTvGuide();
    try {
      const result = parseJson(await call('get_tv_guide', String(channel.id), Boolean(force)), {});
      if (sequence !== state.tvGuideSequence || state.tvLiveChannel?.id !== channel.id) return;
      state.tvGuideChannelId = channel.id;
      state.tvGuideItems = Array.isArray(result.programmes) ? result.programmes : [];
      state.tvGuideError = result.success ? '' : (result.message || tr('Nie udało się pobrać programu TV'));
      document.getElementById('tv-guide-toggle-status').textContent = result.catchup_available
        ? tr('ARCHIWUM')
        : tr('RAMÓWKA');
      updateTvCurrentProgramme();
    } catch (error) {
      if (sequence !== state.tvGuideSequence) return;
      state.tvGuideError = error.message || String(error);
      document.getElementById('tv-guide-toggle-status').textContent = tr('BRAK EPG');
    } finally {
      if (sequence === state.tvGuideSequence) {
        state.tvGuideBusy = false;
        renderTvGuide();
      }
    }
  }

  async function playTvCatchup(programme) {
    const channel = state.tvLiveChannel;
    if (!channel || !programme?.playable) return;
    const sequence = state.tvGuideSequence;
    try {
      const result = parseJson(
        await call(
          'get_tv_catchup',
          String(channel.id),
          Number(programme.start || 0),
          Number(programme.stop || 0),
          String(programme.catchup_id || ''),
        ),
        {},
      );
      if (!result.success) throw new Error(result.message || tr('Nagranie jest niedostępne'));
      if (sequence !== state.tvGuideSequence || state.tvLiveChannel?.id !== channel.id) return;
      const syntheticUrl = result.stream_type === 'hls'
        ? 'https://catchup.invalid/archive.m3u8'
        : result.stream_type === 'dash'
          ? 'https://catchup.invalid/archive.mpd'
          : 'https://catchup.invalid/archive.ts';
      selectTvChannel({
        ...channel,
        stream_url: syntheticUrl,
        playback_url: result.playback_url,
        stream_type: result.stream_type,
        is_catchup: true,
        programme_title: programme.title || tr('Program TV'),
      }, { catchup: true });
      setTvGuideOpen(false);
    } catch (error) {
      toast('error', tr('Archiwum TV'), error.message || String(error));
    }
  }

  function stopTvHealthMonitor() {
    if (state.tvHealthTimer) clearInterval(state.tvHealthTimer);
    state.tvHealthTimer = null;
    state.tvLastPlaybackTime = 0;
    state.tvLastPlaybackProgressAt = 0;
    state.tvPlaybackHealthySince = 0;
    state.tvRecoveryPending = false;
  }

  function recoverTvPlayback(channel, sequence) {
    if (!channel || sequence !== state.tvPlaybackSequence || state.tvRecoveryPending) return;
    if (state.tvRecoveryCount >= 8) {
      showTvPlaybackError(tr('Transmisja wielokrotnie utraciła połączenie. Spróbuj ponownie za chwilę.'));
      return;
    }
    state.tvRecoveryPending = true;
    setTvPlayerState('loading', tr('Odnawianie transmisji…'));
    const delay = Math.min(1600, 250 + state.tvRecoveryCount * 180);
    setTimeout(() => {
      if (sequence !== state.tvPlaybackSequence || state.tvSelected !== channel) return;
      state.tvRecoveryPending = false;
      selectTvChannel(channel, { recovery: true });
    }, delay);
  }

  function startTvHealthMonitor(channel, sequence) {
    stopTvHealthMonitor();
    const video = document.getElementById('tv-video');
    const now = performance.now();
    state.tvLastPlaybackTime = Number(video.currentTime) || 0;
    state.tvLastPlaybackProgressAt = now;
    state.tvPlaybackHealthySince = now;
    const isHls = channel.stream_type !== 'mpegts'
      && /\.m3u8?(?:$|[?#])/i.test(channel.stream_url || '');
    // Classic IPTV HLS commonly publishes a new segment only every 5-12 seconds.
    // A short generic watchdog used to tear down healthy streams between segments.
    const stallThreshold = isHls ? 35000 : 22000;
    state.tvHealthTimer = setInterval(() => {
      if (sequence !== state.tvPlaybackSequence || state.tvSelected !== channel) {
        stopTvHealthMonitor();
        return;
      }
      if (video.paused || video.seeking || document.hidden) {
        state.tvLastPlaybackTime = Number(video.currentTime) || state.tvLastPlaybackTime;
        state.tvLastPlaybackProgressAt = performance.now();
        return;
      }
      const tick = performance.now();
      const current = Number(video.currentTime) || 0;
      if (current > state.tvLastPlaybackTime + 0.08) {
        state.tvLastPlaybackTime = current;
        state.tvLastPlaybackProgressAt = tick;
        if (tick - state.tvPlaybackHealthySince > 15000) state.tvRecoveryCount = 0;
        return;
      }
      if (tick - state.tvLastPlaybackProgressAt > stallThreshold) recoverTvPlayback(channel, sequence);
    }, 900);
  }

  function clearTvMedia({ clearSelection = false } = {}) {
    state.tvPlaybackSequence += 1;
    stopTvHealthMonitor();
    if (clearSelection) {
      state.tvSelected = null;
      state.tvLiveChannel = null;
      resetTvGuide({ close: true });
    }
    if (state.tvHls) {
      try { state.tvHls.destroy(); } catch (_) { /* no-op */ }
      state.tvHls = null;
    }
    if (state.tvDash) {
      try { state.tvDash.reset(); } catch (_) { /* no-op */ }
      state.tvDash = null;
    }
    if (state.tvMpegTs) {
      try { state.tvMpegTs.pause(); } catch (_) { /* no-op */ }
      try { state.tvMpegTs.unload(); } catch (_) { /* no-op */ }
      try { state.tvMpegTs.detachMediaElement(); } catch (_) { /* no-op */ }
      try { state.tvMpegTs.destroy(); } catch (_) { /* no-op */ }
      state.tvMpegTs = null;
    }
    const video = document.getElementById('tv-video');
    try { video.pause(); } catch (_) { /* no-op */ }
    video.removeAttribute('src');
    video.load();
    document.getElementById('tv-video-shell').classList.remove('playing');
    document.getElementById('tv-live-corner').hidden = true;
    if (clearSelection) {
      document.getElementById('tv-now-name').textContent = tr('Nie wybrano kanału');
      document.getElementById('tv-now-group').textContent = tr('Wybierz kanał po prawej stronie');
      mountTvLogo(document.getElementById('tv-now-logo'), null);
      setTvPlayerState('empty');
      renderTvChannels();
    }
  }

  function showTvPlaybackError(message = '') {
    document.getElementById('tv-video-shell').classList.remove('playing');
    document.getElementById('tv-live-corner').hidden = true;
    setTvPlayerState(
      'error',
      message || tr('Spróbuj ponownie lub wybierz inny kanał.'),
    );
  }

  function attemptTvPlay(sequence) {
    if (sequence !== state.tvPlaybackSequence) return;
    const video = document.getElementById('tv-video');
    const playback = video.play();
    if (playback && typeof playback.catch === 'function') {
      playback.catch(() => {
        if (sequence !== state.tvPlaybackSequence) return;
        setTvPlayerState('none');
      });
    }
  }

  function playTvNative(channel, sequence) {
    const video = document.getElementById('tv-video');
    video.src = channel.playback_url || channel.stream_url;
    video.load();
    attemptTvPlay(sequence);
  }

  function playTvMpegTs(channel, sequence) {
    const video = document.getElementById('tv-video');
    const engine = window.mpegts;
    if (!engine?.isSupported?.()) {
      showTvPlaybackError(tr('Ten format transmisji nie jest obsĹ‚ugiwany przez odtwarzacz.'));
      return;
    }
    try {
      const baseUrl = channel.playback_url || channel.stream_url;
      const playbackUrl = `${baseUrl}${baseUrl.includes('?') ? '&' : '?'}_kzt_player=${Date.now()}-${sequence}`;
      const player = engine.createPlayer(
        {
          type: 'mpegts',
          isLive: true,
          url: playbackUrl,
        },
        {
          // mpegts.js documents worker mode as unstable.  In a packaged
          // WebView it can also fail to load its worker from file://.
          enableWorker: false,
          // A small stash absorbs normal IPTV jitter.  Disabling it entirely
          // caused healthy direct TS streams to stop every few dozen seconds.
          enableStashBuffer: true,
          stashInitialSize: 384 * 1024,
          lazyLoad: false,
          liveSync: true,
          liveBufferLatencyChasing: true,
          liveBufferLatencyMaxLatency: 4,
          liveBufferLatencyMinRemain: 1.5,
          autoCleanupSourceBuffer: true,
          autoCleanupMaxBackwardDuration: 60,
          autoCleanupMinBackwardDuration: 30,
        },
      );
      state.tvMpegTs = player;
      player.on(engine.Events.ERROR, () => {
        if (sequence !== state.tvPlaybackSequence || state.tvMpegTs !== player) return;
        // Do not throw away buffered video on a transient upstream hiccup.
        // The health monitor will reconnect only if playback really stalls.
        setTimeout(() => {
          if (sequence !== state.tvPlaybackSequence || state.tvMpegTs !== player) return;
          if (video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA) {
            recoverTvPlayback(channel, sequence);
          }
        }, 1800);
      });
      if (engine.Events.LOADING_COMPLETE) {
        player.on(engine.Events.LOADING_COMPLETE, () => {
          if (sequence !== state.tvPlaybackSequence || state.tvMpegTs !== player) return;
          recoverTvPlayback(channel, sequence);
        });
      }
      player.on(engine.Events.MEDIA_INFO, () => {
        if (sequence !== state.tvPlaybackSequence || state.tvMpegTs !== player) return;
        setTvPlayerState('none');
        attemptTvPlay(sequence);
      });
      player.attachMediaElement(video);
      player.load();
      attemptTvPlay(sequence);
    } catch (_) {
      if (state.tvMpegTs) {
        try { state.tvMpegTs.destroy(); } catch (_) { /* no-op */ }
        state.tvMpegTs = null;
      }
      showTvPlaybackError(tr('Nie udaĹ‚o siÄ™ uruchomiÄ‡ transmisji MPEG-TS.'));
    }
  }

  async function selectTvChannel(channel, options = {}) {
    if (!channel?.stream_url) return;
    const recovery = Boolean(options.recovery);
    const catchup = Boolean(options.catchup || channel.is_catchup);
    clearTvMedia();
    state.tvSelected = channel;
    if (!recovery && !catchup) {
      state.tvLiveChannel = channel;
      resetTvGuide();
    }
    state.tvRecoveryCount = recovery ? state.tvRecoveryCount + 1 : 0;
    state.tvNetworkRetries = 0;
    state.tvMediaRecovered = false;
    state.tvNativeFallbackUsed = false;
    const sequence = state.tvPlaybackSequence;
    document.getElementById('tv-now-name').textContent = catchup
      ? (channel.programme_title || channel.name)
      : channel.name;
    document.getElementById('tv-now-group').textContent = catchup
      ? `${tr('Archiwum')} · ${channel.name}`
      : `${tvGroupLabel(channel.group)} · ${tvCountryLabel(channel.country_name)}`;
    document.getElementById('tv-loading-name').textContent = channel.name;
    mountTvLogo(document.getElementById('tv-now-logo'), channel);
    document.querySelectorAll('[data-tv-channel]').forEach(node => {
      node.classList.toggle('active', node.dataset.tvChannel === channel.id);
    });
    setTvPlayerState('loading', channel.name);

    if (!channel.playback_url) {
      try {
        const result = parseJson(await call('get_tv_playback', String(channel.id || '')), {});
        if (sequence !== state.tvPlaybackSequence || state.tvSelected !== channel) return;
        if (!result.success || !result.playback_url) {
          throw new Error(result.message || tr('Nie przygotowano transmisji'));
        }
        channel.playback_url = result.playback_url;
        if (!channel.stream_type && result.stream_type) channel.stream_type = result.stream_type;
      } catch (error) {
        if (sequence !== state.tvPlaybackSequence || state.tvSelected !== channel) return;
        showTvPlaybackError(error.message || String(error));
        return;
      }
    }

    const video = document.getElementById('tv-video');
    const isDash = /\.mpd(?:$|[?#])/i.test(channel.stream_url);
    const isMpegTs = channel.stream_type === 'mpegts'
      || /\.(?:ts|mpegts)(?:$|[?#])/i.test(channel.stream_url);
    const isNativeMedia = /\.(?:mp4|webm|og[gv]|mp3|aac|m4a)(?:$|[?#])/i.test(channel.stream_url);
    const isExplicitHls = /\.m3u8?(?:$|[?#])/i.test(channel.stream_url);
    const playbackUrl = channel.playback_url || channel.stream_url;
    const HlsPlayer = window.Hls;
    if (isMpegTs) {
      playTvMpegTs(channel, sequence);
      return;
    }
    if (isDash) {
      const DashPlayer = window.dashjs?.MediaPlayer;
      if (!DashPlayer) {
        showTvPlaybackError(tr('Nie udało się uruchomić silnika MPEG-DASH.'));
        return;
      }
      try {
        const dash = DashPlayer().create();
        state.tvDash = dash;
        const events = window.dashjs.MediaPlayer.events || {};
        const markReady = () => {
          if (sequence !== state.tvPlaybackSequence || state.tvDash !== dash) return;
          setTvPlayerState('none');
          attemptTvPlay(sequence);
        };
        if (events.STREAM_INITIALIZED) dash.on(events.STREAM_INITIALIZED, markReady);
        if (events.PLAYBACK_STARTED) dash.on(events.PLAYBACK_STARTED, markReady);
        if (events.ERROR) {
          dash.on(events.ERROR, () => {
            setTimeout(() => {
              if (sequence !== state.tvPlaybackSequence || state.tvDash !== dash) return;
              if (video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA) {
                showTvPlaybackError(tr('Nadawca nie odpowiedział. Spróbuj ponownie za chwilę.'));
              }
            }, 1800);
          });
        }
        dash.initialize(video, playbackUrl, true);
      } catch (_) {
        showTvPlaybackError(tr('Nie udało się uruchomić transmisji MPEG-DASH.'));
      }
      return;
    }
    if (!isNativeMedia && HlsPlayer?.isSupported?.()) {
      const hls = new HlsPlayer({
        enableWorker: true,
        lowLatencyMode: false,
        backBufferLength: 60,
        maxBufferLength: 60,
        maxMaxBufferLength: 120,
        liveSyncDurationCount: 3,
        liveMaxLatencyDurationCount: 8,
        maxLiveSyncPlaybackRate: 1.15,
        manifestLoadingTimeOut: 30_000,
        levelLoadingTimeOut: 30_000,
        fragLoadingTimeOut: 30_000,
      });
      state.tvHls = hls;
      hls.on(HlsPlayer.Events.MEDIA_ATTACHED, () => {
        if (sequence !== state.tvPlaybackSequence || state.tvHls !== hls) return;
        hls.loadSource(playbackUrl);
        attemptTvPlay(sequence);
      });
      hls.on(HlsPlayer.Events.MANIFEST_PARSED, () => {
        if (sequence !== state.tvPlaybackSequence || state.tvHls !== hls) return;
        setTvPlayerState('none');
        attemptTvPlay(sequence);
      });
      hls.on(HlsPlayer.Events.ERROR, (_event, data) => {
        if (sequence !== state.tvPlaybackSequence || state.tvHls !== hls || !data?.fatal) return;
        if (data.type === HlsPlayer.ErrorTypes.NETWORK_ERROR && state.tvNetworkRetries < 4) {
          state.tvNetworkRetries += 1;
          setTvPlayerState('loading', tr('Ponawianie połączenia…'));
          setTimeout(() => {
            if (sequence === state.tvPlaybackSequence && state.tvHls === hls) hls.startLoad();
          }, 900 * state.tvNetworkRetries);
          return;
        }
        if (data.type === HlsPlayer.ErrorTypes.MEDIA_ERROR && !state.tvMediaRecovered) {
          state.tvMediaRecovered = true;
          hls.recoverMediaError();
          return;
        }
        if (!isExplicitHls && !state.tvNativeFallbackUsed) {
          state.tvNativeFallbackUsed = true;
          try { hls.destroy(); } catch (_) { /* no-op */ }
          if (state.tvHls === hls) state.tvHls = null;
          setTvPlayerState('loading', tr('Sprawdzanie alternatywnego formatu…'));
          playTvNative(channel, sequence);
          return;
        }
        showTvPlaybackError(tr('Nadawca nie odpowiedział. Spróbuj ponownie za chwilę.'));
      });
      hls.attachMedia(video);
      return;
    }

    playTvNative(channel, sequence);
  }

  function currentTvCountryChannels() {
    if (state.tvCountry === 'all') return state.tvChannels;
    return state.tvChannels.filter(channel => channel.country_id === state.tvCountry);
  }

  function renderTvCountries() {
    const host = document.getElementById('tv-country-tabs');
    host.replaceChildren();
    const countries = (state.tvCountries || []).filter(country =>
      state.tvChannels.some(channel => channel.country_id === country.id)
    );
    if (countries.length > 1) {
      countries.unshift({ id: 'all', name: tr('Wszystkie kraje') });
    }
    if (!countries.some(country => country.id === state.tvCountry)) {
      state.tvCountry = countries[0]?.id || 'all';
    }
    countries.forEach(country => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = `tv-country-tab${country.id === state.tvCountry ? ' active' : ''}`;
      button.textContent = tvCountryLabel(country.name);
      button.addEventListener('click', () => {
        state.tvCountry = country.id;
        state.tvGroup = 'all';
        renderTvDirectory();
      });
      host.appendChild(button);
    });
  }

  function renderTvCategories() {
    const host = document.getElementById('tv-category-tabs');
    host.replaceChildren();
    const channels = currentTvCountryChannels();
    const groups = [...new Set(channels.map(channel => channel.group || 'Pozostałe'))]
      .sort((a, b) => tvGroupLabel(a).localeCompare(tvGroupLabel(b), tvLocale()));
    if (state.tvGroup !== 'all' && !groups.includes(state.tvGroup)) state.tvGroup = 'all';
    [{ id: 'all', label: tr('Wszystkie') }, ...groups.map(group => ({ id: group, label: tvGroupLabel(group) }))]
      .forEach(group => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = `tv-category-tab${group.id === state.tvGroup ? ' active' : ''}`;
        button.textContent = group.label;
        button.addEventListener('click', () => {
          state.tvGroup = group.id;
          renderTvDirectory();
        });
        host.appendChild(button);
      });
  }

  function filteredTvChannels() {
    const query = normalizeTvText(state.tvQuery);
    return currentTvCountryChannels().filter(channel => {
      if (state.tvGroup !== 'all' && channel.group !== state.tvGroup) return false;
      if (!query) return true;
      return normalizeTvText(`${channel.name} ${channel.group}`).includes(query);
    });
  }

  function renderTvChannels(options = {}) {
    const host = document.getElementById('tv-channel-list');
    if (!host) return;
    const channels = filteredTvChannels();
    const renderKey = `${state.tvCountry}\u0000${state.tvGroup}\u0000${normalizeTvText(state.tvQuery)}`;
    if (state.tvRenderKey !== renderKey || options.reset) {
      state.tvRenderKey = renderKey;
      state.tvVisibleLimit = 80;
      host.scrollTop = 0;
    }
    const previousScroll = host.scrollTop;
    const visibleChannels = channels.slice(0, state.tvVisibleLimit);
    const fragment = document.createDocumentFragment();
    visibleChannels.forEach(channel => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = `tv-channel-button${state.tvSelected?.id === channel.id ? ' active' : ''}`;
      button.dataset.tvChannel = channel.id;
      button.setAttribute('aria-label', `${tr('Odtwórz')} ${channel.name}`);

      const logo = document.createElement('span');
      logo.className = 'tv-channel-logo';
      mountTvLogo(logo, channel);
      const copy = document.createElement('span');
      copy.className = 'tv-channel-copy';
      const name = document.createElement('strong');
      name.textContent = channel.name;
      const group = document.createElement('small');
      group.textContent = tvGroupLabel(channel.group);
      copy.append(name, group);
      const play = document.createElement('span');
      play.className = 'tv-channel-play';
      button.append(logo, copy, play);
      button.addEventListener('click', () => selectTvChannel(channel));
      fragment.appendChild(button);
    });
    host.replaceChildren(fragment);
    if (options.preserveScroll) host.scrollTop = previousScroll;
    document.getElementById('tv-channel-total').textContent = channels.length.toLocaleString(tvLocale());
    document.getElementById('tv-list-empty').hidden = channels.length !== 0;
  }

  function renderTvDirectory() {
    renderTvCountries();
    renderTvCategories();
    renderTvChannels();
  }

  function findReloadedTvChannel(previous) {
    if (!previous) return null;
    const tvgId = String(previous.tvg_id || '').trim();
    if (tvgId) {
      const exact = state.tvChannels.find(channel => String(channel.tvg_id || '').trim() === tvgId);
      if (exact) return exact;
    }
    const name = normalizeTvText(previous.name || '');
    const group = normalizeTvText(previous.group || '');
    return state.tvChannels.find(channel =>
      normalizeTvText(channel.name || '') === name
      && normalizeTvText(channel.group || '') === group
    ) || state.tvChannels.find(channel => normalizeTvText(channel.name || '') === name) || null;
  }

  async function loadTvChannels(force = false, options = {}) {
    if (state.tvBusy) return;
    const silent = Boolean(options.silent);
    const preserveSelection = Boolean(options.preserveSelection);
    const previousSelection = preserveSelection ? state.tvSelected : null;
    state.tvBusy = true;
    const loading = document.getElementById('tv-list-loading');
    const refresh = document.getElementById('tv-refresh');
    const signal = document.querySelector('.tv-signal-pill');
    loading.hidden = silent || state.tvLoaded;
    refresh.disabled = true;
    refresh.classList.add('loading');
    signal.classList.add('loading');
    document.getElementById('tv-source-status').textContent = tr('AKTUALIZOWANIE LISTY');
    try {
      const result = parseJson(await call('get_tv_channels', Boolean(force)), {});
      if (!result.success) throw new Error(result.message || tr('Nie udało się pobrać listy kanałów'));
      state.tvChannels = Array.isArray(result.channels) ? result.channels : [];
      state.tvCountries = Array.isArray(result.countries) ? result.countries : [];
      state.tvGroups = Array.isArray(result.groups) ? result.groups : [];
      state.tvEpgAvailable = Boolean(result.epg_available);
      state.tvRefreshedAt = Number(result.refreshed_at || 0);
      state.tvRemoteSequence = Number(result.remote_sequence || 0);
      state.tvLoaded = true;
      loading.hidden = true;
      signal.classList.toggle('stale', Boolean(result.stale));
      document.getElementById('tv-source-status').textContent = result.stale
        ? tr('LISTA OFFLINE')
        : tr('ŹRÓDŁO GOTOWE');
      document.getElementById('tv-refreshed-at').textContent = `${tr('Aktualizacja')} ${formatTvUpdated(result.refreshed_at)}`;
      state.tvRenderKey = '';
      renderTvDirectory();
      if (preserveSelection && previousSelection) {
        const reloaded = findReloadedTvChannel(previousSelection);
        if (reloaded) selectTvChannel(reloaded);
        else clearTvMedia({ clearSelection: true });
      }
      if (!silent && result.warning && result.stale) {
        toast('info', tr('Wyświetlam ostatnią zapisaną listę'), result.warning);
      }
    } catch (error) {
      loading.hidden = true;
      signal.classList.add('stale');
      document.getElementById('tv-source-status').textContent = tr('BRAK LISTY');
      const empty = document.getElementById('tv-list-empty');
      empty.hidden = false;
      empty.querySelector('strong').textContent = tr('Nie udało się pobrać kanałów');
      empty.querySelector('small').textContent = tr('Sprawdź połączenie i odśwież listę.');
      if (!silent) toast('error', tr('Telewizja'), error.message || String(error));
    } finally {
      state.tvBusy = false;
      refresh.disabled = false;
      refresh.classList.remove('loading');
      signal.classList.remove('loading');
    }
  }

  function stopTvConfigWatcher() {
    if (state.tvConfigTimer) clearInterval(state.tvConfigTimer);
    state.tvConfigTimer = null;
  }

  async function checkTvConfigUpdate() {
    if (state.page !== 'tv' || state.tvConfigBusy || state.tvBusy) return;
    state.tvConfigBusy = true;
    try {
      const status = parseJson(
        await call('check_tv_playlist_update', Number(state.tvRemoteSequence || 0)),
        {},
      );
      if (status.success && status.changed) {
        await loadTvChannels(true, { silent: true, preserveSelection: true });
      }
    } catch (_) {
      // Remote TV configuration is best-effort; the last verified playlist stays active.
    } finally {
      state.tvConfigBusy = false;
    }
  }

  function startTvConfigWatcher() {
    stopTvConfigWatcher();
    // Show a verified disk/bundled list first, then check the remote revision.
    // This keeps first paint instant even on a slow or unavailable GitHub edge.
    setTimeout(checkTvConfigUpdate, 900);
    state.tvConfigTimer = setInterval(checkTvConfigUpdate, 30_000);
  }

  function bindTvPlayer() {
    const video = document.getElementById('tv-video');
    video.addEventListener('playing', () => {
      if (!state.tvSelected) return;
      setTvPlayerState('none');
      document.getElementById('tv-video-shell').classList.add('playing');
      document.getElementById('tv-live-corner').hidden = false;
      document.getElementById('tv-live-label').textContent = state.tvSelected.is_catchup
        ? tr('POWTÓRKA')
        : tr('NA ŻYWO');
      startTvHealthMonitor(state.tvSelected, state.tvPlaybackSequence);
    });
    video.addEventListener('waiting', () => {
      if (state.tvSelected && !video.paused) setTvPlayerState('loading', tr('Buforowanie transmisji…'));
    });
    video.addEventListener('canplay', () => {
      if (state.tvSelected) setTvPlayerState('none');
    });
    video.addEventListener('error', () => {
      if (state.tvSelected && !state.tvHls && !state.tvDash && !state.tvMpegTs) {
        showTvPlaybackError(tr('Format lub adres tej transmisji nie jest obecnie dostępny.'));
      }
    });
  }

  function navigate(page) {
    if (!pageMeta[page]) return;
    if (page !== 'workshop') stopWorkshopAutomationPolling();
    if (page !== 'tv' && state.page === 'tv') {
      stopTvConfigWatcher();
      clearTvMedia({ clearSelection: true });
    }
    state.page = page;
    document.querySelector('main')?.scrollTo({ top: 0, left: 0, behavior: 'auto' });
    document.querySelectorAll('.page').forEach(node => node.classList.remove('active'));
    document.querySelectorAll('.nav-item[data-page]').forEach(node => node.classList.toggle('active', node.dataset.page === page));
    document.getElementById(`page-${page}`).classList.add('active');
    document.getElementById('page-eyebrow').textContent = pageMeta[page][0];
    document.getElementById('page-title').textContent = pageMeta[page][1];
    if (page === 'manage') loadGames();
    if (page === 'add') {
      loadCatalogSuggestions();
      loadCatalogInsights();
    }
    if (page === 'oldgames' && !state.oldGamesLoaded && !state.oldGamesBusy) {
      loadOldGames(1);
    }
    if (page === 'tv') {
      startTvConfigWatcher();
      if (!state.tvLoaded && !state.tvBusy) loadTvChannels(false);
    }
    if (page === 'mode') { loadBackends(); checkBackendUpdate(false); }
    if (page === 'onlinefix') loadOnlineFix();
    if (page === 'workshop') loadWorkshop();
    if (page === 'diagnostics') loadDiagnostics();
    if (page === 'cloudsaves') {
      loadCloudSaveOverview();
      loadLibraryProfile(false);
    }
    if (page === 'plugin') loadPluginStatus();
    if (page === 'license') loadLicenseStatus();
    if (page === 'limits') loadProviderLimits();
  }

  function formatLicenseDate(value) {
    if (!value) return 'Bezterminowo';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    const locale = state.settings.language === 'en' ? 'en-US' : 'pl-PL';
    return date.toLocaleDateString(locale, { day: '2-digit', month: 'long', year: 'numeric' });
  }

  async function copyText(value, label = 'Skopiowano') {
    if (!value || value === '—') return;
    try {
      await navigator.clipboard.writeText(value);
    } catch (_) {
      const helper = document.createElement('textarea');
      helper.value = value;
      helper.style.position = 'fixed';
      helper.style.opacity = '0';
      document.body.appendChild(helper);
      helper.select();
      document.execCommand('copy');
      helper.remove();
    }
    toast('success', label, value);
  }

  function renderLicense(status, forceError = false) {
    state.license = status || {};
    const valid = Boolean(state.license.valid);
    const title = state.license.title || (valid ? 'Licencja aktywna' : 'Aktywacja wymagana');
    const message = state.license.message || '';
    const installationId = state.license.installation_id || '—';
    const pageState = document.getElementById('license-page-state');
    document.getElementById('license-page-title').textContent = title;
    document.getElementById('license-page-message').textContent = message;
    pageState.textContent = valid ? 'AKTYWNA' : 'NIEAKTYWNA';
    pageState.classList.toggle('invalid', !valid);
    const pagePill = document.getElementById('license-page-pill');
    pagePill.textContent = valid ? 'DOSTĘP AKTYWNY' : 'AKTYWACJA WYMAGANA';
    pagePill.className = valid ? 'pill purple' : 'pill gray';
    document.getElementById('license-customer').textContent = state.license.customer || '—';
    document.getElementById('license-expiry').textContent = valid ? formatLicenseDate(state.license.expires_at) : '—';
    const licenseId = state.license.license_id || '—';
    const licenseIdNode = document.getElementById('license-id');
    licenseIdNode.textContent = licenseId;
    licenseIdNode.title = licenseId;
    document.getElementById('license-binding').textContent = valid ? (state.license.machine_bound ? 'Ten komputer' : 'Klucz przenośny') : '—';
    const onlineNode = document.getElementById('license-online');
    if (state.license.state === 'revoked') {
      onlineNode.textContent = 'UNIEWAŻNIONA';
    } else if (state.license.online_verified) {
      onlineNode.textContent = 'Potwierdzona online';
    } else if (valid) {
      onlineNode.textContent = 'Tryb offline';
    } else {
      onlineNode.textContent = 'Brak potwierdzenia';
    }
    onlineNode.title = state.license.online_checked_at || '';
    document.getElementById('license-installation-id').textContent = installationId;
    document.getElementById('license-gate-installation').textContent = installationId;
    document.getElementById('license-deactivate').disabled = !state.license.can_deactivate;

    const gate = document.getElementById('license-gate');
    gate.classList.remove('pending');
    gate.classList.toggle('visible', !valid);
    document.getElementById('license-gate-title').textContent = title;
    const error = document.getElementById('license-gate-error');
    const showError = !valid && (forceError || !['missing', ''].includes(state.license.state || ''));
    document.getElementById('license-gate-message').textContent = valid
      ? 'Licencja została aktywowana.'
      : showError
        ? 'Wpisz inny klucz, aby odzyskać dostęp.'
        : (message || 'Wpisz klucz licencji, aby uruchomić KillzoneTools.');
    error.hidden = !showError;
    error.textContent = showError ? message : '';
  }

  async function initializeApplication() {
    if (state.initialized) return;
    state.initialized = true;
    try {
      await Promise.all([loadSettings(), refreshAll()]);
      await loadWatcherNotifications(false);
      startWatcherNotificationPolling();
      void checkHubcapHealth(false);
      startHubcapHealthPolling();
      if (state.cloudProvider.authenticated) {
        void loadLibraryProfile(true, true);
      } else {
        renderLibraryProfile({ authenticated: false });
      }
      if (state.cloudProvider.google_connected) {
        if (state.cloudProvider.migration?.state !== 'complete') {
          void migrateCloudSaves(true);
        }
      } else if (!state.cloudProvider.ready && !state.settings.cloud_onboarding_seen) {
        navigate('cloudsaves');
        const response = parseJson(
          await call('set_setting', 'cloud_onboarding_seen', JSON.stringify(true))
        );
        if (response.success) state.settings = response.settings;
        toast(
          'info',
          'Skonfiguruj zapisy w chmurze',
          'Wybierz magazyn lokalny albo połącz Google Drive.'
        );
      }
      try {
        const runtimeUpdate = parseJson(await call('check_backend_update', 'opensteamtool'));
        renderBackendUpdate(runtimeUpdate);
      } catch (_error) {
        // The engine card can retry explicitly; startup must remain usable.
      }
    } catch (error) {
      state.initialized = false;
      throw error;
    }
  }

  async function loadLicenseStatus(initialize = false) {
    const status = parseJson(await call('get_license_status'), {});
    renderLicense(status);
    if (initialize && status.valid) await initializeApplication();
    return status;
  }

  async function activateLicense(inputId, buttonId) {
    const input = document.getElementById(inputId);
    const button = document.getElementById(buttonId);
    const token = input.value.trim();
    if (!token) {
      renderLicense({ ...(state.license || {}), valid: false, state: 'invalid', title: 'Wklej klucz licencji', message: 'Pole klucza jest puste.' }, true);
      input.focus();
      return;
    }
    button.disabled = true;
    const original = button.textContent;
    button.textContent = 'Sprawdzanie…';
    try {
      const status = parseJson(await call('activate_license', token), {});
      renderLicense(status, !status.valid);
      if (status.valid) {
        input.value = '';
        document.getElementById(inputId === 'license-gate-key' ? 'license-page-key' : 'license-gate-key').value = '';
        await initializeApplication();
        toast('success', 'Licencja aktywowana', status.message || 'KillzoneTools jest gotowy.');
      }
    } catch (error) {
      renderLicense({ ...(state.license || {}), valid: false, state: 'invalid', title: 'Nie udało się aktywować', message: error.message || String(error) }, true);
    } finally {
      button.disabled = false;
      button.textContent = original;
    }
  }

  async function deactivateLicense() {
    if (!window.confirm(tr('Usunąć licencję z tego komputera? Program wróci do ekranu aktywacji.'))) return;
    const status = parseJson(await call('deactivate_license'), {});
    renderLicense(status);
    document.getElementById('license-gate-key').focus();
  }

  async function loadDashboard() {
    const data = parseJson(await call('get_dashboard'));
    document.getElementById('side-version').textContent = `v${data.version || '0.1.0'}`;
    document.getElementById('stat-managed').textContent = data.managed_count ?? 0;
    document.getElementById('nav-count').textContent = data.managed_count ?? 0;
    const engineReady = data.active_backend === 'KillzoneTools';
    document.getElementById('stat-backend').textContent = engineReady ? 'Gotowy' : 'Wymaga uwagi';
    document.getElementById('stat-steam').textContent = data.steam_found ? (data.steam_running ? 'Uruchomiony' : 'Wykryty') : 'Nie znaleziono';
    document.getElementById('stat-steam-path').textContent = data.steam_path || 'Nie znaleziono Steam';
    document.querySelector('.connection').classList.toggle('online', Boolean(data.steam_found));
    document.getElementById('connection-label').textContent = data.steam_found ? 'Steam połączony' : 'Steam niedostępny';
    const ready = document.getElementById('home-ready-label');
    if (ready) ready.textContent = data.steam_found && engineReady ? 'SYSTEM GOTOWY' : data.steam_found ? 'SPRAWDŹ SILNIK' : 'NIE WYKRYTO STEAM';
  }

  function renderSteamAccounts(payload = {}) {
    state.steamAccounts = payload;
    const host = document.getElementById('steam-account-list');
    const summary = document.getElementById('steam-account-summary');
    if (!host || !summary) return;
    const accounts = Array.isArray(payload.accounts) ? payload.accounts : [];
    if (!accounts.length) {
      summary.textContent = tr('Nie wykryto kont');
      summary.className = 'account-panel-summary disabled';
      host.innerHTML = '<span class="account-empty">' + escapeHtml(tr(payload.message || 'Nie znaleziono zapisanych kont Steam.')) + '</span>';
      return;
    }
    const active = accounts.find(account => account.active) || accounts[0];
    const activeName = active.persona_name || active.account_name || tr('Konto Steam');
    const stale = payload.success === false;
    summary.textContent = stale
      ? tr('Stan kont wymaga uwagi')
      : activeName + ' \u2022 ' + tr(active.enabled ? 'W\u0142\u0105czone' : 'Wy\u0142\u0105czone');
    summary.className = 'account-panel-summary ' + (!stale && active.enabled ? 'enabled' : 'disabled');
    const errorBanner = stale
      ? '<div class="account-policy-error"><strong>' + escapeHtml(tr('Nie można bezpiecznie zmienić kont')) +
        '</strong><span>' + escapeHtml(payload.message || tr('Sprawdź pliki Steam i spróbuj ponownie.')) + '</span></div>'
      : '';
    host.innerHTML = errorBanner + accounts.map(account => {
      const name = account.persona_name || account.account_name || tr('Konto Steam');
      const initial = Array.from(name.trim())[0]?.toUpperCase() || 'S';
      const avatar = account.avatar_data_url
        ? '<img src="' + escapeHtml(account.avatar_data_url) + '" alt="">'
        : escapeHtml(initial);
      const badges = [
        account.active ? '<span class="account-badge current">' + escapeHtml(tr('AKTYWNE KONTO')) + '</span>' : '',
      ].join('');
      const action = account.enabled ? tr('Wy\u0142\u0105cz') : tr('W\u0142\u0105cz');
      return '<article class="steam-account-card ' + (account.active ? 'active' : '') + '">' +
        '<span class="steam-account-avatar">' + avatar + '</span>' +
        '<span class="steam-account-copy"><strong class="steam-account-name">' + escapeHtml(name) + '</strong>' +
        '<span class="steam-account-login">' + escapeHtml(account.account_name || '') + '</span>' +
        '<span class="steam-account-badges">' + badges + '</span></span>' +
        '<button class="account-toggle ' + (account.enabled ? 'off' : '') + '" data-steam-account="' +
        escapeHtml(account.steam_id64) + '" data-enabled="' + String(Boolean(account.enabled)) + '"' +
        (stale ? ' disabled aria-disabled="true"' : '') + '>' +
        escapeHtml(action) + '</button></article>';
    }).join('');
  }

  async function loadSteamAccounts() {
    try {
      renderSteamAccounts(parseJson(await call('get_steam_accounts'), {}));
    } catch (error) {
      renderSteamAccounts({ success: false, message: error.message || String(error), accounts: [] });
    }
  }

  async function toggleSteamAccount(button) {
    const steamId = button.dataset.steamAccount || '';
    const desired = button.dataset.enabled !== 'true';
    button.disabled = true;
    const original = button.textContent;
    button.textContent = tr('Prze\u0142\u0105czanie...');
    try {
      const result = parseJson(await call('set_steam_account_enabled', steamId, desired), {});
      if (!result.success) throw new Error(result.message || tr('Nie uda\u0142o si\u0119 prze\u0142\u0105czy\u0107 konta'));
      renderSteamAccounts(result.data || {});
      toast('success', tr('Konto Steam'), result.message, result.warnings || []);
      await Promise.all([loadDashboard(), loadGames()]);
    } catch (error) {
      button.disabled = false;
      button.textContent = original;
      toast('error', tr('Konto Steam'), error.message || String(error));
      await loadSteamAccounts();
    }
  }

  async function loadGames() {
    state.games = parseJson(await call('get_managed_games'), []);
    document.getElementById('nav-count').textContent = state.games.length;
    renderGames();
    renderHomeShowcase();
    if (state.selectedStorefrontApp) {
      renderStorefrontAction(state.selectedStorefrontApp);
    }
  }

  function renderLibraryActivity() {
    const host = document.getElementById('library-activity-list');
    if (!host) return;
    const items = [...(state.libraryWorkspace?.activity || [])].reverse().slice(0, 6);
    if (!items.length) {
      host.innerHTML = '<span>Historia pojawi się po pierwszej zmianie.</span>';
      return;
    }
    host.innerHTML = items.map(item => `
      <article class="${item.success === false ? 'failed' : ''}">
        <i></i>
        <div><strong>${escapeHtml(item.message || 'Zmiana biblioteki')}</strong><small>${escapeHtml(item.app_id ? `App ${item.app_id}` : 'KillzoneTools')}</small></div>
        <time>${escapeHtml(formatUpdateCenterDate(item.at))}</time>
      </article>
    `).join('');
  }

  async function loadLibraryWorkspace() {
    state.libraryWorkspace = parseJson(
      await call('get_library_workspace'),
      { favorites: [], profiles: {}, activity: [] },
    );
    renderLibraryActivity();
    return state.libraryWorkspace;
  }

  function renderHomeShowcase() {
    const host = document.getElementById('home-cover-stack');
    const count = document.getElementById('home-showcase-count');
    if (!host || !count) return;
    count.textContent = `${state.games.length} ${state.games.length === 1 ? 'GRA' : 'GIER'}`;
    const pictured = state.games.filter(game => game.image_url).slice(0, 3);
    if (!pictured.length) {
      host.innerHTML = '<div class="home-cover-placeholder"><img src="assets/killzonetools-mark.svg" alt=""></div>';
      return;
    }
    host.innerHTML = pictured.map(game => `<div class="home-cover"><img src="${escapeHtml(game.image_url)}" alt=""></div>`).join('');
    host.querySelectorAll('img').forEach((image, index) => image.addEventListener('error', () => {
      const fallback = pictured[index]?.fallback_image_url;
      if (fallback && image.dataset.fallbackUsed !== '1') {
        image.dataset.fallbackUsed = '1';
        image.src = fallback;
      } else image.closest('.home-cover')?.remove();
    }));
  }

  function renderGames() {
    const host = document.getElementById('game-grid');
    const empty = document.getElementById('game-empty');
    const query = document.getElementById('library-search').value.trim().toLowerCase();
    const filter = document.getElementById('library-filter').value;
    const games = state.games.filter(game => {
      if (query && !`${game.name || ''} ${game.app_id}`.toLowerCase().includes(query)) return false;
      if (filter === 'enabled' && !game.enabled) return false;
      if (filter === 'disabled' && game.enabled) return false;
      if (filter === 'favorite' && !game.favorite) return false;
      return true;
    });
    host.innerHTML = '';
    empty.classList.toggle('visible', games.length === 0);
    games.forEach(game => {
      const card = document.createElement('article');
      card.className = 'game-card';
      const source = game.source || 'KillzoneTools';
      const title = game.name || `App ${game.app_id}`;
      const imageMarkup = game.image_url
        ? `<img alt="${escapeHtml(title)}" src="${escapeHtml(game.image_url)}" data-fallback="${escapeHtml(game.fallback_image_url || '')}">`
        : `<div class="game-image-placeholder"><span>K</span><small>Brak grafiki Steam</small></div>`;
      card.innerHTML = `<div class="game-image">${imageMarkup}<button class="game-favorite ${game.favorite ? 'active' : ''}" data-action="favorite" title="${game.favorite ? 'Usuń z ulubionych' : 'Dodaj do ulubionych'}" aria-pressed="${game.favorite ? 'true' : 'false'}">★</button><span class="game-status ${game.enabled ? '' : 'disabled'}"><i></i>${game.enabled ? 'AKTYWNA' : 'WYŁĄCZONA'}</span></div><div class="game-body"><div class="game-title"><div><strong>${escapeHtml(title)}</strong><small>Steam AppID ${escapeHtml(game.app_id)}</small></div><span class="state ${game.enabled ? '' : 'disabled'}"></span></div><div class="game-meta"><span>${escapeHtml(source)}</span><span>${game.app_entry_count || 1} wpisów App/DLC</span><span>${game.manifest_count} manifestów</span></div><div class="game-actions"><button class="game-open" data-action="details">Szczegóły</button><button data-action="toggle">${game.enabled ? 'Wyłącz' : 'Włącz'}</button><button class="remove" data-action="remove" title="Usuń">&times;</button></div></div>`;
      const image = card.querySelector('img');
      if (image) image.addEventListener('error', () => {
        const fallback = image.dataset.fallback;
        if (fallback && image.dataset.fallbackUsed !== '1') {
          image.dataset.fallbackUsed = '1';
          image.src = fallback;
          return;
        }
        image.replaceWith(Object.assign(document.createElement('div'), {
          className: 'game-image-placeholder',
          innerHTML: '<span>K</span><small>Brak grafiki Steam</small>',
        }));
      });
      card.querySelector('[data-action=toggle]').addEventListener('click', () => toggleGame(game));
      card.querySelector('[data-action=favorite]').addEventListener('click', () => toggleGameFavorite(game));
      card.querySelector('[data-action=remove]').addEventListener('click', () => requestRemoval(game));
      card.querySelector('[data-action=details]').addEventListener('click', () => openGameDrawer(game));
      card.addEventListener('click', event => {
        if (!event.target.closest('button')) openGameDrawer(game);
      });
      host.appendChild(card);
    });
  }

  async function toggleGameFavorite(game) {
    const desired = !Boolean(game.favorite);
    const result = parseJson(
      await call('set_game_favorite', String(game.app_id), desired),
      {},
    );
    if (!result.success) {
      return toast('error', 'Ulubione', result.message || 'Nie zapisano zmiany');
    }
    game.favorite = desired;
    state.libraryWorkspace = result;
    renderGames();
    renderLibraryActivity();
    scheduleLibraryProfileSync();
  }

  function closeGameDrawer() {
    state.gameDrawerSequence += 1;
    state.selectedGameDetails = null;
    document.getElementById('game-drawer').classList.remove('visible');
    document.getElementById('game-drawer-backdrop').classList.remove('visible');
    document.getElementById('game-drawer').setAttribute('aria-hidden', 'true');
    document.getElementById('game-drawer').setAttribute('aria-busy', 'false');
    state.onlineFixPlan = null;
  }

  function renderDrawerCover(game, loading = false) {
    const cover = document.getElementById('drawer-cover');
    const title = game.name || `App ${game.app_id}`;
    cover.classList.toggle('loading', loading);
    cover.innerHTML = game.image_url
      ? `<img src="${escapeHtml(game.image_url)}" alt="${escapeHtml(title)}" data-fallback="${escapeHtml(game.fallback_image_url || '')}">`
      : '<div class="game-image-placeholder"><span>K</span></div>';
    const image = cover.querySelector('img');
    if (!image) return;
    image.addEventListener('load', () => cover.classList.remove('loading'), { once: true });
    image.addEventListener('error', () => {
      const fallback = image.dataset.fallback;
      if (fallback && image.dataset.fallbackUsed !== '1') {
        image.dataset.fallbackUsed = '1';
        image.src = fallback;
      } else {
        cover.classList.remove('loading');
        cover.innerHTML = '<div class="game-image-placeholder"><span>K</span></div>';
      }
    });
  }

  function renderGameDrawerLoading(game) {
    const drawer = document.getElementById('game-drawer');
    drawer.setAttribute('aria-busy', 'true');
    drawer.classList.add('loading');
    document.getElementById('drawer-name').textContent = game.name || `App ${game.app_id}`;
    document.getElementById('drawer-appid').textContent = `App ${game.app_id}`;
    document.getElementById('drawer-source').textContent = game.source || 'KillzoneTools';
    document.getElementById('drawer-path').textContent = 'Wczytywanie folderu i ustawień gry…';
    renderDrawerCover(game, true);

    document.getElementById('drawer-lua-count').textContent = '…';
    document.getElementById('drawer-lua-list').innerHTML = '';
    document.getElementById('drawer-dlc-section').hidden = true;
    document.getElementById('drawer-dlc-list').innerHTML = '';
    document.getElementById('drawer-fix-plan').hidden = true;

    document.getElementById('drawer-lc-label').textContent = 'Wczytywanie multiplayera…';
    document.getElementById('drawer-lc-status').textContent = 'Sprawdzanie ustawień tej gry';
    document.getElementById('drawer-lc-fix').classList.remove('active');
    document.getElementById('drawer-remote-download').disabled = true;
    document.getElementById('drawer-lc-fix').disabled = true;
    document.getElementById('drawer-game-dir').disabled = true;

    const cloudSection = document.getElementById('drawer-cloud-section');
    cloudSection.className = 'drawer-section cloud-redirect-section loading';
    document.getElementById('drawer-cloud-toggle').disabled = true;
    document.getElementById('drawer-cloud-label').textContent = 'Wczytywanie zapisów…';
    document.getElementById('drawer-cloud-detail').textContent = 'Sprawdzanie konfiguracji wybranej gry';
    const cloudStatus = document.getElementById('drawer-cloud-status');
    cloudStatus.textContent = 'Proszę czekać';
    cloudStatus.className = 'cloud-redirect-status pending';
  }

  async function openGameDrawer(game) {
    const requestSequence = ++state.gameDrawerSequence;
    state.selectedGameDetails = null;
    state.onlineFixPlan = null;
    document.getElementById('game-drawer').classList.add('visible');
    document.getElementById('game-drawer-backdrop').classList.add('visible');
    document.getElementById('game-drawer').setAttribute('aria-hidden', 'false');
    renderGameDrawerLoading(game);
    const details = parseJson(await call('get_game_details', game.app_id));
    if (requestSequence !== state.gameDrawerSequence) return;
    if (!details.success) {
      toast('error', 'Nie można otworzyć gry', details.message);
      return closeGameDrawer();
    }
    state.selectedGameDetails = details;
    renderGameDrawer(details);
    void hydrateGameDrawerSections(details.app_id, requestSequence);
  }

  function drawerRequestIsCurrent(appId, requestSequence) {
    return requestSequence === state.gameDrawerSequence
      && String(state.selectedGameDetails?.app_id || '') === String(appId);
  }

  async function hydrateGameDrawerSections(appId, requestSequence, refreshDlc = false) {
    const cloudPromise = call('get_cloud_redirect_status', String(appId))
      .then(raw => {
        if (!drawerRequestIsCurrent(appId, requestSequence)) return;
        const status = parseJson(raw, { success: false, message: 'Nie odczytano stanu zapisów' });
        state.selectedGameDetails.cloud_redirect = status;
        renderCloudRedirect(status, state.selectedGameDetails);
      })
      .catch(error => {
        if (!drawerRequestIsCurrent(appId, requestSequence)) return;
        renderCloudRedirect(
          { success: false, message: error.message || String(error) },
          state.selectedGameDetails,
        );
      });
    const dlcPromise = call('get_game_dlc_profile', String(appId), Boolean(refreshDlc))
      .then(raw => {
        if (!drawerRequestIsCurrent(appId, requestSequence)) return;
        const profile = parseJson(raw, { success: false, items: [] });
        state.selectedGameDetails.dlc_profile = profile;
        renderDlcProfile(profile);
      })
      .catch(() => {
        if (drawerRequestIsCurrent(appId, requestSequence)) {
          renderDlcProfile({ success: false, items: [] });
        }
      });
    await Promise.allSettled([cloudPromise, dlcPromise]);
  }

  function renderGameDrawer(game) {
    const drawer = document.getElementById('game-drawer');
    drawer.setAttribute('aria-busy', 'false');
    drawer.classList.remove('loading');
    document.getElementById('drawer-name').textContent = game.name || `App ${game.app_id}`;
    document.getElementById('drawer-appid').textContent = `App ${game.app_id}`;
    document.getElementById('drawer-source').textContent = game.source || 'KillzoneTools';
    document.getElementById('drawer-path').textContent = game.installed
      ? game.install_directory
      : 'Gra nie jest zainstalowana lokalnie — nie wykryto appmanifestu.';
    const ids = game.app_ids || [game.app_id];
    document.getElementById('drawer-lua-count').textContent = ids.length;
    document.getElementById('drawer-lua-list').innerHTML = ids.map(id => `<span>App/DLC ${escapeHtml(id)}</span>`).join('');
    const dlcSection = document.getElementById('drawer-dlc-section');
    const dlcList = document.getElementById('drawer-dlc-list');
    if (!game.dlc_profile && ids.length > 1) {
      dlcSection.hidden = false;
      dlcList.innerHTML = '<div class="drawer-dlc-item"><span><strong>Odczytywanie wpisów DLC…</strong><small>Pakiet Lua jest analizowany lokalnie</small></span></div>';
      document.getElementById('drawer-dlc-note').textContent = 'Sprawdzanie ustawień pakietu…';
    }
    renderDrawerCover(game);
    document.getElementById('drawer-lc-label').textContent = game.online_fix_enabled
      ? 'Wyłącz multiplayer'
      : 'Włącz multiplayer';
    document.getElementById('drawer-lc-status').textContent = game.online_fix_enabled
      ? 'Multiplayer włączony'
      : game.installed
        ? 'Multiplayer wyłączony'
        : 'Najpierw zainstaluj grę w Steam';
    document.getElementById('drawer-lc-fix').classList.toggle('active', game.online_fix_enabled);
    document.getElementById('drawer-remote-download').disabled = !game.installed;
    document.getElementById('drawer-lc-fix').disabled = !game.installed;
    document.querySelector('.drawer-section.online-install')?.classList.toggle('unavailable', !game.installed);
    document.getElementById('drawer-game-dir').disabled = !game.installed;
    document.getElementById('drawer-fix-plan').hidden = true;
    if (game.dlc_profile) renderDlcProfile(game.dlc_profile);
    if (game.cloud_redirect) renderCloudRedirect(game.cloud_redirect, game);
  }

  function renderCloudRedirect(status, game) {
    const section = document.getElementById('drawer-cloud-section');
    const button = document.getElementById('drawer-cloud-toggle');
    const label = document.getElementById('drawer-cloud-label');
    const detail = document.getElementById('drawer-cloud-detail');
    const statusLine = document.getElementById('drawer-cloud-status');
    const enabled = Boolean(status.enabled);
    const ready = Boolean(status.active);
    const repairRequired = Boolean(status.repair_required);
    const nativeCloud = Boolean(status.native_cloud);
    const ownershipPending = Boolean(status.ownership_pending);
    const crossDevice = Boolean(status.cross_device);
    const provider = tr(status.provider_label || 'Google Drive');
    const version = status.version ? ` · ${status.version}` : '';

    section.classList.toggle('active', enabled || nativeCloud);
    section.classList.toggle('native', nativeCloud);
    section.classList.toggle('ownership-pending', ownershipPending);
    section.classList.toggle('unavailable', !enabled && (!game.installed || !game.enabled));
    button.classList.toggle('active', enabled || nativeCloud);
    button.classList.toggle('native', nativeCloud);
    const providerReady = Boolean(status.provider_connected || state.cloudProvider.ready);
    button.disabled = state.cloudRedirectBusy || nativeCloud || ownershipPending || (!enabled && (!providerReady || !game.installed || !game.enabled));
    button.setAttribute('aria-pressed', enabled || nativeCloud ? 'true' : 'false');
    button.setAttribute('aria-busy', state.cloudRedirectBusy ? 'true' : 'false');

    if (nativeCloud) {
      label.textContent = 'Steam Cloud';
      detail.textContent = 'Posiadasz tę grę — zapisy pozostają bezpośrednio w Steam';
      statusLine.textContent = 'Natywna synchronizacja Valve · KillzoneTools niczego nie przekierowuje';
      statusLine.className = 'cloud-redirect-status ready native';
      return;
    }
    if (ownershipPending) {
      label.textContent = 'Sprawdzanie własności gry…';
      detail.textContent = 'Steam wybiera właściwy magazyn bez ryzyka nadpisania zapisów';
      statusLine.textContent = 'Klasyfikacja zakończy się automatycznie podczas pracy Steam';
      statusLine.className = 'cloud-redirect-status pending';
      return;
    }

    label.textContent = state.cloudRedirectBusy
      ? 'Trwa konfiguracja chmury zapisów…'
      : repairRequired
        ? 'Napraw chmurę zapisów dla tej gry'
        : enabled
      ? 'Wyłącz kopię zapisów dla tej gry'
      : 'Włącz kopię zapisów dla tej gry';

    if (state.cloudRedirectBusy) {
      detail.textContent = 'Tworzymy kopię, konfigurujemy magazyn i restartujemy Steam';
      statusLine.textContent = 'Nie zamykaj Steam ani KillzoneTools podczas tej operacji';
      statusLine.className = 'cloud-redirect-status pending';
      return;
    }
    if (!status.success) {
      detail.textContent = 'Konfiguracja silnika wymaga naprawy';
      statusLine.textContent = status.message || 'Nie można odczytać konfiguracji CloudRedirect';
      statusLine.className = 'cloud-redirect-status error';
      return;
    }
    if (repairRequired) {
      detail.textContent = 'Brakuje składnika chmury — naprawimy go automatycznie';
      statusLine.textContent = status.message || 'Naprawa jest wymagana';
      statusLine.className = 'cloud-redirect-status error';
      return;
    }
    if (enabled) {
      detail.textContent = ready
        ? `${provider} · ${crossDevice ? 'synchronizacja między komputerami' : 'lokalna kopia zapisów'}`
        : status.steam_running
          ? `${provider} · uruchomienie wymaga restartu Steam`
          : `${provider} · ochrona włączy się przy następnym uruchomieniu Steam`;
      statusLine.textContent = ready
        ? `Zapisy są chronione${version}`
        : `Chmura jest skonfigurowana${version}`;
      statusLine.className = `cloud-redirect-status ${ready ? 'ready' : 'pending'}`;
      return;
    }
    detail.textContent = status.component_installed
      ? `${provider} · przed zmianą zachowamy kopię`
      : 'Pobierzemy zweryfikowany komponent i zachowamy kopię';
    statusLine.textContent = game.installed
      ? crossDevice
        ? 'Google Drive jest gotowy · włączenie i restart Steam wykonamy automatycznie'
        : 'Połącz Google Drive w zakładce Zapisy w chmurze'
      : 'Najpierw zainstaluj grę w Steam';
    statusLine.className = 'cloud-redirect-status';
  }

  function renderDlcProfile(profile) {
    const section = document.getElementById('drawer-dlc-section');
    const list = document.getElementById('drawer-dlc-list');
    const items = profile.success ? (profile.items || []) : [];
    const possibleDlc = (state.selectedGameDetails?.app_ids || []).length > 1;
    const showError = !profile.success && possibleDlc;
    section.hidden = !items.length && !showError;
    list.innerHTML = '';
    if (!items.length && showError) {
      const row = document.createElement('div');
      row.className = 'drawer-dlc-item';
      row.innerHTML = `<span><strong>${escapeHtml(profile.success ? 'Brak osobnych wpisów DLC' : 'Nie udało się odczytać listy DLC')}</strong><small>${escapeHtml(profile.message || 'Odśwież pakiet Lua i spróbuj ponownie')}</small></span>`;
      list.appendChild(row);
    }
    items.forEach(item => {
      const row = document.createElement('div');
      row.className = 'drawer-dlc-item';
      row.innerHTML = `<span><strong>${escapeHtml(item.name || `DLC ${item.app_id}`)}</strong><small>App ${escapeHtml(item.app_id)}</small></span><button class="dlc-switch ${item.enabled ? 'enabled' : ''}" data-dlc-id="${escapeHtml(item.app_id)}" data-enabled="${item.enabled ? '1' : '0'}" role="switch" aria-checked="${item.enabled ? 'true' : 'false'}"><i></i><b>${item.enabled ? 'WŁ.' : 'WYŁ.'}</b></button>`;
      list.appendChild(row);
    });
    document.getElementById('drawer-dlc-note').textContent = profile.customized
      ? `${profile.disabled_count || 0} wpisów DLC wyłączonych · OpenSteamTool przeładuje Lua automatycznie.`
      : items.length
        ? 'Wpisy DLC z pakietu są włączone. Dostęp w grze zależy od licencji Steam.'
        : 'Nie udało się potwierdzić wpisów DLC w pakiecie.';
  }

  async function toggleDrawerDlc(button) {
    const game = state.selectedGameDetails;
    if (!game) return;
    const dlcId = button.dataset.dlcId;
    const desired = button.dataset.enabled !== '1';
    button.disabled = true;
    try {
      const result = parseJson(await call('set_game_dlc', game.app_id, dlcId, desired));
      toast(result.success ? 'success' : 'error', 'Pakiet DLC', result.message, result.warnings || []);
      if (result.success) {
        const profile = parseJson(await call('get_game_dlc_profile', game.app_id, true), {});
        if (String(state.selectedGameDetails?.app_id || '') === String(game.app_id)) {
          state.selectedGameDetails.dlc_profile = profile;
          renderDlcProfile(profile);
        }
      }
    } finally {
      button.disabled = false;
    }
  }

  async function enableAllDrawerDlc() {
    const game = state.selectedGameDetails;
    if (!game) return;
    const result = parseJson(await call('enable_all_game_dlc', game.app_id));
    toast(result.success ? 'success' : 'error', 'Pakiet DLC', result.message, result.warnings || []);
    if (result.success) {
      const profile = parseJson(await call('get_game_dlc_profile', game.app_id, true), {});
      if (String(state.selectedGameDetails?.app_id || '') === String(game.app_id)) {
        state.selectedGameDetails.dlc_profile = profile;
        renderDlcProfile(profile);
      }
    }
  }

  async function refreshDrawer() {
    const game = state.selectedGameDetails;
    if (!game) return;
    const appId = String(game.app_id);
    const requestSequence = state.gameDrawerSequence;
    const details = parseJson(await call('get_game_details', appId));
    if (requestSequence !== state.gameDrawerSequence || String(state.selectedGameDetails?.app_id || '') !== appId) return;
    if (details.success) {
      state.selectedGameDetails = details;
      renderGameDrawer(details);
      void hydrateGameDrawerSections(appId, requestSequence, true);
    }
  }

  async function drawerRedownload() {
    const game = state.selectedGameDetails;
    if (!game) return;
    const button = document.getElementById('drawer-redownload');
    const original = button.innerHTML;
    button.disabled = true;
    button.innerHTML = '<svg><use href="assets/icons.svg#refresh"></use></svg><span><strong>Aktualizowanie pakietu...</strong><small>Pobieranie plików gry</small></span>';
    toast('info', 'Aktualizacja Lua', `Pobieranie pakietu App ${game.app_id}...`);
    try {
      const result = parseJson(await call('redownload_game', game.app_id));
      toast(result.success ? 'success' : 'error', result.success ? 'Lua zaktualizowane' : 'Aktualizacja nieudana', result.message, result.warnings || []);
      if (result.success) {
        scheduleLibraryProfileSync();
        await refreshAll();
      }
    } finally {
      button.disabled = false;
      button.innerHTML = original;
    }
  }

  async function drawerToggleLcFix() {
    const game = state.selectedGameDetails;
    if (!game || !game.installed) return toast('info', 'Najpierw zainstaluj grę', 'Multiplayer konfigurujemy dopiero w istniejącym folderze gry.');
    const button = document.getElementById('drawer-lc-fix');
    const label = document.getElementById('drawer-lc-label');
    const desired = !Boolean(game.online_fix_enabled);
    button.disabled = true;
    label.textContent = desired ? 'Włączanie…' : 'Wyłączanie…';
    const result = parseJson(await call('set_online_fix', game.app_id, desired));
    toast(result.success ? 'success' : 'error', result.success ? (desired ? 'Multiplayer włączony' : 'Multiplayer wyłączony') : 'Błąd multiplayer', result.message, result.warnings || []);
    button.disabled = false;
    if (result.success) await refreshDrawer();
    else label.textContent = game.online_fix_enabled ? 'Wyłącz multiplayer' : 'Włącz multiplayer';
  }

  async function drawerToggleCloudRedirect() {
    const game = state.selectedGameDetails;
    if (!game) return;
    if (game.cloud_redirect?.native_cloud) {
      return toast(
        'info',
        'Ta gra używa Steam Cloud',
        'Posiadane gry nigdy nie są przekierowywane przez KillzoneTools.'
      );
    }
    if (game.cloud_redirect?.ownership_pending) {
      return toast(
        'info',
        'Steam sprawdza własność gry',
        'Spróbuj ponownie za chwilę — wybór chmury nastąpi automatycznie.'
      );
    }
    if (state.cloudRedirectBusy) {
      return toast(
        'info',
        'Chmura zapisów jest już konfigurowana',
        'Poczekaj na zakończenie bieżącej operacji.'
      );
    }
    const operationAppId = String(game.app_id);
    const current = Boolean(game.cloud_redirect?.enabled);
    const repairRequired = Boolean(game.cloud_redirect?.repair_required);
    const desired = repairRequired || !current;
    if (desired && !state.cloudProvider.ready) {
      navigate('cloudsaves');
      return toast(
        'info',
        'Wybierz magazyn zapisów',
        'Możesz użyć szybkiego magazynu lokalnego albo zalecanego Google Drive.'
      );
    }
    if (desired && (!game.installed || !game.enabled)) {
      return toast(
        'info',
        'Chmura zapisów jest niedostępna',
        game.enabled
          ? 'Najpierw zainstaluj grę w Steam.'
          : 'Najpierw włącz tę grę w bibliotece KillzoneTools.'
      );
    }
    const button = document.getElementById('drawer-cloud-toggle');
    const label = document.getElementById('drawer-cloud-label');
    state.cloudRedirectBusy = true;
    button.disabled = true;
    label.textContent = desired
      ? 'Pobieranie i zabezpieczanie zapisów…'
      : 'Wyłączanie kopii zapisów…';
    toast(
      'info',
      desired ? 'Włączanie chmury zapisów' : 'Wyłączanie chmury zapisów',
      desired
        ? 'KillzoneTools sprawdzi własność, utworzy kopię i zrestartuje Steam.'
        : 'Wyłączamy przekierowanie zapisów dla tej gry. Istniejąca kopia pozostanie bezpieczna.'
    );
    try {
      const result = parseJson(
        await call('set_cloud_redirect', game.app_id, desired)
      );
      toast(
        result.success ? 'success' : 'error',
        result.success
          ? (desired ? 'Chmura zapisów włączona' : 'Chmura zapisów wyłączona')
          : 'Nie udało się zmienić chmury zapisów',
        result.message,
        result.warnings || []
      );
      if (result.success) {
        if (String(state.selectedGameDetails?.app_id || '') === operationAppId) {
          await refreshDrawer();
        } else {
          await refreshAll();
        }
      } else if (String(state.selectedGameDetails?.app_id || '') === operationAppId) {
        renderCloudRedirect(game.cloud_redirect || {}, game);
      }
    } catch (error) {
      toast(
        'error',
        'Nie udało się zmienić chmury zapisów',
        error?.message || 'Połączenie z usługą KillzoneTools zostało przerwane.'
      );
    } finally {
      state.cloudRedirectBusy = false;
      const latest = state.selectedGameDetails;
      if (latest) renderCloudRedirect(latest.cloud_redirect || {}, latest);
    }
  }

  function fixConfidenceLabel(plan) {
    const confidence = String(plan?.confidence || '').toLocaleLowerCase('pl');
    if (confidence.startsWith('wysoka')) return 'dopasowanie pewne';
    if (confidence.startsWith('średnia')) return 'sprawdź wybrany folder';
    if (confidence.startsWith('niska')) return 'sprawdź folder ręcznie';
    return '';
  }

  function renderOnlineFixPlan(plan) {
    state.onlineFixPlan = plan;
    const confidence = fixConfidenceLabel(plan);
    document.getElementById('drawer-fix-target').textContent = `${plan.target_directory} · ${plan.file_count} plików${confidence ? ` · ${confidence}` : ''}`;
    const mappings = plan.mapping_preview || [];
    document.getElementById('drawer-fix-files').innerHTML = mappings.length
      ? mappings.map(item => `<li>${escapeHtml(item.source)} → ${escapeHtml(item.destination)}</li>`).join('')
      : (plan.preview || []).map(file => `<li>${escapeHtml(file)}</li>`).join('');
    document.getElementById('drawer-fix-plan').hidden = false;
  }

  function showFixLocationChoice(appId, result, target) {
    state.pendingFixLocation = { appId: String(appId), result, target };
    const suggestion = result.data?.suggested_directory;
    document.getElementById('fix-location-suggestion').textContent = suggestion
      ? `Znaleziono: ${suggestion}`
      : 'Automatyczne wyszukiwanie sprawdzi wszystkie biblioteki Steam.';
    document.getElementById('fix-location-modal').classList.add('visible');
  }

  function closeFixLocationChoice() {
    state.pendingFixLocation = null;
    document.getElementById('fix-location-modal').classList.remove('visible');
  }

  async function chooseFixLocation(automatic) {
    const pending = state.pendingFixLocation;
    if (!pending) return;
    const automaticButton = document.getElementById('fix-location-auto');
    const manualButton = document.getElementById('fix-location-manual');
    const originalAuto = automaticButton.innerHTML;
    const originalManual = manualButton.innerHTML;
    automaticButton.disabled = true;
    manualButton.disabled = true;
    const active = automatic ? automaticButton : manualButton;
    active.innerHTML = `<strong>${automatic ? 'Szukam folderu...' : 'Otwieram wybór...'}</strong><small>Przygotowanie i weryfikacja instalacji</small>`;
    try {
      const archive = pending.result.data.archive;
      const planned = parseJson(await call(
        automatic ? 'plan_online_fix_automatic' : 'select_game_directory_for_fix',
        pending.appId,
        archive,
      ));
      if (!planned.success) {
        toast('error', automatic ? 'Nie znaleziono folderu' : 'Nie wybrano folderu', planned.message);
        return;
      }

      active.innerHTML = '<strong>Instalowanie...</strong><small>Kopia zapasowa i weryfikacja plików</small>';
      const installed = parseJson(await call(
        'install_online_fix_archive',
        pending.appId,
        planned.data.archive,
        planned.data.game_directory || '',
      ));
      if (!installed.success) {
        if (pending.target === 'drawer') renderOnlineFixPlan(planned.data);
        else renderOnlineFixPagePlan(planned.data);
        closeFixLocationChoice();
        toast('error', 'Instalacja nieudana', installed.message, installed.warnings || []);
        return;
      }
      const destination = installed.data?.target_directory || planned.data.target_directory;
      closeFixLocationChoice();
      toast('success', 'Online-Fix zainstalowany', `${installed.message}. Folder: ${destination}`, installed.warnings || []);
    } catch (error) {
      toast('error', 'Instalacja nieudana', error.message || String(error));
    } finally {
      automaticButton.disabled = false;
      manualButton.disabled = false;
      automaticButton.innerHTML = originalAuto;
      manualButton.innerHTML = originalManual;
    }
  }

  async function drawerDownloadRemoteFix() {
    const game = state.selectedGameDetails;
    if (!game || !game.installed) return toast('info', 'Najpierw zainstaluj grę', 'Online-Fix wymaga istniejącego katalogu gry.');
    const button = document.getElementById('drawer-remote-download');
    const original = button.innerHTML;
    button.disabled = true;
    button.innerHTML = '<span><strong>Pobieranie Online-Fix...</strong><small>Łączenie i sprawdzanie plików</small></span>';
    toast('info', 'Online-Fix.me', 'Szukanie i pobieranie pakietu...');
    try {
      const result = parseJson(await call('download_online_fix_remote', game.app_id));
      if (!result.success) return toast('error', 'Pobieranie nieudane', result.message);
      showFixLocationChoice(game.app_id, result, 'drawer');
      toast('success', 'Online-Fix pobrany', 'Wybierz sposób instalacji.');
    } catch (error) {
      toast('error', 'Pobieranie nieudane', error.message || String(error));
    } finally {
      button.disabled = false;
      button.innerHTML = original;
    }
  }

  async function drawerInstallArchive() {
    const game = state.selectedGameDetails;
    const plan = state.onlineFixPlan;
    if (!game || !plan) return;
    const button = document.getElementById('drawer-fix-install');
    button.disabled = true;
    button.textContent = 'Instalowanie...';
    try {
      const result = parseJson(await call('install_online_fix_archive', game.app_id, plan.archive, plan.game_directory || ''));
      toast(result.success ? 'success' : 'error', result.success ? 'Online-Fix zainstalowany' : 'Instalacja nieudana', result.message, result.warnings || []);
      if (result.success) document.getElementById('drawer-fix-plan').hidden = true;
    } finally {
      button.disabled = false;
      button.textContent = 'Potwierdź i zainstaluj';
    }
  }

  async function copySelectedAppId() {
    const value = state.selectedGameDetails?.app_id;
    if (!value) return;
    try { await navigator.clipboard.writeText(value); }
    catch (_) {
      const input = document.createElement('textarea'); input.value = value; document.body.appendChild(input); input.select(); document.execCommand('copy'); input.remove();
    }
    toast('success', 'Skopiowano AppID', value);
  }

  async function toggleGame(game) {
    const result = parseJson(await call('set_game_enabled', game.app_id, !game.enabled));
    toast(result.success ? 'success' : 'error', result.success ? 'Biblioteka zaktualizowana' : 'Operacja nieudana', result.message, result.warnings || []);
    if (result.success) {
      scheduleLibraryProfileSync();
      await refreshAll();
    }
  }

  function requestRemoval(game) {
    if (!state.settings.confirm_removal) return performRemoval(game);
    state.pendingRemoval = game;
    document.getElementById('confirm-modal').classList.add('visible');
  }

  async function performRemoval(game) {
    document.getElementById('confirm-modal').classList.remove('visible');
    const result = parseJson(await call('remove_game', game.app_id));
    state.pendingRemoval = null;
    toast(result.success ? 'success' : 'error', result.success ? 'Wpis usunięty' : 'Operacja nieudana', result.message);
    if (result.success) {
      scheduleLibraryProfileSync();
      await refreshAll();
    }
  }

  async function loadBackends() {
    const backends = parseJson(await call('get_backends'), []).filter(backend => backend.backend_id === 'opensteamtool');
    const host = document.getElementById('backend-list');
    host.innerHTML = '';
    backends.forEach(backend => {
      const card = document.createElement('article');
      card.className = 'backend-card';
      card.innerHTML = `<div class="backend-icon"><svg><use href="assets/icons.svg#engine"></use></svg></div><div><h3>${backend.installed ? 'Silnik gotowy' : 'Zainstaluj silnik'} ${backend.version ? `<small>v${escapeHtml(backend.version)}</small>` : ''}</h3><p>${backend.runtime_loaded ? 'Połączono ze Steam.' : backend.installed ? 'Uruchom ponownie Steam, aby dokończyć.' : 'Program pobierze pliki i uruchomi Steam ponownie.'}</p><small class="backend-path">${escapeHtml(backend.lua_directory)}</small><div class="backend-tags"><span class="tag ${backend.installed ? 'active' : ''}">${backend.installed ? 'ZAINSTALOWANO' : 'WYMAGA INSTALACJI'}</span>${backend.runtime_loaded ? '<span class="tag active">POŁĄCZONO ZE STEAM</span>' : ''}${backend.selected ? '<span class="tag active">TRYB AKTYWNY</span>' : ''}</div></div><div class="backend-actions"><button class="primary backend-install">${backend.installed ? 'Napraw' : 'Zainstaluj'}</button>${backend.installed && !backend.selected ? '<button class="ghost mode-select">Aktywuj</button>' : ''}${backend.installed ? '<button class="danger backend-uninstall">Odinstaluj</button>' : ''}</div>`;
      card.querySelector('.backend-install').addEventListener('click', event => changeBackendInstall(backend, true, event.currentTarget));
      const select = card.querySelector('.mode-select');
      if (select) select.addEventListener('click', () => selectBackend(backend));
      const uninstall = card.querySelector('.backend-uninstall');
      if (uninstall) uninstall.addEventListener('click', event => changeBackendInstall(backend, false, event.currentTarget));
      host.appendChild(card);
    });
  }

  function renderBackendUpdate(result) {
    state.backendUpdate = result;
    const panel = document.getElementById('runtime-update-panel');
    const title = document.getElementById('runtime-update-title');
    const detail = document.getElementById('runtime-update-detail');
    const install = document.getElementById('runtime-update-install');
    panel.classList.toggle('available', Boolean(result.available));
    panel.classList.toggle('error', result.success === false);
    title.textContent = result.success === false
      ? 'Nie udało się sprawdzić wydania'
      : result.available
        ? 'Nowa wersja silnika jest dostępna'
        : result.installed
          ? 'Silnik jest aktualny'
          : 'Silnik czeka na pierwszą instalację';
    detail.textContent = result.success === false
      ? (result.message || 'Sprawdź połączenie z internetem i spróbuj ponownie.')
      : result.available
        ? `Możesz bezpiecznie przejść z wersji ${result.current_version || 'nieznanej'} na ${result.latest_version}. Steam uruchomi się ponownie.`
        : result.installed
          ? 'Masz najnowszą dostępną wersję. Nie musisz nic robić.'
          : 'Użyj przycisku instalacji w głównym panelu po lewej.';
    const installedVersion = document.getElementById('runtime-installed-version');
    const latestVersion = document.getElementById('runtime-latest-version');
    if (installedVersion) installedVersion.textContent = result.current_version || (result.installed ? 'Wykryta' : 'Brak');
    if (latestVersion) latestVersion.textContent = result.latest_version || 'Brak danych';
    install.hidden = !result.available;
  }

  async function checkBackendUpdate(force = true) {
    const button = document.getElementById('runtime-update-check');
    const original = button.textContent;
    button.disabled = true;
    button.textContent = 'Sprawdzanie…';
    try {
      const result = parseJson(await call('check_backend_update', 'opensteamtool'));
      renderBackendUpdate(result);
      if (force && result.success) toast(result.available ? 'info' : 'success', 'Silnik KillzoneTools', result.available ? 'Nowa wersja jest gotowa do instalacji.' : 'Masz najnowszą wersję silnika.');
    } catch (error) {
      renderBackendUpdate({ success: false, available: false, message: error.message || String(error) });
    } finally {
      button.disabled = false;
      button.textContent = original;
    }
  }

  async function updateBackendRuntime() {
    const button = document.getElementById('runtime-update-install');
    button.disabled = true;
    button.textContent = 'Aktualizowanie…';
    toast('info', 'Aktualizacja silnika', 'Przygotowujemy silnik KillzoneTools. Steam zostanie bezpiecznie zamknięty i uruchomiony ponownie.');
    try {
      const result = parseJson(await call('update_backend', 'opensteamtool'));
      toast(result.success ? 'success' : 'error', result.success ? 'Silnik zaktualizowany' : 'Aktualizacja nieudana', result.message, result.warnings || []);
      await loadBackends();
      await checkBackendUpdate(false);
    } catch (error) {
      toast('error', 'Aktualizacja nieudana', error.message || String(error));
    } finally {
      button.disabled = false;
      button.textContent = 'Aktualizuj teraz';
    }
  }

  function renderApplicationUpdate(result, prompt = false) {
    state.applicationUpdate = result;
    const card = document.getElementById('desktop-update');
    const title = document.getElementById('desktop-update-title');
    const detail = document.getElementById('desktop-update-detail');
    card.classList.remove('checking', 'available', 'current', 'error');
    card.classList.add(result.state || 'error');
    if (result.available) {
      const automaticPromptAllowed = result.automatic_prompt_allowed !== false;
      if (automaticPromptAllowed) {
        title.textContent = 'Wykryto aktualizację';
        detail.textContent = `${result.latest_version} · kliknij, aby zainstalować`;
      } else {
        card.classList.remove('available');
        card.classList.add('error');
        title.textContent = 'Aktualizacja nieudana';
        detail.textContent = `${result.latest_version} · kliknij, aby spróbować ponownie`;
      }
      if (prompt && automaticPromptAllowed && state.license?.valid && !state.applicationUpdatePrompted) {
        state.applicationUpdatePrompted = true;
        openApplicationUpdateModal();
      }
    } else if (result.success) {
      title.textContent = 'Masz najnowszą wersję';
      const build = Number(result.current_build || 0);
      detail.textContent = build
        ? `${result.current_version || 'KillzoneTools'} · build ${build}`
        : (result.current_version || 'KillzoneTools');
    } else {
      title.textContent = 'Sprawdź aktualizacje';
      detail.textContent = 'Kliknij, aby spróbować ponownie';
    }
    if (result.last_install) {
      const previous = result.last_install;
      if (previous.success) {
        toast('success', 'Aktualizacja zakończona', `KillzoneTools ${previous.installed_version || previous.expected_version || ''} został zainstalowany i uruchomiony ponownie.`);
      } else {
        const log = previous.log_path ? ` Log: ${previous.log_path}` : '';
        toast('error', 'Aktualizacja nie została zainstalowana', `${previous.message || 'Instalator zgłosił błąd.'}${log}`);
      }
    }
  }

  function setApplicationUpdateStep(step, stateName) {
    const node = document.querySelector(`[data-update-step="${step}"]`);
    if (!node) return;
    node.classList.remove('active', 'done');
    if (stateName) node.classList.add(stateName);
    if (stateName === 'done') node.querySelector('i').textContent = '✓';
  }

  function resetApplicationUpdateSteps() {
    ['download', 'install', 'restart'].forEach((step, index) => {
      const node = document.querySelector(`[data-update-step="${step}"]`);
      if (!node) return;
      node.classList.remove('active', 'done');
      node.querySelector('i').textContent = String(index + 1);
    });
  }

  function letUiPaint() {
    return new Promise(resolve => requestAnimationFrame(() => setTimeout(resolve, 60)));
  }

  async function checkApplicationUpdate(force = false, prompt = false) {
    const card = document.getElementById('desktop-update');
    card.className = 'desktop-update checking';
    document.getElementById('desktop-update-title').textContent = 'Sprawdzanie…';
    document.getElementById('desktop-update-detail').textContent = 'Łączenie z kanałem GitHub';
    try {
      const result = parseJson(await call('check_application_update', Boolean(force)));
      renderApplicationUpdate(result, prompt);
      if (force) toast(result.success ? (result.available ? 'info' : 'success') : 'error', 'Aktualizacje KillzoneTools', result.message);
    } catch (error) {
      const result = { success: false, state: 'error', available: false, message: error.message || String(error) };
      renderApplicationUpdate(result, false);
      if (force) toast('error', 'Nie sprawdzono aktualizacji', result.message);
    }
  }

  function openApplicationUpdateModal() {
    if (!state.license?.valid) return;
    const result = state.applicationUpdate;
    if (!result?.available) return checkApplicationUpdate(true, true);
    document.getElementById('app-update-current').textContent = result.current_version || '—';
    document.getElementById('app-update-latest').textContent = result.latest_version || '—';
    document.getElementById('app-update-version').textContent = `BUILD ${result.latest_build || ''}`;
    const notes = document.getElementById('app-update-notes');
    notes.textContent = result.notes || '';
    notes.hidden = !result.notes;
    resetApplicationUpdateSteps();
    document.getElementById('app-update-progress').hidden = true;
    document.getElementById('app-update-handoff').hidden = true;
    document.getElementById('app-update-later').disabled = false;
    const install = document.getElementById('app-update-install');
    install.disabled = false;
    install.textContent = 'Pobierz i zaktualizuj';
    document.getElementById('app-update-modal').classList.add('visible');
  }

  async function downloadAndInstallApplicationUpdate() {
    const install = document.getElementById('app-update-install');
    const later = document.getElementById('app-update-later');
    const progress = document.getElementById('app-update-progress');
    install.disabled = true;
    later.disabled = true;
    install.textContent = 'Pobieranie…';
    progress.hidden = false;
    document.getElementById('app-update-handoff').hidden = true;
    resetApplicationUpdateSteps();
    setApplicationUpdateStep('download', 'active');
    document.getElementById('app-update-progress-label').textContent = 'Pobieranie aktualizacji…';
    try {
      await letUiPaint();
      const downloaded = parseJson(await call('download_application_update'));
      if (!downloaded.success) throw new Error(downloaded.message || 'Nie pobrano aktualizacji');
      setApplicationUpdateStep('download', 'done');
      setApplicationUpdateStep('install', 'active');
      document.getElementById('app-update-progress-label').textContent = 'Przygotowanie instalacji…';
      install.textContent = 'Przygotowywanie…';
      await letUiPaint();
      const started = parseJson(await call('install_application_update'));
      if (!started.success) throw new Error(started.message || 'Nie uruchomiono aktualizatora');
      document.getElementById('app-update-handoff').hidden = false;
      document.getElementById('app-update-progress-label').textContent = 'Potwierdź zgodę systemu Windows, jeśli się pojawi…';
      install.textContent = 'Zamykanie aplikacji…';
    } catch (error) {
      progress.hidden = true;
      document.getElementById('app-update-handoff').hidden = true;
      resetApplicationUpdateSteps();
      later.disabled = false;
      install.disabled = false;
      install.textContent = 'Spróbuj ponownie';
      toast('error', 'Aktualizacja nieudana', error.message || String(error));
    }
  }

  async function changeBackendInstall(backend, install, button) {
    if (!install && !window.confirm(tr('Usunąć integrację KillzoneTools ze Steam? Gry pozostaną w bibliotece, ale silnik przestanie działać do ponownej instalacji.'))) return;
    const original = button.textContent;
    button.disabled = true;
    button.textContent = install ? 'Instalowanie...' : 'Odinstalowywanie...';
    toast('info', install ? 'Instalacja silnika' : 'Usuwanie integracji', 'Pliki zostaną sprawdzone, Steam zamknięty, a po operacji uruchomiony ponownie. Proszę czekać...');
    try {
      const result = parseJson(await call(install ? 'install_backend' : 'uninstall_backend', backend.backend_id));
      toast(result.success ? 'success' : 'error', result.success ? 'Gotowe' : 'Błąd', result.message, result.warnings || []);
      await refreshAll();
    } catch (error) {
      toast('error', 'Błąd operacji', error.message || String(error));
    } finally {
      button.disabled = false;
      button.textContent = original;
    }
  }

  async function selectBackend(backend) {
    const result = parseJson(await call('select_backend', backend.backend_id));
    toast(result.success ? 'success' : 'error', result.success ? 'Silnik aktywowany' : 'Silnik niedostępny', result.message);
    if (result.success) await refreshAll();
  }

  function platformLabel(app) {
    const labels = [];
    if (app.windows) labels.push('Windows');
    if (app.mac) labels.push('macOS');
    if (app.linux) labels.push('Linux');
    return labels.join(' / ') || 'Brak danych o platformie';
  }

  function providerLabel(provider) {
    return ({
      hubcap: 'Hubcap',
      steamtools_games: 'SteamTools.games',
      steam: 'Steam Store',
    })[provider] || String(provider || 'Źródło');
  }

  function stableCatalogItem(app) {
    const existing = state.catalogIndex.get(String(app.app_id));
    if (!existing?.metadata_loaded || app.metadata_loaded) return app;
    const merged = { ...app, ...existing };
    [
      'source',
      'providers',
      'download_provider',
      'available',
      'manifest_available',
      'manifest_count',
      'last_updated',
      'onlinefix_available',
      'onlinefix_title',
      'onlinefix_url',
    ].forEach(key => {
      if (app[key] !== undefined) merged[key] = app[key];
    });
    return merged;
  }

  function rememberCatalog(items) {
    (items || []).forEach(app => {
      const stable = stableCatalogItem(app);
      state.catalogIndex.set(String(stable.app_id), stable);
    });
  }

  function visibleCatalogItems() {
    if (state.catalogMode === 'discovery') return state.catalog;
    const start = (state.catalogPage - 1) * state.catalogPageSize;
    return state.catalog.slice(start, start + state.catalogPageSize);
  }

  function renderCatalogPagination() {
    const host = document.getElementById('catalog-pagination');
    const serverPaged = state.catalogMode === 'discovery';
    const pages = serverPaged
      ? Math.max(1, Number(state.catalogPages || 1))
      : Math.max(1, Math.ceil(state.catalog.length / state.catalogPageSize));
    state.catalogPages = pages;
    host.hidden = pages <= 1;
    host.innerHTML = '';
    if (pages <= 1) return;
    const addButton = (label, page, className = '') => {
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = label;
      button.className = className;
      button.disabled = page < 1 || page > pages || page === state.catalogPage;
      if (page === state.catalogPage) button.setAttribute('aria-current', 'page');
      button.addEventListener('click', () => {
        if (state.catalogMode === 'discovery') {
          if (state.catalogDiscoveryBusy) return;
          document.getElementById('catalog-results').scrollIntoView({ behavior: 'auto', block: 'start' });
          void loadCatalogDiscovery(state.discoverySection, page);
        } else {
          state.catalogPage = page;
          renderCatalog();
          void enrichVisibleCatalog(state.catalogSearchSequence);
          void annotateOnlineFixAvailability(
            state.catalogSearchSequence,
            visibleCatalogItems()
          );
          document.getElementById('catalog-results').scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      });
      host.appendChild(button);
    };
    addButton('←', state.catalogPage - 1, 'pager-arrow');
    const candidates = new Set([1, pages, state.catalogPage - 1, state.catalogPage, state.catalogPage + 1]);
    [...candidates].filter(page => page >= 1 && page <= pages).sort((a, b) => a - b).forEach((page, index, list) => {
      if (index && page - list[index - 1] > 1) {
        const gap = document.createElement('span');
        gap.textContent = '…';
        host.appendChild(gap);
      }
      addButton(String(page), page);
    });
    addButton('→', state.catalogPage + 1, 'pager-arrow');
    const summary = document.createElement('small');
    summary.textContent = `${state.catalogPage} / ${pages}`;
    host.appendChild(summary);
  }

  function catalogNumber(value) {
    const number = Number(value || 0);
    return number ? number.toLocaleString(state.settings.language === 'en' ? 'en-US' : 'pl-PL') : '';
  }

  const reviewDescriptionsPl = {
    'Overwhelmingly Positive': 'Przytłaczająco pozytywne',
    'Very Positive': 'Bardzo pozytywne',
    'Mostly Positive': 'W większości pozytywne',
    'Positive': 'Pozytywne',
    'Mixed': 'Mieszane',
    'Mostly Negative': 'W większości negatywne',
    'Negative': 'Negatywne',
    'Very Negative': 'Bardzo negatywne',
    'Overwhelmingly Negative': 'Przytłaczająco negatywne',
  };

  const reviewDescriptionsByScore = {
    1: 'Overwhelmingly Negative',
    2: 'Very Negative',
    3: 'Negative',
    4: 'Mostly Negative',
    5: 'Mixed',
    6: 'Mostly Positive',
    7: 'Positive',
    8: 'Very Positive',
    9: 'Overwhelmingly Positive',
  };

  function catalogReviewPresentation(app) {
    const total = Number(app.review_total || 0);
    const percent = Number(app.review_positive_percent || 0);
    let score = Number(app.review_score || 0);
    let canonical = reviewDescriptionsByScore[score] || '';
    if (!canonical && reviewDescriptionsPl[app.review_score_desc]) canonical = app.review_score_desc;
    if (!canonical && total) {
      if (total < 50) score = percent >= 80 ? 7 : percent >= 40 ? 5 : 3;
      else if (percent >= 95 && total >= 500) score = 9;
      else if (percent >= 80) score = 8;
      else if (percent >= 70) score = 6;
      else if (percent >= 40) score = 5;
      else if (percent >= 20) score = 4;
      else score = total >= 500 ? 1 : 2;
      canonical = reviewDescriptionsByScore[score];
    }
    const tier = score >= 8
      ? 'excellent'
      : score >= 6
        ? 'positive'
        : score === 5
          ? 'mixed'
          : 'negative';
    return { score, canonical, tier };
  }

  function catalogReview(app) {
    if (!Number(app.review_total || 0)) return '';
    const english = state.settings.language === 'en';
    const review = catalogReviewPresentation(app);
    if (!review.canonical) return '';
    const description = english
      ? review.canonical
      : (reviewDescriptionsPl[review.canonical] || review.canonical);
    const votes = catalogNumber(app.review_total);
    return `
      <div class="catalog-reviews review-${review.tier}">
        <strong>${escapeHtml(description)}</strong>
        <span>${escapeHtml(app.review_positive_percent || 0)}% ${english ? 'positive' : 'pozytywnych'} · ${escapeHtml(votes)} ${english ? 'votes' : 'głosów'}</span>
      </div>`;
  }

  function storefrontDate(timestamp) {
    const value = Number(timestamp || 0);
    if (!value) return '';
    return new Date(value * 1000).toLocaleDateString(
      state.settings.language === 'en' ? 'en-US' : 'pl-PL',
      { day: 'numeric', month: 'short', year: 'numeric' },
    );
  }

  function setSafeStorefrontImage(image, sources) {
    if (!image) return;
    const fallback = 'assets/killzonetools-mark.svg';
    const candidates = [...new Set(
      [...(sources || []), fallback].map(value => String(value || '').trim()).filter(Boolean)
    )];
    const requestToken = String((Number(image.dataset.loadToken || 0) + 1));
    const frame = image.closest('.storefront-shot-main');
    image.dataset.loadToken = requestToken;
    let sourceIndex = 0;
    image.classList.add('storefront-image-loading');
    image.classList.remove('storefront-image-fallback');
    frame?.classList.add('image-loading');
    image.onload = () => {
      if (image.dataset.loadToken !== requestToken) return;
      image.classList.remove('storefront-image-loading');
      image.classList.toggle(
        'storefront-image-fallback',
        image.getAttribute('src') === fallback
      );
      frame?.classList.remove('image-loading');
    };
    image.onerror = () => {
      if (image.dataset.loadToken !== requestToken) return;
      sourceIndex += 1;
      if (candidates[sourceIndex]) {
        image.src = candidates[sourceIndex];
        return;
      }
      image.classList.remove('storefront-image-loading');
      image.classList.add('storefront-image-fallback');
      frame?.classList.remove('image-loading');
    };
    image.src = candidates[0] || fallback;
  }

  function resetStorefrontScroll() {
    const body = document.getElementById('storefront-body');
    if (body) body.scrollTop = 0;
  }

  function managedStorefrontGame(appId) {
    return state.games.find(game => String(game.app_id) === String(appId)) || null;
  }

  function renderStorefrontAction(details) {
    const button = document.getElementById('storefront-add-game');
    const managed = managedStorefrontGame(details.app_id);
    button.dataset.mode = managed ? 'update' : 'add';
    button.textContent = managed ? tr('Aktualizuj grę') : tr('Dodaj grę');
    button.disabled = Boolean(details.coming_soon);
    button.title = managed
      ? tr('Pobierz najnowszy pakiet Lua dla tej gry')
      : '';
  }

  function closeStorefront() {
    state.storefrontSequence += 1;
    state.selectedStorefrontApp = null;
    resetStorefrontScroll();
    const modal = document.getElementById('storefront-modal');
    modal.classList.remove('visible', 'storefront-loading-state');
    modal.removeAttribute('aria-busy');
    modal.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('storefront-open');
  }

  function showStorefrontLoading(app) {
    const english = state.settings.language === 'en';
    const modal = document.getElementById('storefront-modal');
    document.getElementById('storefront-loading-title').textContent =
      app.name || `App ${app.app_id}`;
    document.getElementById('storefront-loading-eyebrow').textContent = english
      ? 'OFFICIAL STEAM DATA'
      : 'OFICJALNE DANE STEAM';
    document.getElementById('storefront-loading-copy').textContent = english
      ? 'Loading the gallery, English reviews, and the latest official details.'
      : 'Pobieramy galerię, angielskie opinie i najnowsze oficjalne informacje.';
    document.getElementById('storefront-loading').hidden = false;
    document.getElementById('storefront-body').hidden = true;
    modal.classList.add('storefront-loading-state');
    modal.setAttribute('aria-busy', 'true');
  }

  function renderStorefront(details) {
    const english = state.settings.language === 'en';
    const modal = document.getElementById('storefront-modal');
    const header = details.header_image || details.image_url || details.fallback_image_url || '';
    const background = details.background || header;
    setSafeStorefrontImage(
      document.getElementById('storefront-header-image'),
      [header, details.image_url, details.fallback_image_url]
    );
    document.getElementById('storefront-hero').style.backgroundImage = background
      ? `linear-gradient(90deg, rgba(8,7,6,.2), rgba(8,7,6,.84)), url("${String(background).replaceAll('"', '%22')}")`
      : '';
    document.getElementById('storefront-title').textContent = details.name || `App ${details.app_id}`;
    document.getElementById('storefront-subtitle').textContent = [
      `App ${details.app_id}`,
      details.release_date || '',
      (details.developers || [])[0] || '',
    ].filter(Boolean).join(' · ');

    const screenshots = (details.screenshots || []).filter(item => item?.full);
    const mainShot = screenshots[0]?.full || header;
    const mainImage = document.getElementById('storefront-shot-main');
    setSafeStorefrontImage(
      mainImage,
      [mainShot, header, details.image_url, details.fallback_image_url]
    );
    mainImage.alt = details.name || '';
    const strip = document.getElementById('storefront-shot-strip');
    strip.innerHTML = screenshots.slice(0, 8).map((shot, index) => `
      <button type="button" class="${index === 0 ? 'active' : ''}" data-shot="${escapeHtml(shot.full)}">
        <img alt="">
      </button>`).join('');
    strip.querySelectorAll('[data-shot]').forEach((button, index) => {
      const shot = screenshots[index];
      setSafeStorefrontImage(
        button.querySelector('img'),
        [shot?.thumbnail, shot?.full, header, details.fallback_image_url]
      );
    });
    strip.querySelectorAll('[data-shot]').forEach(button => button.addEventListener('click', () => {
      setSafeStorefrontImage(
        mainImage,
        [button.dataset.shot, header, details.image_url, details.fallback_image_url]
      );
      strip.querySelectorAll('button').forEach(item => item.classList.toggle('active', item === button));
    }));
    document.getElementById('storefront-gallery').classList.toggle('single', screenshots.length < 2);

    document.getElementById('storefront-review-summary').innerHTML =
      catalogReview(details)
      || `<span class="storefront-no-data">${english ? 'No review summary yet' : 'Brak podsumowania recenzji'}</span>`;
    document.getElementById('storefront-about').textContent =
      details.about || details.short_description || (english ? 'Steam did not provide a description.' : 'Steam nie udostępnił opisu.');
    const developers = (details.developers || []).join(', ');
    const facts = [
      [english ? 'Release' : 'Premiera', details.release_date || '—'],
      [english ? 'Developer' : 'Twórca', developers || '—'],
      [
        english ? 'Last update' : 'Ostatnia aktualizacja',
        storefrontDate(details.last_update_timestamp) || '—',
      ],
      ['Steam AppID', details.app_id],
    ];
    document.getElementById('storefront-facts').innerHTML = facts.map(([label, value]) =>
      `<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value)}</dd></div>`
    ).join('');
    document.getElementById('storefront-tags').innerHTML = [
      ...(details.genres || []),
      ...(details.categories || []),
    ].filter((value, index, values) => value && values.indexOf(value) === index)
      .slice(0, 12)
      .map(value => `<span>${escapeHtml(value)}</span>`)
      .join('');

    const reviews = details.reviews || [];
    document.getElementById('storefront-reviews').innerHTML = reviews.length
      ? reviews.map(review => {
        const hours = Number(review.playtime_minutes || 0) / 60;
        const meta = [
          storefrontDate(review.timestamp),
          hours >= 0.1 ? `${hours.toFixed(hours < 10 ? 1 : 0)} h` : '',
          review.votes_up ? `${catalogNumber(review.votes_up)} ${english ? 'helpful' : 'pomocnych'}` : '',
        ].filter(Boolean).join(' · ');
        return `<article class="storefront-review ${review.recommended ? 'recommended' : 'not-recommended'}">
          <header><strong>${review.recommended ? (english ? 'Recommended' : 'Poleca') : (english ? 'Not recommended' : 'Nie poleca')}</strong><small>${escapeHtml(meta)}</small></header>
          <p>${escapeHtml(review.text)}</p>
        </article>`;
      }).join('')
      : `<div class="storefront-empty">${english ? 'No recent reviews are available.' : 'Brak dostępnych ostatnich recenzji.'}</div>`;

    const news = details.news || [];
    const newsHost = document.getElementById('storefront-news');
    newsHost.innerHTML = news.length
      ? news.map(item => `<article class="storefront-news-item">
          <header>
            <span class="storefront-news-source"><i></i>${english ? 'Official Steam update' : 'Oficjalna aktualizacja Steam'}</span>
            <time>${escapeHtml(storefrontDate(item.timestamp))}</time>
          </header>
          <h4>${escapeHtml(item.title)}</h4>
          <p>${escapeHtml(item.summary || (english ? 'Open the announcement to read the full update.' : 'Otwórz ogłoszenie, aby przeczytać pełną aktualizację.'))}</p>
          ${item.url ? `<button type="button" class="storefront-news-open" data-news-url="${escapeHtml(item.url)}">
            ${english ? 'Read full announcement' : 'Czytaj pełne ogłoszenie'}
            <svg><use href="assets/icons.svg#external"></use></svg>
          </button>` : ''}
        </article>`).join('')
      : `<div class="storefront-empty">${english ? 'No developer announcements are available.' : 'Brak dostępnych ogłoszeń twórców.'}</div>`;
    newsHost.querySelectorAll('[data-news-url]').forEach(button => {
      button.addEventListener('click', async () => {
        const response = parseJson(await call('open_steam_announcement', button.dataset.newsUrl), {});
        if (!response.success) toast('error', tr('Ogłoszenie Steam'), response.message || tr('Nie udało się otworzyć przeglądarki'));
      });
    });

    document.getElementById('storefront-loading').hidden = true;
    document.getElementById('storefront-body').hidden = false;
    modal.classList.remove('storefront-loading-state');
    renderStorefrontAction(details);
    document.getElementById('storefront-add-game').disabled = Boolean(details.coming_soon);
    resetStorefrontScroll();
    requestAnimationFrame(resetStorefrontScroll);
    modal.removeAttribute('aria-busy');
  }

  async function openStorefront(app) {
    if (!app || !String(app.app_id || '').match(/^\d+$/)) return;
    const requestSequence = ++state.storefrontSequence;
    const modal = document.getElementById('storefront-modal');
    state.selectedStorefrontApp = app;
    resetStorefrontScroll();
    modal.classList.add('visible');
    modal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('storefront-open');
    const cacheKey = String(app.app_id);
    const cached = state.storefrontCache.get(cacheKey);
    if (cached && Date.now() - cached.storedAt < 10 * 60 * 1000) {
      state.selectedStorefrontApp = {
        ...app,
        ...cached.details,
        name: cached.details.name || app.name,
        source: app.source || cached.details.source,
        providers: app.providers || cached.details.providers,
        available: app.available ?? cached.details.available,
        coming_soon: Boolean(cached.details.coming_soon),
      };
      renderStorefront(state.selectedStorefrontApp);
      return;
    }
    showStorefrontLoading(app);
    try {
      const details = parseJson(await call('get_storefront_details', String(app.app_id)), {});
      if (requestSequence !== state.storefrontSequence) return;
      if (!details.success) throw new Error(details.message || 'Steam nie zwrócił szczegółów gry');
      state.selectedStorefrontApp = {
        ...app,
        ...details,
        name: details.name || app.name,
        source: app.source || details.source,
        providers: app.providers || details.providers,
        available: app.available ?? details.available,
        coming_soon: Boolean(details.coming_soon),
      };
      state.storefrontCache.set(cacheKey, {
        storedAt: Date.now(),
        details: { ...state.selectedStorefrontApp },
      });
      while (state.storefrontCache.size > 48) {
        state.storefrontCache.delete(state.storefrontCache.keys().next().value);
      }
      renderStorefront(state.selectedStorefrontApp);
    } catch (error) {
      if (requestSequence !== state.storefrontSequence) return;
      if (cached?.details) {
        state.selectedStorefrontApp = { ...app, ...cached.details };
        renderStorefront(state.selectedStorefrontApp);
        toast('warning', tr('Dane Steam'), tr('Pokazano ostatnie poprawnie zapisane informacje.'));
        return;
      }
      closeStorefront();
      toast('error', tr('Nie pobrano szczegółów Steam'), error.message || String(error));
    }
  }

  function renderCatalogLoading() {
    const host = document.getElementById('catalog-results');
    const pagination = document.getElementById('catalog-pagination');
    host.setAttribute('aria-busy', 'true');
    host.classList.add('catalog-results-loading');
    let overlay = host.querySelector('.catalog-loading-overlay');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.className = 'catalog-loading-overlay';
      overlay.innerHTML = `
        <span class="catalog-loading-orbit" aria-hidden="true"><i></i></span>
        <strong>${escapeHtml(tr('Wczytywanie gier'))}</strong>
        <small>${escapeHtml(tr('Przygotowujemy następną stronę bez przeładowywania widoku.'))}</small>`;
      host.appendChild(overlay);
    }
    pagination.classList.add('loading');
    pagination.querySelectorAll('button').forEach(button => { button.disabled = true; });
  }

  function finishCatalogLoading() {
    const host = document.getElementById('catalog-results');
    const pagination = document.getElementById('catalog-pagination');
    host.removeAttribute('aria-busy');
    host.classList.remove('catalog-results-loading');
    host.querySelector('.catalog-loading-overlay')?.remove();
    pagination.classList.remove('loading');
  }

  function catalogAvailabilityBadges(app) {
    return app.onlinefix_available
      ? `<span class="onlinefix-availability" title="${escapeHtml(app.onlinefix_title || 'Online-Fix.me')}"><i></i>Online-Fix dostępny</span>`
      : '';
  }

  function catalogMetadataPresentation(app) {
    const metadataPending = !app.metadata_loaded && !app.metadata_failed;
    return {
      metadataPending,
      releaseClass: metadataPending
        ? 'loading'
        : app.coming_soon
          ? 'soon'
          : app.release_date
            ? 'released'
            : 'unknown',
      releaseLabel: metadataPending
        ? 'WCZYTYWANIE DANYCH'
        : app.coming_soon
          ? 'PREMIERA WKRÓTCE'
          : app.release_date
            ? 'JUŻ DOSTĘPNA'
            : 'DATA PREMIERY NIEPODANA',
      releaseDate: metadataPending
        ? 'Pobieranie daty ze Steam…'
        : app.release_date || 'Brak daty premiery',
      developer: (app.developers || [])[0] || (app.publishers || [])[0] || '',
      tags: [...(app.genres || []), ...(app.categories || [])]
        .filter((value, index, values) => value && values.indexOf(value) === index)
        .slice(0, 7),
      availability: app.coming_soon
        ? 'Dodawanie zostanie odblokowane po premierze'
        : app.available
          ? 'Pakiet gotowy do dodania'
          : 'Źródło zostanie wybrane automatycznie',
      selectLabel: app.coming_soon ? 'Jeszcze niewydana' : 'Dodaj grę',
    };
  }

  function patchCatalogCard(app) {
    const card = document.querySelector(`.catalog-card[data-app-id="${app.app_id}"]`);
    if (!card) return false;
    const presentation = catalogMetadataPresentation(app);
    card.classList.toggle('unreleased', Boolean(app.coming_soon));

    const providers = (app.providers || [app.source]).filter(Boolean);
    const badges = card.querySelector('.catalog-badges');
    if (badges) {
      badges.innerHTML = providers
        .map(provider => `<i class="provider-badge ${escapeHtml(provider)}">${escapeHtml(providerLabel(provider))}</i>`)
        .join('')
        + `<span class="catalog-app-id">APP ${escapeHtml(app.app_id)}</span>`;
    }
    const title = card.querySelector('.catalog-title-button');
    if (title) title.textContent = app.name;
    const release = card.querySelector('.release-badge');
    if (release) {
      release.className = `release-badge ${presentation.releaseClass}`;
      release.textContent = presentation.releaseLabel;
    }
    const description = card.querySelector('.catalog-description');
    if (description) {
      description.textContent = app.short_description
        || (presentation.metadataPending
          ? 'Pobieranie opisu, daty premiery i opinii ze Steam…'
          : 'Steam nie udostępnia dodatkowego opisu tej pozycji.');
    }
    const meta = card.querySelector('.catalog-meta-line');
    if (meta) {
      meta.innerHTML = `<span><small>PREMIERA</small><strong>${escapeHtml(presentation.releaseDate)}</strong></span>`
        + (presentation.developer
          ? `<span><small>TWÓRCA</small><strong>${escapeHtml(presentation.developer)}</strong></span>`
          : '');
    }
    const reviewMarkup = catalogReview(app);
    const currentReview = card.querySelector('.catalog-reviews');
    if (reviewMarkup) {
      const template = document.createElement('template');
      template.innerHTML = reviewMarkup.trim();
      const nextReview = template.content.firstElementChild;
      if (currentReview) currentReview.replaceWith(nextReview);
      else meta?.insertAdjacentElement('afterend', nextReview);
    } else {
      currentReview?.remove();
    }
    const tags = card.querySelector('.catalog-tags');
    if (tags) {
      tags.innerHTML = presentation.tags
        .map(value => `<span>${escapeHtml(value)}</span>`)
        .join('');
    }
    const availability = card.querySelector('.catalog-availability > span');
    if (availability) availability.textContent = presentation.availability;
    const select = card.querySelector('[data-select]');
    if (select) {
      select.disabled = Boolean(app.coming_soon);
      select.textContent = presentation.selectLabel;
    }
    return true;
  }

  function renderCatalog() {
    const host = document.getElementById('catalog-results');
    host.removeAttribute('aria-busy');
    host.innerHTML = '';
    if (!state.catalog.length) {
      const query = document.getElementById('app-search').value.trim();
      host.innerHTML = `<div class="catalog-empty"><strong>${query ? 'Brak dopasowań' : 'Brak gier dla tych filtrów'}</strong><span>${query ? 'Spróbuj pełnej nazwy albo AppID.' : 'Usuń jeden z filtrów albo wybierz inne zestawienie.'}</span></div>`;
      renderCatalogPagination();
      return;
    }
    visibleCatalogItems().forEach(app => {
      const card = document.createElement('article');
      card.className = `catalog-card panel${app.coming_soon ? ' unreleased' : ''}`;
      card.dataset.appId = String(app.app_id);
      const providers = (app.providers || [app.source]).filter(Boolean);
      const badges = providers.map(provider => `<i class="provider-badge ${escapeHtml(provider)}">${escapeHtml(providerLabel(provider))}</i>`).join('');
      const ranking = state.discoveryRanking[String(app.app_id)] || {};
      const rankBadge = ranking.rank ? `<b class="catalog-rank">#${escapeHtml(ranking.rank)}</b>` : '';
      const players = ranking.peak_in_game
        ? `<span><b>${escapeHtml(catalogNumber(ranking.peak_in_game))}</b> szczyt graczy</span>`
        : '';
      const presentation = catalogMetadataPresentation(app);
      const tags = presentation.tags
        .map(value => `<span>${escapeHtml(value)}</span>`)
        .join('');
      card.innerHTML = `
        <div class="catalog-image">
          ${rankBadge}
          <span class="release-badge ${presentation.releaseClass}">${escapeHtml(presentation.releaseLabel)}</span>
          <img src="${escapeHtml(app.image_url)}" alt="" loading="lazy" decoding="async">
          <span class="catalog-image-letter">${escapeHtml(app.name.slice(0, 1).toUpperCase())}</span>
        </div>
        <div class="catalog-copy">
          <div class="catalog-badges">${badges}<span class="catalog-app-id">APP ${escapeHtml(app.app_id)}</span></div>
          <h3><button type="button" class="catalog-title-button" data-details>${escapeHtml(app.name)}</button></h3>
          <p class="catalog-description">${escapeHtml(
            app.short_description
            || (presentation.metadataPending
              ? 'Pobieranie opisu, daty premiery i opinii ze Steam…'
              : 'Steam nie udostępnia dodatkowego opisu tej pozycji.')
          )}</p>
          <div class="catalog-meta-line"><span><small>PREMIERA</small><strong>${escapeHtml(presentation.releaseDate)}</strong></span>${presentation.developer ? `<span><small>TWÓRCA</small><strong>${escapeHtml(presentation.developer)}</strong></span>` : ''}</div>
          ${catalogReview(app)}
          <div class="catalog-tags">${tags}</div>
          <div class="catalog-facts">${players}</div>
          <div class="catalog-availability"><span>${escapeHtml(presentation.availability)}</span><div class="onlinefix-badge-slot" aria-live="polite">${catalogAvailabilityBadges(app)}</div></div>
        </div>
        <div class="catalog-actions">
          <button class="ghost" data-store><svg><use href="assets/icons.svg#external"></use></svg>Sklep Steam</button>
          <button class="primary" data-select ${app.coming_soon ? 'disabled' : ''}>${escapeHtml(presentation.selectLabel)}</button>
        </div>`;
      const image = card.querySelector('img');
      const imageSources = [
        app.image_url,
        `https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/${app.app_id}/capsule_616x353.jpg`,
        app.fallback_image_url,
      ].filter((value, index, values) => value && values.indexOf(value) === index);
      let imageIndex = 0;
      image.addEventListener('load', () => card.querySelector('.catalog-image').classList.add('loaded'), { once: true });
      image.addEventListener('error', () => {
        imageIndex += 1;
        if (imageSources[imageIndex]) image.src = imageSources[imageIndex];
        else image.style.display = 'none';
      });
      card.querySelector('[data-store]').addEventListener('click', event => { event.stopPropagation(); call('open_store_page', app.app_id); });
      card.querySelector('[data-details]').addEventListener('click', event => {
        event.stopPropagation();
        const current = state.catalog.find(
          item => String(item.app_id) === String(app.app_id)
        ) || app;
        void openStorefront(current);
      });
      card.querySelector('[data-select]').addEventListener('click', async event => {
        event.stopPropagation();
        const current = state.catalog.find(
          item => String(item.app_id) === String(app.app_id)
        ) || app;
        if (current.coming_soon) return;
        await queueSelectedApp(current, event.currentTarget);
      });
      host.appendChild(card);
    });
    renderCatalogPagination();
  }

  async function enrichVisibleCatalog(sequence, options = {}) {
    const shouldRender = options.render !== false;
    const visible = visibleCatalogItems();
    const appIds = visible
      .filter(app => !app.metadata_loaded && !app.metadata_failed)
      .map(app => String(app.app_id));
    if (!appIds.length) return false;
    try {
      const response = parseJson(
        await call('get_catalog_metadata', JSON.stringify(appIds)),
        { success: false, items: {} }
      );
      if (sequence !== state.catalogSearchSequence || !response.success) return false;
      const metadata = response.items || {};
      state.catalog = state.catalog.map(app => {
        const details = metadata[String(app.app_id)];
        if (!details) {
          const stable = stableCatalogItem(app);
          return stable.metadata_loaded ? stable : { ...stable, metadata_failed: true };
        }
        return {
          ...app,
          ...details,
          source: app.source,
          providers: app.providers,
          download_provider: app.download_provider,
          available: app.available,
          manifest_available: app.manifest_available,
          manifest_count: app.manifest_count,
          last_updated: app.last_updated,
        };
      });
      rememberCatalog(state.catalog);
      if (shouldRender) {
        visibleCatalogItems().forEach(patchCatalogCard);
        void annotateOnlineFixAvailability(sequence, visibleCatalogItems());
      }
      return true;
    } catch (_) {
      // Metadane są ulepszeniem kart; wyszukiwanie pozostaje użyteczne offline.
      return false;
    }
  }

  async function annotateOnlineFixAvailability(sequence, apps) {
    const visible = (apps || [])
      .filter(app => !app.onlinefix_available)
      .slice(0, state.catalogPageSize)
      .map(app => ({ app_id: app.app_id, name: app.name }));
    if (!visible.length) return;
    try {
      const response = parseJson(await call('check_online_fix_availability', JSON.stringify(visible)), { items: [] });
      if (sequence !== state.catalogSearchSequence) return;
      (response.items || []).forEach(item => {
        const catalogApp = state.catalog.find(
          app => String(app.app_id) === String(item.app_id)
        );
        if (catalogApp) {
          Object.assign(catalogApp, {
            onlinefix_available: Boolean(item.available),
            onlinefix_title: item.title || '',
            onlinefix_url: item.url || '',
          });
          state.catalogIndex.set(String(item.app_id), catalogApp);
        }
        const card = document.querySelector(`.catalog-card[data-app-id="${item.app_id}"]`);
        const slot = card?.querySelector('.onlinefix-badge-slot');
        if (!slot) return;
        slot.innerHTML = catalogAvailabilityBadges(catalogApp || {});
      });
    } catch (_) {
      // Dostępność fixa jest dodatkiem; katalog musi pozostać szybki offline.
    }
  }

  async function refreshCatalogApp(app, button) {
    const original = button.textContent;
    button.disabled = true;
    button.textContent = 'Sprawdzanie...';
    try {
      const result = parseJson(await call('refresh_catalog_app', app.app_id, app.name));
      if (result.item) {
        const refreshed = result.item;
        state.catalog = state.catalog.map(item => {
          if (String(item.app_id) !== String(refreshed.app_id)) return item;
          return refreshed.metadata_loaded ? refreshed : {
            ...item,
            ...refreshed,
            release_date: item.release_date,
            coming_soon: item.coming_soon,
            short_description: item.short_description,
            developers: item.developers,
            publishers: item.publishers,
            genres: item.genres,
            categories: item.categories,
            recommendations: item.recommendations,
            metadata_loaded: item.metadata_loaded,
          };
        });
        state.catalogIndex.set(
          String(refreshed.app_id),
          state.catalog.find(item => String(item.app_id) === String(refreshed.app_id))
        );
        renderCatalog();
        void annotateOnlineFixAvailability(state.catalogSearchSequence, visibleCatalogItems());
      }
      toast(
        result.available ? 'success' : 'info',
        result.available ? 'Pakiet znaleziony' : result.manifest_only ? 'Znaleziono same manifesty' : 'Pakiet niedostępny',
        result.message,
        result.warnings || [],
      );
    } catch (error) {
      toast('error', 'Nie udało się sprawdzić pakietu', error.message || String(error));
    } finally {
      if (button.isConnected) {
        button.disabled = false;
        button.textContent = original;
      }
    }
  }

  function renderQueue() {
    const host = document.getElementById('queue-list');
    const empty = document.getElementById('queue-empty');
    host.innerHTML = '';
    empty.classList.toggle('visible', state.installQueue.length === 0);
    state.installQueue.forEach(item => {
      const row = document.createElement('article');
      row.className = 'queue-item';
      const statusLabels = { pending: 'OCZEKUJE', sent: 'GOTOWE', failed: 'BŁĄD' };
      row.innerHTML = `<div class="queue-thumb"><span>${escapeHtml(String(item.name || 'G').slice(0, 1).toUpperCase())}</span><img src="${escapeHtml(item.image_url || '')}" alt="" loading="lazy" decoding="async"></div><div class="queue-copy"><strong>${escapeHtml(item.name)}</strong><span>App ${escapeHtml(item.app_id)} - ${escapeHtml(String(item.source || 'steam').toUpperCase())}</span><p>${escapeHtml(item.message || 'W kolejce')}</p></div><div class="queue-status ${escapeHtml(item.status)}">${escapeHtml(statusLabels[item.status] || String(item.status || 'pending').toUpperCase())}</div>`;
      const image = row.querySelector('img');
      const imageSources = [
        item.image_url,
        `https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/${item.app_id}/capsule_616x353.jpg`,
        `https://cdn.cloudflare.steamstatic.com/steam/apps/${item.app_id}/header.jpg`,
      ].filter((value, index, values) => value && values.indexOf(value) === index);
      let imageIndex = 0;
      image.addEventListener('load', () => row.querySelector('.queue-thumb').classList.add('loaded'), { once: true });
      image.addEventListener('error', () => {
        imageIndex += 1;
        if (imageSources[imageIndex]) image.src = imageSources[imageIndex];
        else image.style.display = 'none';
      });
      host.appendChild(row);
    });
  }

  async function loadInstallQueue() {
    state.installQueue = parseJson(await call('get_install_queue'), []);
    renderQueue();
  }

  async function queueSelectedApp(app = state.selectedCatalogApp, trigger = null) {
    if (!app) {
      toast('error', 'Nie wybrano gry', 'Najpierw wybierz wynik');
      return false;
    }
    if (app.coming_soon) {
      toast('info', 'Gra jeszcze niewydana', `Premiera: ${app.release_date || 'termin nieznany'}`);
      return false;
    }
    state.selectedCatalogApp = app;
    const buttons = [trigger].filter(Boolean);
    const labels = buttons.map(button => button.textContent);
    buttons.forEach(button => {
      button.disabled = true;
      button.textContent = 'Dodawanie...';
    });
    toast('info', 'Dodawanie gry', `Pobieranie i import App ${app.app_id}...`);
    let success = false;
    try {
      const result = parseJson(await call('queue_install', JSON.stringify(app)));
      toast(result.success ? 'success' : 'error', result.success ? 'Gra dodana' : 'Dodawanie nieudane', result.message);
      await loadInstallQueue();
      if (result.success) {
        success = true;
        scheduleLibraryProfileSync();
        await refreshAll();
        const onlineFixApp = await resolveOnlineFixForApp(app);
        if (onlineFixApp.onlinefix_available) openOnlineFixAutomationOffer(onlineFixApp);
      }
    } catch (error) {
      toast('error', 'Dodawanie nieudane', error.message || String(error));
    } finally {
      buttons.forEach((button, index) => {
        button.disabled = false;
        button.textContent = labels[index];
      });
    }
    return success;
  }

  async function updateStorefrontGame(app, trigger) {
    if (!app || !managedStorefrontGame(app.app_id)) return false;
    const original = trigger.textContent;
    trigger.disabled = true;
    trigger.textContent = tr('Aktualizowanie gry…');
    toast('info', tr('Aktualizacja gry'), `${tr('Pobieranie najnowszego pakietu')} · App ${app.app_id}`);
    try {
      const result = parseJson(await call('redownload_game', String(app.app_id)), {});
      toast(
        result.success ? 'success' : 'error',
        result.success ? tr('Gra zaktualizowana') : tr('Aktualizacja nieudana'),
        result.message || '',
        result.warnings || [],
      );
      await loadInstallQueue();
      if (result.success) {
        scheduleLibraryProfileSync();
        closeStorefront();
        await refreshAll();
        return true;
      }
      return false;
    } catch (error) {
      toast('error', tr('Aktualizacja nieudana'), error.message || String(error));
      return false;
    } finally {
      trigger.disabled = false;
      trigger.textContent = original;
    }
  }

  function setCatalogSearchState(label, loading = false) {
    const node = document.getElementById('catalog-search-state');
    node.textContent = label;
    node.classList.toggle('loading', loading);
    const shell = node.closest('.catalog-search');
    shell?.classList.toggle('searching', loading);
    if (loading) shell?.setAttribute('aria-busy', 'true');
    else shell?.removeAttribute('aria-busy');
  }

  const discoveryLabels = {
    browse: ['Wszystkie gry', 'Łącz dowolne gatunki, style i tryby rozgrywki.'],
  };

  function renderCatalogFilterState() {
    const count = state.catalogFilters.size;
    document.getElementById('catalog-filter-count').textContent = `${count} ${count === 1 ? 'FILTR' : 'FILTRÓW'}`;
    document.getElementById('catalog-filter-clear').disabled = count === 0;
    document.querySelectorAll('[data-catalog-filter]').forEach(button => {
      const active = state.catalogFilters.has(button.dataset.catalogFilter);
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', active ? 'true' : 'false');
    });
  }

  function catalogDiscoveryCacheKey(section, page) {
    return JSON.stringify({
      section,
      page: Math.max(1, Number(page || 1)),
      pageSize: state.catalogPageSize,
      filters: [...state.catalogFilters].sort(),
      sort: state.catalogSort,
      query: document.getElementById('app-search').value.trim().toLocaleLowerCase(),
      language: state.settings.language || 'pl',
    });
  }

  function rememberCatalogDiscovery(key, response) {
    state.catalogDiscoveryCache.set(key, { storedAt: Date.now(), response });
    while (state.catalogDiscoveryCache.size > 72) {
      state.catalogDiscoveryCache.delete(state.catalogDiscoveryCache.keys().next().value);
    }
  }

  function sortCatalogPageItems(items, response = {}) {
    const values = [...(items || [])];
    const sort = state.catalogSort || 'relevance';
    const filters = Array.isArray(response.filters) ? response.filters : [];
    const onlineFixOnly = filters.length === 1 && filters.includes('onlinefix');
    // Steam already applies global ordering. Re-sorting normal/combined pages
    // locally would corrupt that order, especially for localized release dates.
    if (sort === 'relevance' || !onlineFixOnly || response.global_sort) return values;
    const rating = app => {
      const total = Math.max(0, Number(app.review_total || 0));
      const percent = Math.max(0, Math.min(100, Number(app.review_positive_percent || 0)));
      if (!total) return -1;
      const confidence = 2 ** (-Math.log10(total + 1));
      return percent - (percent - 50) * confidence;
    };
    const release = app => {
      const parsed = Date.parse(String(app.release_date || ''));
      return Number.isFinite(parsed) ? parsed : 0;
    };
    const price = app => {
      if (app.is_free) return 0;
      const normalized = String(app.price || '')
        .replace(/[^\d,.\-]/g, '')
        .replace(',', '.');
      const parsed = Number.parseFloat(normalized);
      return Number.isFinite(parsed) ? parsed : Number.POSITIVE_INFINITY;
    };
    values.sort((left, right) => {
      if (sort === 'reviews') {
        return rating(right) - rating(left)
          || Number(right.review_total || 0) - Number(left.review_total || 0)
          || String(left.name || '').localeCompare(String(right.name || ''));
      }
      if (sort === 'release') {
        return release(right) - release(left)
          || String(left.name || '').localeCompare(String(right.name || ''));
      }
      if (sort === 'price') {
        return price(left) - price(right)
          || String(left.name || '').localeCompare(String(right.name || ''));
      }
      if (sort === 'name') {
        return String(left.name || '').localeCompare(
          String(right.name || ''),
          state.settings.language === 'en' ? 'en' : 'pl',
          { sensitivity: 'base' }
        );
      }
      return 0;
    });
    return values;
  }

  async function hydrateCatalogDiscoveryResponse(response, sequence) {
    const items = Array.isArray(response?.items) ? response.items : [];
    const withFailedMetadata = values => values.map(app => {
      const stable = stableCatalogItem(app);
      return stable.metadata_loaded ? stable : { ...stable, metadata_failed: true };
    });
    const pendingIds = items
      .filter(app => !app.metadata_loaded)
      .map(app => String(app.app_id))
      .filter(appId => /^\d+$/.test(appId));
    if (!pendingIds.length) {
      return { ...response, items: sortCatalogPageItems(items, response) };
    }
    try {
      const metadataResponse = parseJson(
        await call('get_catalog_metadata', JSON.stringify(pendingIds)),
        { success: false, items: {} }
      );
      if (sequence !== state.catalogSearchSequence || !metadataResponse.success) {
        return sequence !== state.catalogSearchSequence
          ? response
          : {
              ...response,
              items: sortCatalogPageItems(withFailedMetadata(items), response),
            };
      }
      const metadata = metadataResponse.items || {};
      const hydratedItems = items.map(app => {
        const details = metadata[String(app.app_id)];
        if (!details) {
          const stable = stableCatalogItem(app);
          return stable.metadata_loaded
            ? stable
            : { ...stable, metadata_failed: true };
        }
        return {
          ...app,
          ...details,
          source: app.source,
          providers: app.providers,
          download_provider: app.download_provider,
          available: app.available,
          manifest_available: app.manifest_available,
          manifest_count: app.manifest_count,
          last_updated: app.last_updated,
          onlinefix_available: app.onlinefix_available,
          onlinefix_title: app.onlinefix_title,
        };
      });
      return {
        ...response,
        items: sortCatalogPageItems(hydratedItems, response),
      };
    } catch (_) {
      return {
        ...response,
        items: sortCatalogPageItems(withFailedMetadata(items), response),
      };
    }
  }

  function applyCatalogDiscoveryResponse(response, sequence, clientCached = false) {
    if (sequence !== state.catalogSearchSequence) return false;
    state.catalog = (response.items || []).map(stableCatalogItem);
    state.catalogPages = Number(response.pages || 1);
    state.discoveryRanking = response.ranking || {};
    if (Number(response.onlinefix_total || 0)) {
      state.onlineFixCatalogTotal = Number(response.onlinefix_total);
      const detail = document.getElementById('onlinefix-filter-detail');
      if (detail) {
        detail.textContent = `${catalogNumber(state.onlineFixCatalogTotal)} ${state.settings.language === 'en' ? 'games · combine with any other filter' : 'gier · połącz z dowolnym innym filtrem'}`;
      }
    }
    rememberCatalog(state.catalog);
    renderCatalog();
    void annotateOnlineFixAvailability(sequence, visibleCatalogItems());
    const cacheLabel = clientCached || response.cached || response.stale;
    document.getElementById('catalog-provider').textContent = state.catalogFilters.has('onlinefix')
      ? (cacheLabel ? 'Online-Fix + Steam · cache' : 'Online-Fix + Steam')
      : (cacheLabel ? 'Steam · cache' : 'Steam · na żywo');
    setCatalogSearchState(response.success ? `${response.total || state.catalog.length} GIER` : 'OFFLINE');
    if (!response.success) {
      toast('error', 'Nie udało się pobrać rankingu', response.message || 'Steam jest chwilowo niedostępny.');
    }
    return true;
  }

  async function loadCatalogDiscovery(section = state.discoverySection, page = 1) {
    const previous = {
      catalog: state.catalog,
      page: state.catalogPage,
      pages: state.catalogPages,
      ranking: state.discoveryRanking,
    };
    const sequence = ++state.catalogSearchSequence;
    state.catalogDiscoveryBusy = sequence;
    state.catalogMode = 'discovery';
    state.discoverySection = section;
    state.catalogPage = Math.max(1, Number(page || 1));
    const cacheKey = catalogDiscoveryCacheKey(section, state.catalogPage);
    const cachedPage = state.catalogDiscoveryCache.get(cacheKey);
    document.getElementById('discovery-browser').hidden = false;
    renderCatalogFilterState();
    const labels = state.catalogFilters.size
      ? ['Wyniki dla połączonych filtrów', `${state.catalogFilters.size} warunki muszą być spełnione jednocześnie.`]
      : discoveryLabels.browse;
    document.getElementById('discovery-title').textContent = labels[0];
    document.getElementById('discovery-subtitle').textContent = labels[1];
    setCatalogSearchState('POBIERANIE', true);
    renderCatalogLoading();
    if (cachedPage && Date.now() - cachedPage.storedAt < 5 * 60 * 1000) {
      const hydrated = await hydrateCatalogDiscoveryResponse(
        cachedPage.response,
        sequence
      );
      if (sequence !== state.catalogSearchSequence) return;
      rememberCatalogDiscovery(cacheKey, hydrated);
      state.catalogDiscoveryBusy = false;
      applyCatalogDiscoveryResponse(hydrated, sequence, true);
      finishCatalogLoading();
      return;
    }
    try {
      const response = parseJson(
        await call(
          'get_catalog_discovery',
          section,
          state.catalogPage,
          state.catalogPageSize,
          JSON.stringify([...state.catalogFilters]),
          state.catalogSort,
          document.getElementById('app-search').value.trim()
        ),
        { success: false, items: [] }
      );
      if (sequence !== state.catalogSearchSequence) return;
      if (!response.success) {
        throw new Error(response.message || 'Steam jest chwilowo niedostępny.');
      }
      const hydrated = await hydrateCatalogDiscoveryResponse(response, sequence);
      if (sequence !== state.catalogSearchSequence) return;
      rememberCatalogDiscovery(cacheKey, hydrated);
      state.catalogDiscoveryBusy = false;
      applyCatalogDiscoveryResponse(hydrated, sequence);
    } catch (error) {
      if (sequence !== state.catalogSearchSequence) return;
      // Never display results belonging to a different filter as if they
      // matched the current request. A matching client cache is handled above.
      state.catalog = [];
      state.catalogPages = 1;
      state.discoveryRanking = {};
      state.catalogDiscoveryBusy = false;
      renderCatalog();
      setCatalogSearchState('OFFLINE');
      if (Date.now() - state.catalogErrorToastAt > 60 * 1000) {
        state.catalogErrorToastAt = Date.now();
        const message = error.message || String(error);
        toast(
          /ograniczy|HTTP (401|403|429)|Too Many/i.test(message) ? 'info' : 'error',
          'Steam chwilowo zwolnił odpowiedzi',
          message,
        );
      }
    } finally {
      if (sequence === state.catalogSearchSequence) {
        finishCatalogLoading();
      }
      if (state.catalogDiscoveryBusy === sequence) state.catalogDiscoveryBusy = false;
    }
  }

  async function loadCatalogSuggestions() {
    if (document.getElementById('app-search').value.trim()) return;
    await loadCatalogDiscovery('browse', 1);
  }

  function insightReleaseDate(value) {
    if (!value) return '';
    const date = new Date(`${value}T12:00:00Z`);
    if (Number.isNaN(date.getTime())) return String(value);
    return date.toLocaleDateString(
      state.settings.language === 'en' ? 'en-US' : 'pl-PL',
      { day: 'numeric', month: 'short' },
    );
  }

  function insightMetric(item) {
    const english = state.settings.language === 'en';
    const rank = `#${Number(item.rank || 0) || '—'}`;
    if (item.metric === 'players') {
      return {
        primary: catalogNumber(item.current_players || item.value),
        secondary: `${english ? '24h peak' : 'szczyt 24 h'} ${catalogNumber(item.peak_24h)}`,
      };
    }
    if (item.metric === 'trending') {
      return {
        primary: catalogNumber(item.current_players || item.value),
        secondary: item.trend_delta
          ? `+${Number(item.trend_delta)} ${english ? 'places' : 'miejsc'}`
          : (item.trend_new ? (english ? 'new in chart' : 'nowość w rankingu') : rank),
      };
    }
    if (item.metric === 'reviews') {
      const rating = Number(item.rating || item.value || 0);
      return {
        primary: rating ? `${rating.toFixed(2)}%` : rank,
        secondary: item.review_total
          ? `${catalogNumber(item.review_total)} ${english ? 'reviews' : 'opinii'}`
          : '',
      };
    }
    if (item.metric === 'release') {
      return {
        primary: catalogNumber(item.peak_24h || item.value) || rank,
        secondary: insightReleaseDate(item.release_date),
      };
    }
    return { primary: rank, secondary: '' };
  }

  function renderCatalogInsights(response = state.catalogInsights) {
    const sections = response?.sections || {};
    const targets = {
      most_played: 'insight-most-played',
      trending: 'insight-trending',
      popular_releases: 'insight-popular-releases',
      hot_releases: 'insight-hot-releases',
    };
    Object.entries(targets).forEach(([key, id]) => {
      const host = document.getElementById(id);
      if (!host) return;
      const items = (sections[key] || []).slice(0, 15);
      host.innerHTML = '';
      if (!items.length) {
        host.innerHTML = '<div class="steam-insight-empty">Dane chwilowo niedostępne</div>';
        return;
      }
      items.forEach((item, index) => {
        const button = document.createElement('button');
        const metric = insightMetric(item);
        button.className = 'steam-insight-row';
        button.type = 'button';
        button.style.setProperty('--row-index', String(index));
        button.innerHTML = `
          <span class="steam-insight-rank">${escapeHtml(item.rank || index + 1)}</span>
          <span class="steam-insight-thumb">
            <i>${escapeHtml(String(item.name || 'G').slice(0, 1).toUpperCase())}</i>
            <img src="${escapeHtml(item.image_url || '')}" alt="" loading="lazy" decoding="async">
          </span>
          <span class="steam-insight-copy"><strong>${escapeHtml(item.name || `App ${item.app_id}`)}</strong><small>App ${escapeHtml(item.app_id)}</small></span>
          <span class="steam-insight-metric"><b>${escapeHtml(metric.primary)}</b><small>${escapeHtml(metric.secondary)}</small></span>`;
        const image = button.querySelector('img');
        const sources = [
          item.image_url,
          item.fallback_image_url,
          `https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/${item.app_id}/capsule_231x87.jpg`,
        ].filter((value, position, values) => value && values.indexOf(value) === position);
        let sourceIndex = 0;
        image.addEventListener('load', () => button.querySelector('.steam-insight-thumb').classList.add('loaded'), { once: true });
        image.addEventListener('error', () => {
          sourceIndex += 1;
          if (sources[sourceIndex]) image.src = sources[sourceIndex];
          else image.style.display = 'none';
        });
        button.addEventListener('click', () => void openStorefront({
          ...item,
          source: 'steam',
          providers: ['steam'],
        }));
        host.appendChild(button);
      });
    });
  }

  function renderCatalogInsightsLoading() {
    ['insight-most-played', 'insight-trending', 'insight-popular-releases', 'insight-hot-releases'].forEach(id => {
      const host = document.getElementById(id);
      if (!host) return;
      host.innerHTML = Array.from({ length: 10 }, (_, index) => `
        <div class="steam-insight-row steam-insight-row-loading" style="--row-index:${index}">
          <span></span><i></i><em></em><b></b>
        </div>`).join('');
    });
  }

  async function loadCatalogInsights(force = false) {
    if (state.catalogInsightsBusy) return;
    if (
      !force
      && state.catalogInsights
      && Date.now() - state.catalogInsightsLoadedAt < 5 * 60 * 1000
    ) {
      renderCatalogInsights();
      return;
    }
    state.catalogInsightsBusy = true;
    const stateNode = document.getElementById('steam-insights-state');
    const refresh = document.getElementById('steam-insights-refresh');
    if (refresh) refresh.disabled = true;
    if (!state.catalogInsights) renderCatalogInsightsLoading();
    if (stateNode) stateNode.textContent = 'Pobieranie zbiorczych rankingów Steam…';
    try {
      const response = parseJson(
        await call('get_catalog_insights', 15, Boolean(force)),
        { success: false, sections: {} }
      );
      if (!response.success) throw new Error(response.message || 'Brak danych Steam');
      state.catalogInsights = response;
      state.catalogInsightsLoadedAt = Date.now();
      renderCatalogInsights(response);
      if (stateNode) {
        const fetched = response.fetched_at
          ? new Date(Number(response.fetched_at) * 1000).toLocaleTimeString(
            state.settings.language === 'en' ? 'en-US' : 'pl-PL',
            { hour: '2-digit', minute: '2-digit' },
          )
          : '';
        const source = response.source || 'Valve Steam Charts';
        stateNode.textContent = response.cached
          ? `${source} · pamięć 5 min${fetched ? ` · ${fetched}` : ''}`
          : `${source} · odświeżono${fetched ? ` ${fetched}` : ''}`;
      }
    } catch (error) {
      if (state.catalogInsights) renderCatalogInsights();
      if (stateNode) stateNode.textContent = `Rankingi chwilowo niedostępne · ${error.message || error}`;
    } finally {
      state.catalogInsightsBusy = false;
      if (refresh) refresh.disabled = false;
    }
  }

  function applyCatalogSearchItems(items, query, sequence) {
    if (
      sequence !== state.catalogSearchSequence
      || state.catalogSearchQuery !== query
      || document.getElementById('app-search').value.trim() !== query
    ) return false;
    const previousIds = state.catalog.map(app => String(app.app_id));
    const previous = new Map(
      state.catalog.map(app => [String(app.app_id), app])
    );
    const next = (items || []).map(app => ({
      ...(previous.get(String(app.app_id)) || {}),
      ...app,
    }));
    const nextIds = next.map(app => String(app.app_id));
    const sameOrder = previousIds.length === nextIds.length
      && previousIds.every((appId, index) => appId === nextIds[index]);
    state.catalog = next;
    state.catalogMode = 'search';
    state.catalogPage = 1;
    state.catalogPages = Math.max(
      1,
      Math.ceil(state.catalog.length / state.catalogPageSize)
    );
    rememberCatalog(state.catalog);
    if (sameOrder) {
      visibleCatalogItems().forEach(patchCatalogCard);
      renderCatalogPagination();
    } else {
      renderCatalog();
    }
    return true;
  }

  async function searchCatalogCachedLive(query, sequence) {
    try {
      const response = parseJson(
        await call('search_catalog_cached', query),
        { success: false, items: [] }
      );
      if (
        sequence !== state.catalogSearchSequence
        || state.catalogSearchQuery !== query
        || document.getElementById('app-search').value.trim() !== query
      ) return;
      const items = response.items || [];
      if (!items.length) {
        setCatalogSearchState('SZUKANIE STEAM', true);
        return;
      }
      if (applyCatalogSearchItems(items, query, sequence)) {
        setCatalogSearchState(`${items.length} LOKALNIE · STEAM…`, true);
        void annotateOnlineFixAvailability(sequence, visibleCatalogItems());
      }
    } catch (_) {
      // Lokalny indeks jest tylko natychmiastową warstwą wyszukiwania.
    }
  }

  async function searchCatalog(query, sequence) {
    query = String(query || '').trim();
    if (!query) return loadCatalogSuggestions();
    if (
      sequence !== state.catalogSearchSequence
      || document.getElementById('app-search').value.trim() !== query
    ) return;
    state.catalogMode = 'search';
    state.catalogPage = 1;
    state.discoveryRanking = {};
    state.catalogSearchQuery = query;
    document.getElementById('discovery-browser').hidden = true;
    setCatalogSearchState('SZUKANIE STEAM', true);
    try {
      const response = parseJson(await call('search_catalog_live', query));
      if (
        sequence !== state.catalogSearchSequence
        || state.catalogSearchQuery !== query
        || document.getElementById('app-search').value.trim() !== query
      ) return;
      applyCatalogSearchItems(response.items || [], query, sequence);
      void enrichVisibleCatalog(sequence);
      void annotateOnlineFixAvailability(sequence, visibleCatalogItems());
      const elapsed = Number(response.elapsed_ms || 0);
      document.getElementById('catalog-provider').textContent =
        elapsed > 0 ? `Steam · ${elapsed} ms` : 'Steam + indeks lokalny';
      setCatalogSearchState(response.success ? `${state.catalog.length} WYNIKÓW` : 'BŁĄD');
    } catch (_) {
      if (sequence === state.catalogSearchSequence) setCatalogSearchState('OFFLINE');
    }
  }

  async function handleCatalogInput() {
    const query = document.getElementById('app-search').value.trim();
    clearTimeout(state.catalogLocalSearchTimer);
    clearTimeout(state.catalogSearchTimer);
    const sequence = ++state.catalogSearchSequence;
    state.catalogSearchQuery = query;
    if (state.catalogFilters.size) {
      if (query.length === 1 && !/^\d$/.test(query)) {
        setCatalogSearchState('MIN. 2 ZNAKI');
        return;
      }
      setCatalogSearchState(query ? 'WPISYWANIE…' : 'POBIERANIE', true);
      state.catalogSearchTimer = setTimeout(
        () => {
          if (
            sequence !== state.catalogSearchSequence
            || document.getElementById('app-search').value.trim() !== query
          ) return;
          void loadCatalogDiscovery('browse', 1);
        },
        query ? 360 : 0
      );
      return;
    }
    if (!query) {
      return loadCatalogSuggestions();
    }
    if (query.length < 2 && !/^\d+$/.test(query)) {
      setCatalogSearchState('MIN. 2 ZNAKI');
      return;
    }

    state.catalogMode = 'search';
    state.catalogPage = 1;
    state.discoveryRanking = {};
    document.getElementById('discovery-browser').hidden = true;
    setCatalogSearchState('SZUKANIE LOKALNE', true);
    state.catalogLocalSearchTimer = setTimeout(
      () => void searchCatalogCachedLive(query, sequence),
      45
    );
    state.catalogSearchTimer = setTimeout(
      () => void searchCatalog(query, sequence),
      240
    );
  }

  async function loadPluginStatus() {
    const status = parseJson(await call('get_plugin_status'));
    const pill = document.getElementById('plugin-state');
    pill.textContent = status.opensteamtool ? 'RUNTIME AKTYWNY' : 'RUNTIME NIEDOSTĘPNY';
    pill.className = `pill ${status.opensteamtool ? 'purple' : 'gray'}`;
  }

  function formatBytes(value) {
    const bytes = Number(value || 0);
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)} KB`;
    if (bytes < 1024 ** 3) return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
    return `${(bytes / 1024 ** 3).toFixed(2)} GB`;
  }

  function normalizeWorkshopAutomation(payload = {}, workshopStatus = null) {
    const source = payload?.automation || payload?.data?.automation || payload?.data || payload || {};
    const statusHasEnabled = workshopStatus && Object.prototype.hasOwnProperty.call(workshopStatus, 'auto_sync_enabled');
    const sourceHasEnabled = Object.prototype.hasOwnProperty.call(source, 'auto_sync_enabled') || Object.prototype.hasOwnProperty.call(source, 'enabled');
    const enabled = sourceHasEnabled
      ? Boolean(source.auto_sync_enabled ?? source.enabled)
      : statusHasEnabled
        ? Boolean(workshopStatus.auto_sync_enabled)
        : false;
    const failed = payload?.success === false;
    return {
      enabled,
      running: Boolean(source.running),
      state: String(source.state || (enabled ? (source.running ? 'listening' : 'ready') : 'disabled')).toLowerCase(),
      last_scan: source.last_scan || '',
      last_success: source.last_success || '',
      last_error: source.last_error || (failed ? payload.message || 'Nieznany błąd' : ''),
      current_action: source.current_action || '',
      imported_count: Number(source.imported_count || 0),
      updated_count: Number(source.updated_count || 0),
    };
  }

  function formatWorkshopTime(value) {
    if (!value) return '—';
    let timestamp = value;
    if (typeof timestamp === 'number' && timestamp > 0 && timestamp < 1e12) timestamp *= 1000;
    const date = new Date(timestamp);
    if (Number.isNaN(date.getTime())) return '—';
    const locale = state.settings.language === 'en' ? 'en-US' : 'pl-PL';
    return date.toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }

  function renderWorkshopAutomation(payload = {}, workshopStatus = state.workshopStatus) {
    const automation = normalizeWorkshopAutomation(payload, workshopStatus);
    const card = document.getElementById('workshop-automation');
    const title = document.getElementById('workshop-automation-title');
    const detail = document.getElementById('workshop-automation-detail');
    const meta = document.getElementById('workshop-automation-meta');
    const badge = document.getElementById('workshop-automation-badge');
    if (!card || !title || !detail || !meta || !badge) return;

    const rawState = automation.state;
    let visualState = 'listening';
    let titleText = 'Nasłuchuje Steam Workshop';
    let detailText = automation.current_action || 'Czekam na nowe subskrypcje i zakończone pobrania Steam.';
    let badgeText = 'NASŁUCHUJE';
    if (rawState.includes('conflict')) {
      visualState = 'attention';
      titleText = 'Sprawdź zmieniony mod';
      detailText = automation.current_action || 'Pliki moda w grze różnią się od bezpiecznej kopii. KillzoneTools niczego nie nadpisał.';
      badgeText = 'UWAGA';
    } else if (
      automation.last_error
      || rawState.includes('error')
      || rawState.includes('fail')
      || rawState.includes('paused')
      || (automation.enabled && !automation.running)
    ) {
      visualState = 'error';
      titleText = 'Automatyczny import zatrzymany';
      detailText = automation.last_error || automation.current_action || 'Sprawdź konfigurację Workshop i spróbuj ponownie.';
      badgeText = 'BŁĄD';
    } else if (!automation.enabled) {
      visualState = 'disabled';
      titleText = 'Automatyczny import wyłączony';
      detailText = 'Włącz go raz, a nowe mody będą trafiać do gry bez ręcznego skanowania.';
      badgeText = 'WYŁĄCZONY';
    } else if (rawState.includes('download') || rawState.includes('steam')) {
      visualState = 'downloading';
      titleText = 'Steam pobiera mod';
      detailText = automation.current_action || 'Import rozpocznie się automatycznie po zakończeniu pobierania.';
      badgeText = 'STEAM POBIERA';
    } else if (rawState.includes('import') || rawState.includes('copy') || rawState.includes('sync') || rawState.includes('update')) {
      visualState = 'importing';
      titleText = 'Importuję mod do gry';
      detailText = automation.current_action || 'Kopiuję pliki do folderu Workshop i aktualizuję ich nazwy.';
      badgeText = 'IMPORTUJE';
    } else if (rawState.includes('done') || rawState.includes('success') || rawState.includes('complete') || rawState.includes('ready')) {
      visualState = 'done';
      titleText = 'Mody są zsynchronizowane';
      const summary = [];
      if (automation.imported_count) summary.push(`Zaimportowano: ${automation.imported_count}`);
      if (automation.updated_count) summary.push(`Zaktualizowano: ${automation.updated_count}`);
      detailText = summary.join(' · ') || automation.current_action || 'Wszystkie pobrane mody są już w grze.';
      badgeText = 'GOTOWE';
    }

    card.dataset.state = visualState;
    title.textContent = titleText;
    detail.textContent = detailText;
    badge.textContent = badgeText;
    meta.textContent = `Ostatni skan: ${formatWorkshopTime(automation.last_scan || automation.last_success)}`;
  }

  function stopWorkshopAutomationPolling() {
    if (state.workshopPollTimer) clearTimeout(state.workshopPollTimer);
    state.workshopPollTimer = null;
    state.workshopPollAppId = '';
    state.workshopPollCounts = '';
    state.workshopPollGeneration += 1;
  }

  function scheduleWorkshopAutomationPolling(appId, generation, delay = 4600) {
    if (state.page !== 'workshop' || state.workshopPollGeneration !== generation || state.workshopPollAppId !== String(appId)) return;
    state.workshopPollTimer = setTimeout(() => pollWorkshopAutomation(appId, generation), delay);
  }

  function startWorkshopAutomationPolling(appId) {
    stopWorkshopAutomationPolling();
    if (!appId || state.page !== 'workshop') return;
    state.workshopPollAppId = String(appId);
    const initial = normalizeWorkshopAutomation(state.workshopStatus?.automation || {}, state.workshopStatus);
    state.workshopPollCounts = `${initial.imported_count}:${initial.updated_count}`;
    const generation = state.workshopPollGeneration;
    scheduleWorkshopAutomationPolling(appId, generation);
  }

  async function pollWorkshopAutomation(appId, generation) {
    if (state.page !== 'workshop' || state.workshopPollGeneration !== generation || state.workshopPollAppId !== String(appId)) return;
    const selected = document.getElementById('workshop-game')?.value;
    if (String(selected || '') !== String(appId)) return;
    if (document.hidden || state.workshopPollBusy) {
      scheduleWorkshopAutomationPolling(appId, generation);
      return;
    }
    state.workshopPollBusy = true;
    try {
      const payload = parseJson(await call('get_workshop_automation_status', appId), {});
      if (state.workshopPollGeneration === generation && state.workshopPollAppId === String(appId)) {
        renderWorkshopAutomation(payload, state.workshopStatus);
        const automation = normalizeWorkshopAutomation(payload, state.workshopStatus);
        const counts = `${automation.imported_count}:${automation.updated_count}`;
        if (state.workshopPollCounts && counts !== state.workshopPollCounts) {
          state.workshopPollCounts = counts;
          await updateWorkshopSelection();
          return;
        }
        state.workshopPollCounts = counts;
      }
    } catch (error) {
      if (state.workshopPollGeneration === generation && state.workshopPollAppId === String(appId)) {
        renderWorkshopAutomation({
          enabled: Boolean(state.workshopStatus?.auto_sync_enabled),
          state: 'error',
          last_error: error.message || String(error),
        });
      }
    } finally {
      state.workshopPollBusy = false;
      scheduleWorkshopAutomationPolling(appId, generation);
    }
  }

  async function loadWorkshop() {
    const games = parseJson(await call('get_workshop_games'), []);
    const select = document.getElementById('workshop-game');
    const previous = state.workshopPreferredAppId || select.value;
    state.workshopPreferredAppId = '';
    select.innerHTML = '<option value="">Wybierz grę...</option>';
    games.forEach(game => {
      const option = document.createElement('option');
      option.value = game.app_id;
      option.textContent = `${game.name || `App ${game.app_id}`} — App ${game.app_id}`;
      select.appendChild(option);
    });
    if (games.some(game => game.app_id === previous)) select.value = previous;
    await updateWorkshopSelection();
  }

  async function updateWorkshopSelection() {
    const appId = document.getElementById('workshop-game').value;
    stopWorkshopAutomationPolling();
    const prepare = document.getElementById('workshop-prepare');
    const open = document.getElementById('workshop-open-page');
    const host = document.getElementById('workshop-items');
    const empty = document.getElementById('workshop-empty');
    host.innerHTML = '';
    state.workshopStatus = null;
    prepare.disabled = !appId;
    open.disabled = !appId;
    if (!appId) {
      prepare.dataset.enabled = '0';
      prepare.textContent = 'Włącz automatyczny import';
      prepare.className = 'primary';
      document.getElementById('workshop-status').innerHTML = '<strong>Wybierz grę</strong><span>Sprawdzimy, czy jest gotowa na mody.</span>';
      renderWorkshopAutomation({}, { auto_sync_enabled: false });
      document.getElementById('workshop-facts').innerHTML = '';
      document.getElementById('workshop-ready-pill').textContent = 'NIE WYBRANO GRY';
      empty.style.display = 'grid';
      return;
    }
    document.getElementById('workshop-status').innerHTML = '<strong>Skanowanie...</strong><span>Przeglądam biblioteki Steam i katalog gry.</span>';
    const status = parseJson(await call('get_workshop_status', appId));
    state.workshopStatus = status;
    if (!status.success) {
      document.getElementById('workshop-status').innerHTML = `<strong>Nie można przygotować Workshop</strong><span>${escapeHtml(status.message || 'Nieznany błąd')}</span>`;
      renderWorkshopAutomation({ enabled: false, state: 'error', last_error: status.message || 'Nieznany błąd' }, status);
      prepare.dataset.enabled = '0';
      prepare.textContent = 'Włącz automatyczny import';
      prepare.className = 'primary';
      prepare.disabled = true;
      empty.style.display = 'grid';
      return;
    }
    const warning = (status.warnings || [])[0] || '';
    const autoSyncEnabled = Object.prototype.hasOwnProperty.call(status, 'auto_sync_enabled')
      ? Boolean(status.auto_sync_enabled)
      : Boolean(status.ugc_enabled);
    document.getElementById('workshop-status').innerHTML = `<strong>${escapeHtml(status.message)}</strong><span>${escapeHtml(warning || status.directory_confidence || '')}</span>`;
    document.getElementById('workshop-facts').innerHTML = `<div><dt>Folder gry</dt><dd>${escapeHtml(status.target_directory)}</dd></div><div><dt>Wersja Online-Fix</dt><dd>${status.dll_path ? escapeHtml(status.dll_version || 'nieznana') : 'nie wykryto'}</dd></div><div><dt>Automatyczny import</dt><dd>${autoSyncEnabled ? 'aktywny' : 'wyłączony'}</dd></div><div><dt>Folder modów</dt><dd>${escapeHtml(status.workshop_directory)}</dd></div>`;
    const pill = document.getElementById('workshop-ready-pill');
    pill.textContent = status.ready ? 'GOTOWY' : 'WYMAGA KONFIGURACJI';
    pill.className = `pill ${status.ready ? 'purple' : 'gray'}`;
    prepare.dataset.enabled = autoSyncEnabled ? '1' : '0';
    prepare.textContent = autoSyncEnabled ? 'Wyłącz automatyczny import' : 'Włącz automatyczny import';
    prepare.className = autoSyncEnabled ? 'danger' : 'primary';
    prepare.disabled = autoSyncEnabled
      ? false
      : !status.dll_path || (status.dll_version && !status.dll_compatible);
    renderWorkshopAutomation(status.automation || {}, { ...status, auto_sync_enabled: autoSyncEnabled });
    renderWorkshopItems(status.items || []);
    startWorkshopAutomationPolling(appId);
  }

  function renderWorkshopItems(items) {
    const host = document.getElementById('workshop-items');
    const empty = document.getElementById('workshop-empty');
    host.innerHTML = '';
    empty.style.display = items.length ? 'none' : 'grid';
    items.forEach(item => {
      const row = document.createElement('article');
      row.className = 'workshop-item';
      const stateLabel = item.installed
        ? 'W GRZE'
        : item.locally_available
          ? 'POBRANY W STEAM'
          : item.download_state === 'downloading'
            ? 'POBIERANIE W STEAM'
            : item.subscribed
              ? 'ZASUBSKRYBOWANY'
              : 'TYLKO W GRZE';
      const title = item.title || `Workshop ${item.file_id}`;
      const preview = item.preview_url
        ? `<img src="${escapeHtml(item.preview_url)}" alt="" loading="lazy">`
        : '<span aria-hidden="true">W</span>';
      const actionLabel = item.installed
        ? (item.managed ? 'Usuń kopię' : 'Dodano ręcznie')
        : item.locally_available
          ? 'Importuj do gry'
          : item.download_state === 'downloading'
            ? 'Steam pobiera pliki'
            : 'Oczekuje na Steam';
      const pathLabel = item.source_path || (item.subscribed ? 'Pliki nie są jeszcze dostępne lokalnie' : item.target_path);
      const assetLine = item.asset_health === 'warning'
        ? `<span class="workshop-asset-health warning">${escapeHtml(String(item.assets_unavailable))} zasobów usuniętych przez autora</span>`
        : item.asset_health === 'ok'
          ? `<span class="workshop-asset-health ok">Zasoby moda sprawdzone</span>`
          : '';
      row.innerHTML = `<div class="workshop-thumb">${preview}</div><div class="workshop-item-copy"><strong class="workshop-item-title" title="${escapeHtml(title)}">${escapeHtml(title)}</strong><small><span class="workshop-file-id">FILE ID ${escapeHtml(item.file_id)}</span>${escapeHtml(String(item.file_count))} plików · ${escapeHtml(formatBytes(item.size_bytes))}</small>${assetLine}<p title="${escapeHtml(pathLabel)}">${escapeHtml(pathLabel)}</p></div><span class="tag ${item.asset_health === 'warning' ? 'warning' : (item.installed || item.locally_available ? 'active' : '')}">${stateLabel}</span><button class="workshop-item-action ${item.installed ? 'danger' : 'primary'}">${actionLabel}</button>`;
      const image = row.querySelector('.workshop-thumb img');
      if (image) image.addEventListener('error', () => { image.parentElement.innerHTML = '<span aria-hidden="true">W</span>'; }, { once: true });
      const button = row.querySelector('button');
      button.disabled = (item.installed && !item.managed) || (!item.installed && !item.locally_available);
      button.addEventListener('click', () => item.installed ? removeWorkshopItem(item, button) : importWorkshopItem(item, button));
      host.appendChild(row);
    });
  }

  async function prepareWorkshop() {
    const appId = document.getElementById('workshop-game').value;
    if (!appId) return;
    const button = document.getElementById('workshop-prepare');
    const desired = button.dataset.enabled !== '1';
    const original = button.textContent;
    button.disabled = true;
    button.textContent = desired ? 'Włączanie...' : 'Wyłączanie...';
    try {
      const result = parseJson(await call('set_workshop_enabled', appId, desired));
      toast(
        result.success ? 'success' : 'error',
        result.success ? (desired ? 'Automatyczny import włączony' : 'Automatyczny import wyłączony') : 'Nie udało się zmienić ustawienia',
        result.message,
        result.warnings || [],
      );
    } catch (error) {
      button.textContent = original;
      toast('error', 'Nie udało się zmienić ustawienia', error.message || String(error));
    } finally {
      // Status z backendu jest źródłem prawdy także po błędzie. Nie odblokowuj
      // przycisku bezwarunkowo, bo niezgodny Online-Fix powinien go blokować.
      await updateWorkshopSelection();
    }
  }

  async function importWorkshopItem(item, button) {
    const appId = document.getElementById('workshop-game').value;
    button.disabled = true;
    button.textContent = 'Kopiowanie...';
    const result = parseJson(await call('import_workshop_item', appId, item.file_id));
    toast(result.success ? 'success' : 'error', result.success ? 'Mod zaimportowany' : 'Import nieudany', result.message);
    await updateWorkshopSelection();
  }

  async function removeWorkshopItem(item, button) {
    const appId = document.getElementById('workshop-game').value;
    button.disabled = true;
    button.textContent = 'Usuwanie...';
    const result = parseJson(await call('remove_workshop_item', appId, item.file_id));
    toast(result.success ? 'success' : 'error', result.success ? 'Kopia usunięta' : 'Nie usunięto', result.message);
    await updateWorkshopSelection();
  }

  async function loadDiagnostics() {
    const result = parseJson(await call('get_runtime_diagnostics'));
    state.diagnostics = result;
    const host = document.getElementById('diagnostics-list');
    host.innerHTML = '';
    if (!result.success) {
      host.innerHTML = `<div class="catalog-empty"><strong>Diagnostyka niedostępna</strong><span>${escapeHtml(result.message || '')}</span></div>`;
      return;
    }
    const labels = { ok: 'OK', warning: 'UWAGA', error: 'BŁĄD', info: 'INFO' };
    (result.checks || []).forEach(check => {
      const row = document.createElement('article');
      row.className = `diagnostic-row panel ${escapeHtml(check.status)}`;
      row.innerHTML = `<span class="diagnostic-state">${labels[check.status] || 'INFO'}</span><div><h3>${escapeHtml(check.title)}</h3><strong>${escapeHtml(check.summary)}</strong><p>${escapeHtml(check.detail)}</p></div>`;
      host.appendChild(row);
    });
    const summary = result.summary || {};
    document.getElementById('diagnostics-health').textContent = result.health === 'ok' ? 'Dobry' : result.health === 'warning' ? 'Wymaga uwagi' : 'Wykryto błędy';
    document.getElementById('diagnostics-count').textContent = summary.checks || 0;
    document.getElementById('diagnostics-warnings').textContent = (summary.warnings || 0) + (summary.errors || 0);
    document.getElementById('diagnostics-pill').textContent = result.health === 'ok' ? 'WSZYSTKO GOTOWE' : 'SPRAWDŹ WYNIKI';
  }

  async function runRepair(method, title) {
    const result = parseJson(await call(method));
    toast(result.success ? 'success' : 'error', title, result.message, result.warnings || []);
    if (result.success) await loadDiagnostics();
  }

  async function createSupportBundle() {
    const button = document.getElementById('repair-support-bundle');
    const original = button.textContent;
    button.disabled = true;
    button.textContent = 'Tworzenie…';
    try {
      const result = parseJson(await call('create_support_bundle'));
      toast(result.success ? 'success' : 'error', result.success ? 'Raport gotowy' : 'Nie utworzono raportu', result.message, result.warnings || []);
    } finally {
      button.disabled = false;
      button.textContent = original;
    }
  }

  async function runRecovery(method, title, pendingText) {
    const button = document.getElementById(method === 'export_library_recovery' ? 'recovery-export' : 'recovery-import');
    const original = button.textContent;
    button.disabled = true;
    button.textContent = pendingText;
    try {
      const result = parseJson(await call(method));
      if (result.message === 'Przywracanie anulowane') return;
      toast(result.success ? 'success' : 'error', title, result.message, result.warnings || []);
      if (result.success && method === 'import_library_recovery') await refreshAll();
    } finally {
      button.disabled = false;
      button.textContent = original;
    }
  }

  async function restartSteam() {
    const button = document.getElementById('restart-steam');
    button.disabled = true;
    toast('info', 'Restart Steam', 'Zamykanie i ponowne uruchamianie klienta...');
    try {
      const result = parseJson(await call('restart_steam'));
      toast(result.success ? 'success' : 'error', result.success ? 'Steam uruchomiony' : 'Restart nieudany', result.message, result.warnings || []);
      if (result.success) await refreshAll();
    } catch (error) {
      toast('error', 'Restart nieudany', error.message || String(error));
    } finally {
      button.disabled = false;
    }
  }

  async function loadOnlineFix() {
    const games = parseJson(await call('get_online_fix_games'), []);
    const select = document.getElementById('onlinefix-game');
    const previous = select.value;
    select.innerHTML = '<option value="">Wybierz grę...</option>';
    games.forEach(game => {
      const option = document.createElement('option');
      option.value = game.app_id;
      option.textContent = `${game.name || `App ${game.app_id}`} — App ${game.app_id}`;
      option.dataset.name = game.name || `App ${game.app_id}`;
      option.dataset.image = game.image_url || '';
      option.dataset.fallback = game.fallback_image_url || '';
      select.appendChild(option);
    });
    if (!games.length) {
      select.options[0].textContent = 'Brak zainstalowanych gier';
      document.getElementById('onlinefix-preview').innerHTML = '<div class="selection-mark">O</div><div><strong>Najpierw zainstaluj grę</strong><small>Multiplayer wymaga istniejącego folderu w bibliotece Steam.</small></div>';
    }
    if (games.some(game => game.app_id === previous)) select.value = previous;
    await updateOnlineFixSelection();
  }

  async function updateOnlineFixSelection() {
    const appId = document.getElementById('onlinefix-game').value;
    const toggle = document.getElementById('onlinefix-toggle');
    const page = document.getElementById('onlinefix-page');
    const remote = document.getElementById('onlinefix-remote');
    const archive = document.getElementById('onlinefix-archive');
    const preview = document.getElementById('onlinefix-preview');
    state.onlineFixPagePlan = null;
    document.getElementById('onlinefix-fix-plan').hidden = true;
    if (!appId) {
      preview.innerHTML = '<div class="selection-mark">O</div><div><strong>Nie wybrano gry</strong><small>Wybierz grę z biblioteki.</small></div>';
      document.getElementById('onlinefix-state').textContent = 'Nie skonfigurowano';
      toggle.disabled = true;
      page.disabled = true;
      remote.disabled = true;
      archive.disabled = true;
      return;
    }
    const selected = document.getElementById('onlinefix-game').selectedOptions[0];
    const previewImage = selected.dataset.image
      ? `<img src="${escapeHtml(selected.dataset.image)}" alt="${escapeHtml(selected.dataset.name)}">`
      : '<div class="selection-mark">K</div>';
    preview.innerHTML = `${previewImage}<div><strong>${escapeHtml(selected.dataset.name || `App ${appId}`)}</strong><small>Steam AppID ${escapeHtml(appId)}</small></div>`;
    toggle.disabled = false;
    page.disabled = false;
    remote.disabled = false;
    archive.disabled = false;
    const result = parseJson(await call('get_online_fix_status', appId));
    document.getElementById('onlinefix-state').textContent = result.message || 'Nie skonfigurowano';
    document.getElementById('onlinefix-lc-label').textContent = result.enabled
      ? 'Wyłącz multiplayer'
      : 'Włącz multiplayer';
    toggle.dataset.enabled = result.enabled ? '1' : '0';
    toggle.classList.toggle('active', Boolean(result.enabled));
  }

  async function toggleOnlineFix() {
    const appId = document.getElementById('onlinefix-game').value;
    if (!appId) return;
    const button = document.getElementById('onlinefix-toggle');
    const label = document.getElementById('onlinefix-lc-label');
    const desired = button.dataset.enabled !== '1';
    button.disabled = true;
    const old = label.textContent;
    label.textContent = desired ? 'Włączanie…' : 'Wyłączanie…';
    try {
      const result = parseJson(await call('set_online_fix', appId, desired));
      toast(result.success ? 'success' : 'error', result.success ? (desired ? 'Multiplayer włączony' : 'Multiplayer wyłączony') : 'Błąd multiplayer', result.message, result.warnings || []);
      await updateOnlineFixSelection();
    } catch (error) {
      toast('error', 'Błąd multiplayer', error.message || String(error));
      label.textContent = old;
    } finally {
      button.disabled = false;
    }
  }

  async function openOnlineFixPage() {
    const appId = document.getElementById('onlinefix-game').value;
    if (!appId) return;
    const result = parseJson(await call('open_online_fix_page', appId));
    toast(result.success ? 'success' : 'error', 'Online-Fix.me', result.message);
  }

  function renderOnlineFixPagePlan(plan) {
    state.onlineFixPagePlan = plan;
    const confidence = fixConfidenceLabel(plan);
    document.getElementById('onlinefix-fix-target').textContent = `${plan.target_directory} · ${plan.file_count} plików${confidence ? ` · ${confidence}` : ''}`;
    const mappings = plan.mapping_preview || [];
    document.getElementById('onlinefix-fix-files').innerHTML = mappings.length
      ? mappings.map(item => `<li>${escapeHtml(item.source)} → ${escapeHtml(item.destination)}</li>`).join('')
      : (plan.preview || []).map(file => `<li>${escapeHtml(file)}</li>`).join('');
    document.getElementById('onlinefix-fix-plan').hidden = false;
  }

  async function downloadOnlineFixFromPage() {
    const appId = document.getElementById('onlinefix-game').value;
    if (!appId) return;
    const button = document.getElementById('onlinefix-remote');
    const original = button.innerHTML;
    button.disabled = true;
    button.innerHTML = '<span><strong>Pobieranie...</strong><small>Szukanie Online-Fix</small></span>';
    try {
      const result = parseJson(await call('download_online_fix_remote', appId));
      if (!result.success) return toast('error', 'Pobieranie nieudane', result.message);
      showFixLocationChoice(appId, result, 'page');
      toast('success', 'Online-Fix pobrany', 'Wybierz sposób instalacji.');
    } finally {
      button.disabled = false;
      button.innerHTML = original;
    }
  }

  async function selectOnlineFixArchiveFromPage() {
    const appId = document.getElementById('onlinefix-game').value;
    if (!appId) return;
    const result = parseJson(await call('select_online_fix_archive', appId));
    if (!result.success) return toast('error', 'Pakiet odrzucony', result.message);
    renderOnlineFixPagePlan(result.data);
    toast('success', 'Pakiet sprawdzony', 'Sprawdź plan i potwierdź instalację');
  }

  async function installOnlineFixFromPage() {
    const appId = document.getElementById('onlinefix-game').value;
    const plan = state.onlineFixPagePlan;
    if (!appId || !plan) return;
    const button = document.getElementById('onlinefix-fix-install');
    button.disabled = true;
    button.textContent = 'Instalowanie...';
    try {
      const result = parseJson(await call('install_online_fix_archive', appId, plan.archive, plan.game_directory || ''));
      toast(result.success ? 'success' : 'error', result.success ? 'Online-Fix zainstalowany' : 'Instalacja nieudana', result.message, result.warnings || []);
      if (result.success) document.getElementById('onlinefix-fix-plan').hidden = true;
    } finally {
      button.disabled = false;
      button.textContent = 'Potwierdź i zainstaluj';
    }
  }

  function renderHubcapStatus(status) {
    state.hubcap = status;
    const configured = Boolean(status.configured);
    const invalid = status.state === 'invalid' || status.reason === 'invalid_key';
    const checked = status.state && status.state !== 'unchecked';
    const usable = configured && !invalid;
    document.getElementById('hubcap-settings-state').textContent = invalid ? 'KLUCZ NIEWAŻNY' : configured ? (checked ? 'POŁĄCZONO' : 'SPRAWDZANIE') : 'NIE POŁĄCZONO';
    document.getElementById('hubcap-settings-state').className = `pill ${usable ? 'purple' : 'gray'}`;
    const searchStatus = document.getElementById('hubcap-search-status');
    const searchDetail = document.getElementById('hubcap-search-detail');
    const providerDot = document.getElementById('hubcap-provider-dot');
    if (searchStatus) searchStatus.textContent = invalid ? 'Hubcap wymaga nowego klucza' : configured ? 'Hubcap połączony' : 'Hubcap opcjonalny';
    if (searchDetail) searchDetail.textContent = invalid ? 'Wklej aktualny klucz w Ustawieniach' : configured ? `Dodatkowe pakiety: ${status.masked_key}` : 'SteamTools.games działa bez klucza';
    if (providerDot) providerDot.classList.toggle('ready', usable);
    document.getElementById('hubcap-home-status').textContent = invalid ? 'Klucz Hubcap wygasł' : configured ? `Połączono ${status.masked_key}` : 'Wyszukiwanie działa bez klucza';
    document.getElementById('hubcap-disconnect').disabled = !configured;
  }

  async function loadHubcapStatus() {
    const status = parseJson(await call('get_hubcap_status'));
    renderHubcapStatus(status);
  }

  async function checkHubcapHealth(force = false) {
    try {
      const status = parseJson(await call('check_hubcap_health', Boolean(force)));
      renderHubcapStatus(status);
      if (status.notify) {
        toast(
          'error',
          'Klucz Hubcap wymaga odświeżenia',
          status.message || 'Wklej nowy klucz Hubcap w Ustawieniach.'
        );
      }
      return status;
    } catch (_) {
      return state.hubcap;
    }
  }

  function startHubcapHealthPolling() {
    if (state.hubcapHealthTimer) clearInterval(state.hubcapHealthTimer);
    state.hubcapHealthTimer = setInterval(() => {
      void checkHubcapHealth(false);
    }, 30 * 60 * 1000);
  }

  async function refreshVisibleCatalogAfterProviderChange() {
    const input = document.getElementById('app-search');
    const query = input.value.trim();
    clearTimeout(state.catalogSearchTimer);
    const sequence = ++state.catalogSearchSequence;
    if (query.length >= 2 || /^\d+$/.test(query)) await searchCatalog(query, sequence);
    else if (!query) await loadCatalogSuggestions();
  }

  async function connectHubcap() {
    const input = document.getElementById('hubcap-api-key');
    const key = input.value.trim();
    if (!key) return toast('error', 'Brak klucza API', 'Wklej klucz smm... z Hubcap');
    const button = document.getElementById('hubcap-connect');
    button.disabled = true;
    button.textContent = 'Sprawdzanie...';
    try {
      const result = parseJson(await call('connect_hubcap', key));
      toast(result.success ? 'success' : 'error', result.success ? 'Hubcap połączony' : 'Połączenie nieudane', result.message);
      if (result.stats) {
        document.getElementById('hubcap-usage').textContent = `Dzienne użycie: ${result.stats.daily_usage}/${result.stats.daily_limit}`;
      }
      if (result.success) {
        input.value = '';
        await loadHubcapStatus();
        await checkHubcapHealth(false);
        await refreshVisibleCatalogAfterProviderChange();
      }
    } finally {
      button.disabled = false;
      button.textContent = 'Połącz i sprawdź';
    }
  }

  async function disconnectHubcap() {
    const result = parseJson(await call('disconnect_hubcap'));
    document.getElementById('hubcap-usage').textContent = 'Brak danych dostawcy.';
    toast(result.success ? 'success' : 'error', 'Hubcap', result.message);
    await loadHubcapStatus();
    await refreshVisibleCatalogAfterProviderChange();
  }

  function formatProfileDate(value) {
    if (!value) return '—';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value);
    return date.toLocaleString(
      state.settings.language === 'en' ? 'en-US' : 'pl-PL',
      { dateStyle: 'medium', timeStyle: 'short' }
    );
  }

  function renderLibraryProfile(profile = {}) {
    state.libraryProfile = profile;
    const card = document.getElementById('library-profile-card');
    if (!card) return;
    const connected = Boolean(profile.authenticated);
    const exists = Boolean(profile.exists);
    const same = Boolean(profile.same_library);
    const localChanges = Boolean(profile.local_changes_pending);
    const title = document.getElementById('library-profile-title');
    const detail = document.getElementById('library-profile-detail');
    const pill = document.getElementById('library-profile-state');
    const button = document.getElementById('library-profile-sync');
    card.classList.toggle('ready', same);
    card.classList.toggle('available', exists && !same);
    title.textContent = !connected
      ? 'Połącz Google Drive, aby przenosić gry'
      : same
        ? 'Biblioteka jest zsynchronizowana'
        : localChanges
          ? 'Lokalne zmiany czekają na synchronizację'
        : exists
          ? 'Na Google Drive jest inna wersja biblioteki'
          : 'Utwórz pierwszą kopię biblioteki';
    detail.textContent = connected
      ? `${Number(profile.local_game_count || 0)} gier lokalnie${exists ? ` · ${Number(profile.game_count || 0)} w chmurze · ${formatProfileDate(profile.created_at)}` : ''}`
      : 'Po zalogowaniu pakiet Lua i manifesty będą przypisane do aktywnego konta Steam.';
    pill.textContent = !connected
      ? 'NIE POŁĄCZONO'
      : same
        ? 'AKTUALNA'
        : localChanges
          ? 'DO WYSŁANIA'
          : exists
            ? 'KOPIA DOSTĘPNA'
            : 'GOTOWY';
    pill.className = `pill ${connected ? 'purple' : 'gray'}`;
    button.disabled = !connected;
    button.textContent = same ? 'Synchronizuj ponownie' : 'Synchronizuj teraz';
  }

  function openLibraryProfilePrompt(profile) {
    if (!profile?.prompt_required) {
      document.getElementById('library-profile-modal').classList.remove('visible');
      return;
    }
    if (state.libraryProfilePrompted) return;
    state.libraryProfilePrompted = true;
    document.getElementById('library-profile-modal-count').textContent = String(profile.game_count || 0);
    document.getElementById('library-profile-modal-date').textContent = formatProfileDate(profile.created_at);
    document.getElementById('library-profile-modal').classList.add('visible');
  }

  async function loadLibraryProfile(prompt = false, seedIfMissing = false) {
    try {
      const profile = parseJson(await call('get_library_cloud_profile'), {});
      renderLibraryProfile(profile);
      if (prompt) openLibraryProfilePrompt(profile);
      if (
        seedIfMissing
        && profile.success
        && profile.authenticated
        && !profile.exists
        && Number(profile.local_game_count || 0) > 0
      ) {
        await syncLibraryProfile(true);
      }
      return profile;
    } catch (error) {
      renderLibraryProfile({ success: false, message: error.message || String(error) });
      return {};
    }
  }

  async function syncLibraryProfile(silent = false) {
    if (!state.cloudProvider.authenticated) {
      if (!silent) toast('info', 'Połącz Google Drive', 'Najpierw połącz konto Google.');
      return;
    }
    const button = document.getElementById('library-profile-sync');
    if (button.disabled) return;
    button.disabled = true;
    button.textContent = 'Synchronizowanie…';
    try {
      const result = parseJson(await call('sync_library_cloud_profile'));
      if (!silent || !result.success) {
        toast(
          result.success ? 'success' : 'error',
          result.success ? 'Biblioteka zsynchronizowana' : 'Synchronizacja nieudana',
          result.message,
          result.warnings || []
        );
      }
      await loadLibraryProfile(false);
    } finally {
      button.disabled = false;
      button.textContent = state.libraryProfile?.same_library
        ? 'Synchronizuj ponownie'
        : 'Synchronizuj teraz';
    }
  }

  function scheduleLibraryProfileSync() {
    clearTimeout(state.libraryProfileSyncTimer);
    if (!state.cloudProvider.authenticated) return;
    state.libraryProfileSyncTimer = setTimeout(() => {
      void syncLibraryProfile(true);
    }, 3500);
  }

  function formatUpdateCenterDate(value) {
    if (!value) return '—';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return '—';
    return date.toLocaleString(
      state.settings.language === 'en' ? 'en-US' : 'pl-PL',
      { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }
    );
  }

  async function restoreLibraryProfile() {
    const button = document.getElementById('library-profile-restore');
    button.disabled = true;
    button.textContent = 'Weryfikowanie i wczytywanie…';
    try {
      const result = parseJson(await call('restore_library_cloud_profile'));
      toast(
        result.success ? 'success' : 'error',
        result.success ? 'Biblioteka przywrócona' : 'Nie udało się przywrócić biblioteki',
        result.message,
        result.warnings || []
      );
      if (result.success) {
        document.getElementById('library-profile-modal').classList.remove('visible');
        await refreshAll();
        await loadLibraryProfile(false);
      }
    } finally {
      button.disabled = false;
      button.textContent = 'Wczytaj moje gry';
    }
  }

  function renderCloudProviderStatus(status) {
    state.cloudProvider = status || { connected: true, ready: true, provider: 'local', local_active: true };
    const ready = Boolean(state.cloudProvider.ready ?? state.cloudProvider.connected);
    const authenticated = Boolean(state.cloudProvider.authenticated);
    const googleConnected = Boolean(state.cloudProvider.google_connected);
    const localActive = state.cloudProvider.provider === 'local' && ready;
    const stateNode = document.getElementById('cloud-provider-state');
    const title = document.getElementById('cloud-provider-title');
    const message = document.getElementById('cloud-provider-message');
    const connect = document.getElementById('google-drive-connect');
    const disconnect = document.getElementById('google-drive-disconnect');
    const localState = document.getElementById('cloud-local-provider-state');
    const googleState = document.getElementById('cloud-google-provider-state');
    const localCard = document.getElementById('cloud-provider-local-card');
    const googleCard = document.getElementById('cloud-provider-google-card');
    const useLocal = document.getElementById('cloud-use-local');

    stateNode.textContent = googleConnected ? 'GOOGLE DRIVE' : localActive ? 'LOKALNIE' : 'WYMAGA KONFIGURACJI';
    stateNode.className = `pill ${ready ? 'purple' : 'gray'}`;
    title.textContent = googleConnected
      ? 'Zapisy synchronizują się między komputerami'
      : localActive
        ? 'Zapisy są chronione lokalnie'
        : 'Wybierz magazyn zapisów';
    message.textContent = state.cloudProvider.message || (
      localActive
        ? 'Szybki magazyn na tym komputerze nie wymaga połączenia z siecią.'
        : 'Połącz Google Drive albo użyj magazynu lokalnego.'
    );
    localCard?.classList.toggle('active', localActive);
    googleCard?.classList.toggle('active', googleConnected);
    localState.textContent = localActive ? 'AKTYWNY' : 'DOSTĘPNY';
    localState.className = `pill ${localActive ? 'purple' : 'gray'}`;
    googleState.textContent = googleConnected ? 'AKTYWNY' : authenticated ? 'GOTOWY' : 'NIE POŁĄCZONO';
    googleState.className = `pill ${googleConnected ? 'purple' : 'gray'}`;
    useLocal.disabled = localActive;
    useLocal.textContent = localActive ? 'Aktywny magazyn' : 'Użyj lokalnie';
    connect.disabled = googleConnected;
    connect.textContent = googleConnected
      ? 'Aktywny magazyn'
      : authenticated
        ? 'Użyj Google Drive'
        : 'Połącz Google Drive';
    disconnect.disabled = !authenticated;
  }

  async function loadCloudProviderStatus() {
    try {
      const status = parseJson(await call('get_cloud_provider_status'));
      renderCloudProviderStatus(status);
      return status;
    } catch (error) {
      renderCloudProviderStatus({ success: false, connected: false, message: error.message || String(error) });
      return state.cloudProvider;
    }
  }

  async function connectGoogleDrive() {
    const button = document.getElementById('google-drive-connect');
    button.disabled = true;
    const canReactivate = Boolean(state.cloudProvider.authenticated && !state.cloudProvider.google_connected);
    button.textContent = canReactivate ? 'Włączanie Google Drive…' : 'Dokończ logowanie w przeglądarce…';
    if (!canReactivate) {
      toast('info', 'Logowanie Google Drive', 'W przeglądarce wybierz konto i zezwól na dostęp do plików KillzoneTools.');
    }
    try {
      const result = parseJson(
        await call(canReactivate ? 'set_cloud_save_provider' : 'connect_google_drive', ...(canReactivate ? ['gdrive'] : []))
      );
      toast(result.success ? 'success' : 'error', result.success ? 'Google Drive połączony' : 'Nie udało się połączyć Google Drive', result.message, result.warnings || []);
      await loadCloudSaveOverview();
      await loadLibraryProfile(true, true);
      if (state.selectedGameDetails) await refreshDrawer();
    } finally {
      button.disabled = Boolean(state.cloudProvider.google_connected);
      button.textContent = state.cloudProvider.google_connected
        ? 'Aktywny magazyn'
        : state.cloudProvider.authenticated
          ? 'Użyj Google Drive'
          : 'Połącz Google Drive';
    }
  }

  async function useLocalCloudStorage() {
    const button = document.getElementById('cloud-use-local');
    button.disabled = true;
    try {
      const result = parseJson(await call('set_cloud_save_provider', 'local'));
      toast(result.success ? 'success' : 'error', 'Magazyn lokalny', result.message, result.warnings || []);
      await loadCloudSaveOverview();
      if (state.selectedGameDetails) await refreshDrawer();
    } finally {
      button.disabled = Boolean(state.cloudProvider.local_active);
    }
  }

  async function disconnectGoogleDrive() {
    const button = document.getElementById('google-drive-disconnect');
    button.disabled = true;
    try {
      const result = parseJson(await call('disconnect_google_drive'));
      toast(result.success ? 'success' : 'error', 'Google Drive', result.message, result.warnings || []);
      await loadCloudSaveOverview();
      await loadLibraryProfile(false);
      if (state.selectedGameDetails) await refreshDrawer();
    } finally {
      button.disabled = !Boolean(state.cloudProvider.authenticated);
    }
  }

  function migrationStateLabel(value) {
    const stateName = String(value || '');
    if (stateName === 'complete') return 'Gotowe';
    if (stateName === 'partial') return 'Częściowo';
    if (stateName === 'running') return 'W toku';
    if (stateName === 'failed') return 'Błąd';
    return 'Nie wykonano';
  }

  function renderCloudMigrationProgress(migration = {}) {
    const total = Math.max(0, Number(migration.files || 0));
    const processed = Math.min(
      total || Number.MAX_SAFE_INTEGER,
      Math.max(
        0,
        Number(migration.uploaded || 0)
          + Number(migration.already_present || 0)
          + Number(migration.conflicts || 0)
          + Number(migration.failed || 0)
      )
    );
    const stateName = String(migration.state || '');
    const percent = total > 0
      ? Math.min(100, Math.round((processed / total) * 100))
      : ['complete', 'partial'].includes(stateName)
        ? 100
        : 0;
    const box = document.getElementById('cloud-migration-progress');
    const bar = document.getElementById('cloud-migration-bar');
    box.className = `cloud-migration-progress ${stateName}`.trim();
    document.getElementById('cloud-migration-progress-label').textContent =
      stateName === 'running'
        ? 'Przenoszenie kopii…'
        : stateName === 'complete'
          ? 'Wszystkie kopie sprawdzone'
          : stateName === 'partial'
            ? 'Migracja wymaga uwagi'
            : stateName === 'failed'
              ? 'Migracja nieudana'
              : 'Gotowe do sprawdzenia';
    document.getElementById('cloud-migration-progress-count').textContent = `${processed} / ${total}`;
    document.getElementById('cloud-migration-fill').style.width = `${percent}%`;
    bar.setAttribute('aria-valuenow', String(percent));
    const details = [
      `${migration.uploaded || 0} wysłano`,
      `${migration.already_present || 0} już było`,
    ];
    if (migration.conflicts) details.push(`${migration.conflicts} konfliktów`);
    if (migration.failed) details.push(`${migration.failed} błędów`);
    document.getElementById('cloud-migration-progress-detail').textContent =
      stateName ? details.join(' · ') : 'Postęp będzie aktualizowany plik po pliku.';
  }

  function renderCloudSaveOverview(overview) {
    renderCloudProviderStatus(overview);
    const local = overview.local || {};
    const remote = overview.remote || {};
    const migration = overview.migration || {};
    renderCloudQuota(overview.quota || {});
    document.getElementById('cloud-local-files').textContent = String(local.files ?? 0);
    document.getElementById('cloud-local-detail').textContent =
      `${local.apps || 0} gier · ${formatBytes(local.bytes || 0)}`;
    document.getElementById('cloud-remote-files').textContent =
      overview.google_connected ? String(remote.files ?? 0) : '—';
    document.getElementById('cloud-remote-detail').textContent = overview.google_connected
      ? `${remote.apps || 0} gier · ${remote.accounts?.length || 0} kont Steam`
      : overview.authenticated ? 'Google Drive jest gotowy do włączenia' : 'Połącz Google Drive';
    document.getElementById('cloud-migration-state').textContent =
      migrationStateLabel(migration.state);
    document.getElementById('cloud-migration-detail').textContent = migration.finished_at
      ? `${migration.uploaded || 0} nowych · ${migration.already_present || 0} już zapisanych`
      : 'Dotychczasowe kopie czekają na sprawdzenie';
    renderCloudMigrationProgress(migration);
    const migrate = document.getElementById('cloud-save-migrate');
    migrate.disabled = !overview.google_connected
      || migration.state === 'running'
      || state.cloudQuota.state === 'full';
    const warning = document.getElementById('cloud-migration-warning');
    warning.textContent = overview.warnings?.length
      ? overview.warnings[0]
      : 'Migracja nie nadpisuje innej kopii istniejącej już na Google Drive.';
  }

  function renderCloudQuota(quota) {
    state.cloudQuota = quota || { state: 'disconnected' };
    const card = document.getElementById('cloud-quota');
    if (!card) return;
    const connected = Boolean(state.cloudProvider.google_connected);
    card.hidden = !connected;
    if (!connected) return;
    const limit = Number(quota.limit || 0);
    const usage = Number(quota.usage || 0);
    const percent = Math.max(0, Math.min(100, Number(quota.percent || 0)));
    const quotaState = quota.state || 'unknown';
    card.className = `panel cloud-quota ${quotaState}`;
    const title = document.getElementById('cloud-quota-title');
    const detail = document.getElementById('cloud-quota-detail');
    const bar = document.getElementById('cloud-quota-bar');
    document.getElementById('cloud-quota-fill').style.width = `${percent}%`;
    bar.setAttribute('aria-valuenow', String(Math.round(percent)));

    if (quotaState === 'full') {
      title.textContent = 'Google Drive jest pełny';
      detail.textContent = 'Nowe kopie pozostają lokalnie. Zwolnij miejsce i ponów synchronizację.';
    } else if (quotaState === 'critical' || quotaState === 'warning') {
      title.textContent = quotaState === 'critical'
        ? 'Kończy się miejsce na Google Drive'
        : 'Mało wolnego miejsca na Google Drive';
      detail.textContent = limit
        ? `${formatBytes(usage)} z ${formatBytes(limit)} · wolne ${formatBytes(quota.available || 0)}`
        : (quota.message || 'Sprawdź miejsce na koncie Google.');
    } else if (quota.success && limit) {
      title.textContent = `${Math.round(percent)}% miejsca wykorzystane`;
      detail.textContent = `${formatBytes(usage)} z ${formatBytes(limit)} · wolne ${formatBytes(quota.available || 0)}`;
    } else if (quota.success) {
      title.textContent = 'Google Drive jest gotowy';
      detail.textContent = 'Konto nie udostępnia stałego limitu miejsca.';
    } else {
      title.textContent = 'Nie udało się sprawdzić miejsca';
      detail.textContent = quota.message || 'Ponów sprawdzanie za chwilę.';
    }

    if (
      !state.cloudQuotaWarningShown
      && ['full', 'critical'].includes(quotaState)
    ) {
      state.cloudQuotaWarningShown = true;
      toast(
        quotaState === 'full' ? 'error' : 'warning',
        quotaState === 'full' ? 'Google Drive jest pełny' : 'Kończy się miejsce w chmurze',
        detail.textContent,
      );
    }
  }

  async function loadCloudSaveOverview() {
    const refresh = document.getElementById('cloud-save-refresh');
    if (refresh) refresh.disabled = true;
    try {
      const overview = parseJson(await call('get_cloud_save_overview'));
      renderCloudSaveOverview(overview);
      return overview;
    } catch (error) {
      renderCloudProviderStatus({ success: false, connected: false, message: error.message || String(error) });
      return {};
    } finally {
      if (refresh) refresh.disabled = false;
    }
  }

  async function migrateCloudSaves(silent = false) {
    if (!state.cloudProvider.google_connected) {
      if (!silent) toast('info', 'Połącz Google Drive', 'Najpierw połącz konto Google.');
      return;
    }
    const button = document.getElementById('cloud-save-migrate');
    button.disabled = true;
    button.textContent = 'Przenoszenie zapisów…';
    let keepPolling = true;
    const pollProgress = async () => {
      if (!keepPolling) return;
      try {
        renderCloudMigrationProgress(
          parseJson(await call('get_cloud_migration_status'))
        );
      } catch (_) {
        // The final overview reports any persistent error.
      }
      if (keepPolling) window.setTimeout(pollProgress, 700);
    };
    window.setTimeout(pollProgress, 250);
    try {
      const result = parseJson(await call('migrate_google_drive_saves'));
      if (!silent || !result.success) {
        toast(
          result.success ? 'success' : 'error',
          result.success ? 'Kopie zapisów zabezpieczone' : 'Migracja wymaga uwagi',
          result.message,
          result.warnings || []
        );
      }
      await loadCloudSaveOverview();
    } finally {
      keepPolling = false;
      button.textContent = 'Sprawdź i przenieś kopie';
      button.disabled = !state.cloudProvider.google_connected || state.cloudQuota.state === 'full';
    }
  }

  async function runCloudArchive(method, title, busyText) {
    const buttonId = method === 'export_local_cloud_saves' ? 'cloud-save-export' : 'cloud-save-import';
    const button = document.getElementById(buttonId);
    const original = button.textContent;
    button.disabled = true;
    button.textContent = busyText;
    try {
      const result = parseJson(await call(method));
      toast(result.success ? 'success' : 'error', title, result.message, result.warnings || []);
      if (result.success) await loadCloudSaveOverview();
    } finally {
      button.disabled = false;
      button.textContent = original;
    }
  }

  function setLimitLocalCounts(card, data) {
    const values = card.querySelectorAll('dd');
    if (values[0]) values[0].textContent = String(data.downloads ?? 0);
    if (values[1]) values[1].textContent = String(data.unique_games ?? 0);
  }

  async function loadProviderLimits() {
    const checked = document.getElementById('limits-checked');
    checked.textContent = 'Pobieranie aktualnego stanu...';
    try {
      const response = parseJson(await call('get_provider_limits'));
      const hubcap = response.hubcap || {};
      const hubcapCard = document.getElementById('limit-hubcap');
      const hubcapState = hubcapCard.querySelector('.limit-state');
      const hubcapNumber = hubcapCard.querySelector('.limit-number strong');
      const hubcapUnit = hubcapCard.querySelector('.limit-number span');
      const hubcapTrack = hubcapCard.querySelector('.limit-track i');
      hubcapCard.querySelector('h3').textContent = hubcap.available ? 'Konto połączone' : hubcap.configured ? 'Nie można odczytać' : 'Nie połączono';
      hubcapState.textContent = hubcap.available ? (hubcap.can_make_requests ? 'DOSTĘPNY' : 'LIMIT OSIĄGNIĘTY') : 'BRAK DANYCH';
      hubcapState.classList.toggle('good', Boolean(hubcap.available && hubcap.can_make_requests));
      hubcapNumber.textContent = hubcap.available ? `${hubcap.daily_usage}/${hubcap.daily_limit || '—'}` : '—';
      hubcapUnit.textContent = hubcap.available ? 'dzisiejsze użycie API' : 'dzisiejszych zapytań';
      const percent = hubcap.daily_limit ? Math.min(100, (hubcap.daily_usage / hubcap.daily_limit) * 100) : 0;
      hubcapTrack.style.width = `${percent}%`;
      hubcapCard.querySelector(':scope > p').textContent = hubcap.message || 'Brak danych providera.';
      setLimitLocalCounts(hubcapCard, hubcap);

      const steamtools = response.steamtools_games || {};
      const steamtoolsCard = document.getElementById('limit-steamtools');
      setLimitLocalCounts(steamtoolsCard, steamtools);
      steamtoolsCard.querySelector(':scope > p').textContent = steamtools.message || 'Brak stałego dziennego limitu konta.';
      const locale = state.settings.language === 'en' ? 'en-US' : 'pl-PL';
      checked.textContent = response.checked_at ? `Sprawdzono ${new Date(response.checked_at).toLocaleTimeString(locale)}` : 'Stan aktualny';
    } catch (error) {
      checked.textContent = 'Nie udało się pobrać limitów';
      toast('error', 'Limity providerów', error.message || String(error));
    }
  }

  async function browseAndImport() {
    const result = parseJson(await call('browse_and_import'));
    if (result.message === 'Import anulowany') return;
    toast(result.success ? 'success' : 'error', result.success ? 'Import zakończony' : 'Import odrzucony', result.message, result.warnings || []);
    if (result.success) await refreshAll();
  }

  function applyAdvancedVisibility() {
    document.body.classList.toggle('show-advanced', Boolean(state.settings.show_advanced));
  }

  function applyLanguage() {
    const language = state.settings.language === 'en' ? 'en' : 'pl';
    state.settings.language = language;
    if (window.KZT_I18N) window.KZT_I18N.setLanguage(language);
    if (state.watcherNotifications.length) renderWatcherNotifications();
    if (state.tvLoaded) {
      renderTvDirectory();
      if (state.tvSelected) {
        document.getElementById('tv-now-group').textContent = `${tvGroupLabel(state.tvSelected.group)} · ${tvCountryLabel(state.tvSelected.country_name)}`;
      }
    }
  }

  function applyTheme() {
    const aliases = { graphite: 'copper', void: 'copper', violet: 'rose' };
    const requested = aliases[state.settings.theme] || state.settings.theme;
    const theme = ['copper', 'midnight', 'rose'].includes(requested) ? requested : 'copper';
    state.settings.theme = theme;
    document.documentElement.dataset.theme = theme;
  }

  async function loadSettings(loadProvider = true) {
    state.settings = parseJson(await call('get_settings'), state.settings);
    applyLanguage();
    applyTheme();
    document.querySelectorAll('[data-setting]').forEach(control => {
      const value = state.settings[control.dataset.setting];
      if (control.type === 'checkbox') control.checked = Boolean(value);
      else control.value = value;
    });
    applyAdvancedVisibility();
    const cache = parseJson(await call('get_image_cache_status'), {});
    const cacheStatus = document.getElementById('image-cache-status');
    if (cacheStatus) cacheStatus.textContent = `${cache.files || 0} grafik · ${formatBytes(cache.size_bytes || 0)}`;
    if (loadProvider) await Promise.all([loadHubcapStatus(), loadCloudProviderStatus()]);
  }

  async function clearImageCache() {
    const button = document.getElementById('image-cache-clear');
    button.disabled = true;
    try {
      const result = parseJson(await call('clear_image_cache'));
      toast(result.success ? 'success' : 'error', 'Cache okładek', result.message);
      await loadSettings(false);
    } finally {
      button.disabled = false;
    }
  }

  async function saveSetting(control) {
    const value = control.type === 'checkbox' ? control.checked : control.value;
    const response = parseJson(await call('set_setting', control.dataset.setting, JSON.stringify(value)));
    if (response.success) {
      state.settings = response.settings;
      applyLanguage();
      applyTheme();
      applyAdvancedVisibility();
      if (control.dataset.setting === 'language') {
        state.storefrontCache.clear();
        state.catalogIndex.clear();
        state.catalogInsights = null;
        state.catalogInsightsLoadedAt = 0;
        const query = document.getElementById('app-search').value.trim();
        if (query.length >= 2 || /^\d+$/.test(query)) {
          const sequence = ++state.catalogSearchSequence;
          await searchCatalog(query, sequence);
        }
        else await loadCatalogSuggestions();
        if (state.page === 'add') await loadCatalogInsights(true);
      }
      toast('success', 'Ustawienie zapisane', 'Zmiana została zastosowana.');
    } else toast('error', 'Nie zapisano ustawienia', response.message || 'Nieznany błąd');
  }

  async function refreshAll() {
    await Promise.all([
      loadDashboard(),
      loadLibraryWorkspace(),
      loadGames(),
      loadInstallQueue(),
      loadSteamAccounts(),
    ]);
    if (state.page === 'mode') await Promise.all([loadBackends(), checkBackendUpdate(false)]);
    if (state.page === 'onlinefix') await loadOnlineFix();
    if (state.page === 'workshop') await loadWorkshop();
    if (state.page === 'tv') await loadTvChannels(false);
    if (state.page === 'diagnostics') await loadDiagnostics();
    if (state.page === 'plugin') await loadPluginStatus();
    if (state.page === 'limits') await loadProviderLimits();
  }

  function formatOldGamesDate(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return tr('Nie odświeżono');
    return date.toLocaleDateString(
      state.settings.language === 'en' ? 'en-US' : 'pl-PL',
      { day: '2-digit', month: 'short', year: 'numeric' },
    );
  }

  function populateOldGamesFilters(status) {
    if (state.oldGamesFiltersReady || !status?.filters) return;
    const fill = (id, values) => {
      const select = document.getElementById(id);
      values.forEach(item => {
        const option = document.createElement('option');
        option.value = typeof item === 'object' ? item.value : String(item);
        option.textContent = typeof item === 'object' ? tr(item.label) : String(item);
        select.appendChild(option);
      });
    };
    fill('oldgames-genre', status.filters.genres || []);
    fill('oldgames-year', status.filters.years || []);
    state.oldGamesFiltersReady = true;
  }

  function oldGamesFilterTitle() {
    const active = [
      ['oldgames-genre', state.oldGamesGenre],
      ['oldgames-year', state.oldGamesYear],
    ].find(([, value]) => value);
    if (active) {
      const select = document.getElementById(active[0]);
      return select.options[select.selectedIndex]?.textContent || tr('Wybrane gry');
    }
    if (state.oldGamesQuery) return `${tr('Wyniki dla')}: “${state.oldGamesQuery}”`;
    if (state.oldGamesSort === 'top_downloads') return tr('Najczęściej pobierane');
    if (state.oldGamesSort === 'popular') return tr('Popularne teraz');
    return tr('Wszystkie stare gry');
  }

  function setOldGamesBusy(busy) {
    state.oldGamesBusy = busy;
    const loading = document.getElementById('oldgames-loading');
    const grid = document.getElementById('oldgames-grid');
    const pagination = document.getElementById('oldgames-pagination');
    loading.hidden = !busy;
    grid.hidden = busy;
    pagination.hidden = busy;
    document.getElementById('oldgames-refresh').classList.toggle('loading', busy);
  }

  function renderOldGamesPagination() {
    const host = document.getElementById('oldgames-pagination');
    host.innerHTML = '';
    if (state.oldGamesPages <= 1) return;
    const pages = new Set([1, state.oldGamesPages]);
    for (let offset = -2; offset <= 2; offset += 1) {
      const value = state.oldGamesPage + offset;
      if (value >= 1 && value <= state.oldGamesPages) pages.add(value);
    }
    const ordered = [...pages].sort((a, b) => a - b);
    const addButton = (label, page, disabled = false, active = false) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = label;
      button.dataset.oldgamesPage = String(page);
      button.disabled = disabled;
      button.classList.toggle('active', active);
      host.appendChild(button);
    };
    addButton('←', state.oldGamesPage - 1, state.oldGamesPage <= 1);
    ordered.forEach((page, index) => {
      if (index && page - ordered[index - 1] > 1) {
        const gap = document.createElement('span');
        gap.textContent = '…';
        host.appendChild(gap);
      }
      addButton(String(page), page, false, page === state.oldGamesPage);
    });
    addButton('→', state.oldGamesPage + 1, state.oldGamesPage >= state.oldGamesPages);
  }

  function renderOldGames() {
    const grid = document.getElementById('oldgames-grid');
    const empty = document.getElementById('oldgames-empty');
    grid.hidden = false;
    document.getElementById('oldgames-pagination').hidden = false;
    grid.innerHTML = '';
    state.oldGames.forEach((item, index) => {
      const card = document.createElement('article');
      card.className = 'oldgame-card';
      card.tabIndex = 0;
      card.dataset.oldgameId = item.id || '';
      card.style.animationDelay = `${Math.min(index, 12) * 18}ms`;
      const image = item.image_url
        ? `<img src="${escapeHtml(item.image_url)}" alt="" loading="lazy">`
        : '<span class="oldgame-card-placeholder"><svg><use href="assets/icons.svg#library"></use></svg></span>';
      const metadata = [item.year, item.platform].filter(Boolean);
      card.innerHTML = `
        <div class="oldgame-card-cover">${image}<span class="oldgame-card-source">MYABANDONWARE</span></div>
        <div class="oldgame-card-body">
          <div>
            <h3>${escapeHtml(item.title || tr('Stara gra'))}</h3>
            <p>${escapeHtml(metadata.join(' · ') || tr('Pełne dane po otwarciu'))}</p>
          </div>
          <div class="oldgame-card-actions">
            <span class="oldgame-card-open">${escapeHtml(tr('Szczegóły'))}<svg><use href="assets/icons.svg#external"></use></svg></span>
            <button type="button" data-oldgame-add="${escapeHtml(item.id || '')}">${escapeHtml(tr('Zobacz i pobierz'))}</button>
          </div>
        </div>`;
      grid.appendChild(card);
    });
    empty.hidden = state.oldGames.length > 0 || state.oldGamesBusy;
    document.getElementById('oldgames-result-title').textContent = oldGamesFilterTitle();
    document.getElementById('oldgames-result-count').textContent = state.oldGamesBusy
      ? tr('Wczytywanie…')
      : `${Number(state.oldGamesStatus?.result_total ?? 0).toLocaleString()} ${tr('gier')}`;
    renderOldGamesPagination();
  }

  async function loadOldGames(page = 1) {
    const sequence = ++state.oldGamesSequence;
    setOldGamesBusy(true);
    document.getElementById('oldgames-empty').hidden = true;
    document.getElementById('oldgames-result-count').textContent = tr('Wczytywanie…');
    try {
      const response = parseJson(
        await call(
          'get_old_games',
          state.oldGamesQuery,
          page,
          state.oldGamesPageSize,
          '',
          state.oldGamesSort,
          state.oldGamesImagesOnly,
          state.oldGamesGenre,
          state.oldGamesYear,
          '',
        ),
        {},
      );
      if (sequence !== state.oldGamesSequence) return;
      if (!response.success) throw new Error(response.message || tr('Nie pobrano katalogu'));
      state.oldGames = Array.isArray(response.items) ? response.items : [];
      state.oldGamesPage = Number(response.page || 1);
      state.oldGamesPages = Number(response.pages || 1);
      state.oldGamesLoaded = true;
      state.oldGamesStatus = {
        ...(response.status || {}),
        result_total: Number(response.total || 0),
      };
      populateOldGamesFilters(response.status);
      document.getElementById('oldgames-total').textContent = Number(response.status?.total || response.total || 0).toLocaleString();
      document.getElementById('oldgames-updated').textContent = formatOldGamesDate(response.status?.updated_at);
    } catch (error) {
      if (sequence !== state.oldGamesSequence) return;
      state.oldGames = [];
      state.oldGamesStatus = { result_total: 0 };
      toast('error', tr('Stare gry'), error.message || String(error));
    } finally {
      if (sequence === state.oldGamesSequence) {
        setOldGamesBusy(false);
        renderOldGames();
      }
    }
  }

  function resetOldGameMedia() {
    ['oldgame-cover', 'oldgame-main-shot'].forEach(id => {
      const image = document.getElementById(id);
      image.removeAttribute('src');
    });
    document.getElementById('oldgame-shot-strip').innerHTML = '';
  }

  function renderOldGameDetails(details) {
    state.selectedOldGame = details;
    const cover = document.getElementById('oldgame-cover');
    const main = document.getElementById('oldgame-main-shot');
    const images = [...new Set([
      ...(details.screenshots || []),
      details.image_url,
    ].filter(Boolean))];
    cover.src = details.image_url || images[0] || '';
    main.src = images[0] || details.image_url || '';
    document.getElementById('oldgame-title').textContent = details.title || tr('Stara gra');
    document.getElementById('oldgame-subtitle').textContent = [
      details.year,
      details.platform,
    ].filter(Boolean).join(' · ') || 'MyAbandonware';
    document.getElementById('oldgame-description').textContent =
      details.description || tr('Opis jest dostępny na stronie źródłowej.');
    const facts = [
      [tr('ROK'), details.year],
      [tr('PLATFORMA'), details.platform],
      [tr('KRAJ WYDANIA'), details.country],
      [tr('TWÓRCA'), details.developer],
      [tr('WYDAWCA'), details.publisher],
    ].filter(([, value]) => value);
    document.getElementById('oldgame-facts').innerHTML = facts
      .map(([label, value]) => `<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value || '—')}</dd></div>`)
      .join('');
    const tags = [details.genre, details.themes]
      .flatMap(value => String(value || '').split(/[,/]/))
      .map(value => value.trim())
      .filter(Boolean);
    document.getElementById('oldgame-tags').innerHTML = tags
      .map(value => `<span>${escapeHtml(value)}</span>`)
      .join('');
    const availableChoices = (details.downloads || []).filter(value => value?.eligible);
    const choices = availableChoices;
    const downloadBox = document.getElementById('oldgame-download-box');
    const downloadSelect = document.getElementById('oldgame-download-choice');
    const installButton = document.getElementById('oldgame-install');
    downloadSelect.innerHTML = choices.map(value => {
      const kindLabel = {
        'disc-image': tr('Obraz płyty'),
        installer: tr('Instalator'),
        portable: tr('Gotowa gra'),
      }[value.kind] || tr('Wydanie gry');
      const description = [
        kindLabel,
        value.platform,
        value.label,
      ].filter(Boolean).join(' · ');
      return `<option value="${escapeHtml(value.id || '')}" data-kind="${escapeHtml(value.kind || 'portable')}">${escapeHtml(description)}</option>`;
    }).join('');
    downloadBox.hidden = choices.length === 0;
    installButton.hidden = choices.length === 0;
    if (choices.length) {
      document.getElementById('oldgame-download-copy').textContent = tr(
        'KillzoneTools pobierze wydanie wieloczęściowo, przygotuje nośnik lub uruchomi instalator, a następnie otworzy folder gry.',
      );
    }
    const strip = document.getElementById('oldgame-shot-strip');
    strip.innerHTML = images.slice(0, 8).map((url, index) => `
      <button type="button" data-oldgame-shot="${index}" class="${index === 0 ? 'active' : ''}">
        <img src="${escapeHtml(url)}" alt="" loading="lazy">
      </button>`).join('');
    strip.hidden = images.length < 2;
    document.getElementById('oldgame-detail-hero').style.setProperty(
      '--oldgame-hero',
      details.image_url ? `url("${String(details.image_url).replace(/["\\]/g, '\\$&')}")` : 'linear-gradient(135deg,#25160d,#0a0c0f)',
    );
    const store = document.getElementById('oldgame-open-store');
    store.hidden = !details.store_url;
    document.getElementById('oldgame-detail-loading').hidden = true;
    document.getElementById('oldgame-detail').hidden = false;
    document.querySelector('.oldgame-actions').hidden = false;
  }

  async function openOldGame(item) {
    if (!item?.url) return;
    const sequence = ++state.oldGameDetailsSequence;
    state.selectedOldGame = { ...item };
    resetOldGameMedia();
    document.getElementById('oldgame-install-view').hidden = true;
    document.getElementById('oldgame-detail').hidden = true;
    document.getElementById('oldgame-detail-loading').hidden = false;
    document.querySelector('.oldgame-actions').hidden = true;
    const modal = document.getElementById('oldgame-modal');
    modal.classList.add('visible');
    modal.setAttribute('aria-hidden', 'false');
    document.getElementById('oldgame-detail').scrollTop = 0;
    try {
      const details = parseJson(
        await call('get_old_game_details', item.url, false),
        {},
      );
      if (sequence !== state.oldGameDetailsSequence) return;
      if (!details.success) throw new Error(details.message || tr('Nie pobrano szczegółów gry'));
      renderOldGameDetails(details);
    } catch (error) {
      if (sequence !== state.oldGameDetailsSequence) return;
      hideOldGame();
      toast('error', tr('Stare gry'), error.message || String(error));
    }
  }

  function hideOldGame() {
    clearTimeout(state.oldGameInstallTimer);
    state.oldGameInstallPollSequence += 1;
    state.oldGameDetailsSequence += 1;
    state.selectedOldGame = null;
    resetOldGameMedia();
    const modal = document.getElementById('oldgame-modal');
    modal.classList.remove('visible');
    modal.setAttribute('aria-hidden', 'true');
  }

  async function cancelOldGameInstall() {
    const status = state.oldGameInstallStatus || {};
    if (!['starting', 'running', 'cancelling'].includes(status.status)) return true;
    try {
      const result = parseJson(
        await call('cancel_old_game_install', status.job_id || ''),
        {},
      );
      if (!result.success && result.message !== tr('Brak aktywnego pobierania')) {
        toast('error', tr('Nie anulowano pobierania'), result.message || '');
        return false;
      }
      state.oldGameInstallStatus = {
        ...status,
        status: 'cancelling',
        stage: 'cancelling',
        cancellable: false,
        message: tr('Anulowanie pobierania…'),
      };
      renderOldGameInstallStatus(state.oldGameInstallStatus);
      return true;
    } catch (error) {
      toast('error', tr('Nie anulowano pobierania'), error.message || String(error));
      return false;
    }
  }

  async function closeOldGame() {
    const status = state.oldGameInstallStatus || {};
    const belongsToOpenGame = !status.source_url
      || status.source_url === state.selectedOldGame?.url;
    if (
      belongsToOpenGame
      && ['starting', 'running', 'cancelling'].includes(status.status)
    ) {
      if (!window.confirm(tr('Pobieranie nadal trwa. Czy chcesz je anulować?'))) return;
      if (!(await cancelOldGameInstall())) return;
    }
    hideOldGame();
  }

  function formatOldGameBytes(value) {
    const size = Number(value || 0);
    if (!size) return '';
    const units = ['B', 'KB', 'MB', 'GB'];
    let amount = size;
    let index = 0;
    while (amount >= 1024 && index < units.length - 1) {
      amount /= 1024;
      index += 1;
    }
    return `${amount.toFixed(index > 1 ? 1 : 0)} ${units[index]}`;
  }

  function renderOldGameInstallStatus(status) {
    if (!status || status.status === 'idle') return;
    state.oldGameInstallStatus = status;
    const modal = document.getElementById('oldgame-modal');
    if (
      !modal.classList.contains('visible')
      || (status.source_url && status.source_url !== state.selectedOldGame?.url)
    ) return;
    const view = document.getElementById('oldgame-install-view');
    const detail = document.getElementById('oldgame-detail');
    const title = document.getElementById('oldgame-install-title');
    const message = document.getElementById('oldgame-install-message');
    const bar = document.getElementById('oldgame-install-bar');
    const size = document.getElementById('oldgame-install-size');
    view.hidden = false;
    detail.hidden = true;
    title.textContent = status.status === 'complete'
      ? tr('Gra została zainstalowana')
      : status.status === 'error'
        ? tr('Instalacja nie powiodła się')
        : status.status === 'cancelled'
          ? tr('Pobieranie anulowane')
        : status.name || tr('Instalowanie gry');
    message.textContent = status.message || tr('Proszę czekać…');
    const percent = status.total > 0
      ? Math.max(0, Math.min(100, Number(status.percent || 0)))
      : status.status === 'complete' ? 100 : 14;
    bar.style.width = `${percent}%`;
    bar.classList.toggle('indeterminate', status.total <= 0 && status.status === 'running');
    size.textContent = status.total > 0
      ? `${formatOldGameBytes(status.current)} / ${formatOldGameBytes(status.total)}`
      : status.destination || '';
    const active = ['starting', 'running', 'cancelling'].includes(status.status);
    document.querySelector('.oldgame-actions').hidden = active;
    const cancelButton = document.getElementById('oldgame-cancel');
    cancelButton.hidden = !status.cancellable || status.status === 'cancelling';
    if (['error', 'cancelled'].includes(status.status)) {
      document.getElementById('oldgame-install').hidden = false;
    }
    document.getElementById('oldgame-add-steam').hidden = active;
  }

  async function pollOldGameInstall(sequence = state.oldGameInstallPollSequence) {
    clearTimeout(state.oldGameInstallTimer);
    try {
      const status = parseJson(await call('get_old_game_install_status'), {});
      if (sequence !== state.oldGameInstallPollSequence) return;
      renderOldGameInstallStatus(status);
      if (['starting', 'running', 'cancelling'].includes(status.status)) {
        state.oldGameInstallTimer = setTimeout(() => void pollOldGameInstall(sequence), 450);
        return;
      }
      if (status.status === 'complete' && state.oldGameInstallNotified !== 'complete') {
        state.oldGameInstallNotified = 'complete';
        toast('success', tr('Gra gotowa'), status.message || '', status.warnings || []);
      } else if (status.status === 'error' && state.oldGameInstallNotified !== 'error') {
        state.oldGameInstallNotified = 'error';
        toast('error', tr('Instalacja nie powiodła się'), status.message || '');
      } else if (status.status === 'cancelled' && state.oldGameInstallNotified !== 'cancelled') {
        state.oldGameInstallNotified = 'cancelled';
        toast('info', tr('Pobieranie anulowane'), status.message || '');
      }
    } catch (error) {
      if (sequence !== state.oldGameInstallPollSequence) return;
      state.oldGameInstallTimer = setTimeout(() => void pollOldGameInstall(sequence), 900);
    }
  }

  async function installOldGame(item = state.selectedOldGame) {
    if (!item?.url) return;
    const downloadId = document.getElementById('oldgame-download-choice').value;
    if (!downloadId) return;
    const button = document.getElementById('oldgame-install');
    button.disabled = true;
    state.oldGameInstallNotified = '';
    try {
      const result = parseJson(
        await call('start_old_game_install', item.url, downloadId),
        {},
      );
      if (!result.success) {
        if (result.message !== tr('Instalacja anulowana')) {
          toast('error', tr('Nie rozpoczęto instalacji'), result.message || '');
        }
        return;
      }
      state.oldGameInstallStatus = {
        status: 'starting',
        stage: 'starting',
        job_id: result.data?.job_id || '',
        source_url: item.url,
        name: item.title || '',
        cancellable: true,
      };
      document.getElementById('oldgame-install-view').hidden = false;
      document.getElementById('oldgame-detail').hidden = true;
      document.querySelector('.oldgame-actions').hidden = true;
      const pollSequence = ++state.oldGameInstallPollSequence;
      void pollOldGameInstall(pollSequence);
    } catch (error) {
      toast('error', tr('Nie rozpoczęto instalacji'), error.message || String(error));
    } finally {
      button.disabled = false;
    }
  }

  async function addOldGameExeToSteam(item = state.selectedOldGame) {
    if (!item?.url) return;
    const button = document.getElementById('oldgame-add-steam');
    const status = state.oldGameInstallStatus || {};
    const suggestedPath = status.source_url === item.url
      ? status.executable || status.destination || ''
      : '';
    button.disabled = true;
    try {
      const result = parseJson(
        await call('add_old_game_executable_to_steam', item.url, suggestedPath),
        {},
      );
      if (!result.success) {
        if (result.message !== tr('Nie wybrano pliku EXE')) {
          toast('error', tr('Nie dodano gry'), result.message || '');
        }
        return;
      }
      toast('success', tr('Gra dodana do Steam'), result.message || '', result.warnings || []);
    } catch (error) {
      toast('error', tr('Nie dodano gry'), error.message || String(error));
    } finally {
      button.disabled = false;
    }
  }

  async function refreshOldGamesIndex() {
    const button = document.getElementById('oldgames-refresh');
    button.disabled = true;
    button.classList.add('loading');
    try {
      const result = parseJson(await call('refresh_old_games'), {});
      if (!result.success) throw new Error(result.message || tr('Nie odświeżono indeksu'));
      toast('success', tr('Indeks odświeżony'), `${Number(result.total || 0).toLocaleString()} ${tr('gier')}`);
      await loadOldGames(1);
    } catch (error) {
      toast('error', tr('Nie odświeżono indeksu'), error.message || String(error));
    } finally {
      button.disabled = false;
      button.classList.remove('loading');
    }
  }

  function chooseOldGamesCategory(kind, value) {
    state.oldGamesGenre = kind === 'genre' ? value : '';
    state.oldGamesYear = kind === 'year' ? value : '';
    state.oldGamesQuery = '';
    document.getElementById('oldgames-search').value = '';
    document.getElementById('oldgames-genre').value = state.oldGamesGenre;
    document.getElementById('oldgames-year').value = state.oldGamesYear;
    document.getElementById('oldgames-filter-clear').disabled = !value;
    void loadOldGames(1);
  }

  function bindUi() {
    document.querySelectorAll('[data-page]').forEach(button => button.addEventListener('click', () => navigate(button.dataset.page)));
    document.querySelectorAll('[data-go]').forEach(button => button.addEventListener('click', () => navigate(button.dataset.go)));
    document.querySelectorAll('.browse-trigger').forEach(button => button.addEventListener('click', browseAndImport));
    bindTvPlayer();
    document.getElementById('tv-refresh').addEventListener('click', () => loadTvChannels(true));
    document.getElementById('tv-guide-toggle').addEventListener('click', () => {
      if (!state.tvLiveChannel) return;
      setTvGuideOpen(!state.tvGuideOpen);
      if (state.tvGuideOpen && !state.tvGuideBusy && state.tvGuideChannelId !== state.tvLiveChannel.id) {
        void loadTvGuide(state.tvLiveChannel);
      }
    });
    document.getElementById('tv-guide-close').addEventListener('click', () => setTvGuideOpen(false));
    document.getElementById('tv-player-retry').addEventListener('click', () => {
      if (state.tvSelected) selectTvChannel(state.tvSelected);
    });
    document.getElementById('tv-search').addEventListener('input', event => {
      state.tvQuery = event.target.value.trim();
      document.getElementById('tv-search-clear').hidden = !state.tvQuery;
      renderTvChannels();
    });
    document.getElementById('tv-search-clear').addEventListener('click', () => {
      const input = document.getElementById('tv-search');
      input.value = '';
      state.tvQuery = '';
      input.focus();
      document.getElementById('tv-search-clear').hidden = true;
      renderTvChannels();
    });
    document.getElementById('tv-channel-list').addEventListener('scroll', event => {
      const host = event.currentTarget;
      if (host.scrollHeight - host.scrollTop - host.clientHeight > 320) return;
      const total = filteredTvChannels().length;
      if (state.tvVisibleLimit >= total) return;
      state.tvVisibleLimit = Math.min(total, state.tvVisibleLimit + 80);
      renderTvChannels({ preserveScroll: true });
    }, { passive: true });
    document.getElementById('notification-bell').addEventListener('click', event => {
      event.stopPropagation();
      toggleWatcherNotifications();
    });
    document.getElementById('notification-panel').addEventListener('click', async event => {
      event.stopPropagation();
      const itemNode = event.target.closest('.notification-item');
      if (!itemNode) return;
      const id = itemNode.dataset.notificationId;
      if (id) {
        await call('mark_watcher_notifications_read', JSON.stringify([id]));
        const item = state.watcherNotifications.find(value => value.id === id);
        if (item) item.read = true;
        renderWatcherNotifications();
      }
      const routes = {
        onlinefix: 'onlinefix',
        workshop: 'workshop',
        update: 'mode',
        games: 'manage',
        cloud: 'cloudsaves',
      };
      const page = routes[itemNode.dataset.notificationCategory];
      if (page) navigate(page);
      toggleWatcherNotifications(false);
    });
    document.getElementById('notification-read-all').addEventListener('click', event => {
      event.stopPropagation();
      void markWatcherNotificationsRead();
    });
    document.getElementById('notification-clear').addEventListener('click', event => {
      event.stopPropagation();
      void clearWatcherNotifications();
    });
    document.getElementById('onlinefix-auto-later').addEventListener('click', closeOnlineFixAutomationOffer);
    document.getElementById('onlinefix-auto-accept').addEventListener('click', acceptOnlineFixAutomationOffer);
    document.getElementById('onlinefix-auto-modal').addEventListener('click', event => {
      if (event.target.id === 'onlinefix-auto-modal') closeOnlineFixAutomationOffer();
    });
    document.addEventListener('click', event => {
      if (!event.target.closest('#notification-center')) toggleWatcherNotifications(false);
    });
    document.getElementById('restart-steam').addEventListener('click', restartSteam);
    document.getElementById('steam-account-list').addEventListener('click', event => {
      const button = event.target.closest('[data-steam-account]');
      if (button && !button.disabled) toggleSteamAccount(button);
    });
    document.getElementById('desktop-update').addEventListener('click', () => {
      if (state.applicationUpdate?.available) openApplicationUpdateModal();
      else checkApplicationUpdate(true, true);
    });
    document.getElementById('app-update-later').addEventListener('click', () => document.getElementById('app-update-modal').classList.remove('visible'));
    document.getElementById('app-update-install').addEventListener('click', downloadAndInstallApplicationUpdate);
    document.getElementById('runtime-update-check').addEventListener('click', () => checkBackendUpdate(true));
    document.getElementById('runtime-update-install').addEventListener('click', updateBackendRuntime);
    document.getElementById('game-drawer-close').addEventListener('click', closeGameDrawer);
    document.getElementById('game-drawer-backdrop').addEventListener('click', closeGameDrawer);
    document.getElementById('storefront-close').addEventListener('click', closeStorefront);
    document.getElementById('storefront-modal').addEventListener('click', event => {
      if (event.target.id === 'storefront-modal') closeStorefront();
    });
    document.getElementById('storefront-open-steam').addEventListener('click', () => {
      if (state.selectedStorefrontApp) call('open_store_page', state.selectedStorefrontApp.app_id);
    });
    document.getElementById('storefront-add-game').addEventListener('click', async event => {
      const app = state.selectedStorefrontApp;
      if (!app || app.coming_soon) return;
      if (managedStorefrontGame(app.app_id)) {
        await updateStorefrontGame(app, event.currentTarget);
      } else if (await queueSelectedApp(app, event.currentTarget)) {
        closeStorefront();
      }
    });
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape' && document.getElementById('storefront-modal').classList.contains('visible')) {
        closeStorefront();
      }
      if (event.key === 'Escape') {
        toggleWatcherNotifications(false);
        closeOnlineFixAutomationOffer();
        if (document.getElementById('oldgame-modal').classList.contains('visible')) {
          closeOldGame();
        }
      }
    });
    document.getElementById('drawer-redownload').addEventListener('click', drawerRedownload);
    document.getElementById('drawer-store').addEventListener('click', () => state.selectedGameDetails && call('open_store_page', state.selectedGameDetails.app_id));
    document.getElementById('drawer-steam').addEventListener('click', () => state.selectedGameDetails && call('open_game_in_steam', state.selectedGameDetails.app_id));
    document.getElementById('drawer-reveal-lua').addEventListener('click', () => state.selectedGameDetails && call('reveal_game_lua', state.selectedGameDetails.app_id));
    document.getElementById('drawer-copy-id').addEventListener('click', copySelectedAppId);
    document.getElementById('drawer-game-dir').addEventListener('click', () => state.selectedGameDetails && call('reveal_game_directory', state.selectedGameDetails.app_id));
    document.getElementById('drawer-workshop').addEventListener('click', () => {
      if (!state.selectedGameDetails) return;
      state.workshopPreferredAppId = state.selectedGameDetails.app_id;
      closeGameDrawer();
      navigate('workshop');
    });
    document.getElementById('drawer-dlc-list').addEventListener('click', event => {
      const button = event.target.closest('[data-dlc-id]');
      if (button && !button.disabled) toggleDrawerDlc(button);
    });
    document.getElementById('drawer-dlc-enable-all').addEventListener('click', enableAllDrawerDlc);
    document.getElementById('drawer-cloud-toggle').addEventListener('click', drawerToggleCloudRedirect);
    document.getElementById('drawer-delete').addEventListener('click', () => { if (state.selectedGameDetails) { const game = state.selectedGameDetails; closeGameDrawer(); requestRemoval(game); } });
    document.getElementById('drawer-lc-fix').addEventListener('click', drawerToggleLcFix);
    document.getElementById('drawer-remote-download').addEventListener('click', drawerDownloadRemoteFix);
    document.getElementById('drawer-fix-install').addEventListener('click', drawerInstallArchive);
    document.getElementById('refresh').addEventListener('click', refreshAll);
    document.getElementById('manage-refresh').addEventListener('click', loadGames);
    document.getElementById('library-search').addEventListener('input', renderGames);
    document.getElementById('library-filter').addEventListener('change', renderGames);
    const oldGamesSearch = document.getElementById('oldgames-search');
    oldGamesSearch.addEventListener('input', event => {
      clearTimeout(state.oldGamesSearchTimer);
      state.oldGamesGenre = '';
      state.oldGamesYear = '';
      ['oldgames-genre', 'oldgames-year'].forEach(id => {
        document.getElementById(id).value = '';
      });
      document.getElementById('oldgames-filter-clear').disabled = true;
      state.oldGamesQuery = event.target.value.trim();
      state.oldGamesSearchTimer = setTimeout(() => void loadOldGames(1), 180);
    });
    document.getElementById('oldgames-search-clear').addEventListener('click', () => {
      oldGamesSearch.value = '';
      state.oldGamesQuery = '';
      oldGamesSearch.focus();
      void loadOldGames(1);
    });
    document.getElementById('oldgames-sort').addEventListener('change', event => {
      state.oldGamesSort = event.target.value || 'top_downloads';
      void loadOldGames(1);
    });
    document.getElementById('oldgames-images-only').addEventListener('change', event => {
      state.oldGamesImagesOnly = Boolean(event.target.checked);
      void loadOldGames(1);
    });
    document.getElementById('oldgames-genre').addEventListener('change', event => chooseOldGamesCategory('genre', event.target.value));
    document.getElementById('oldgames-year').addEventListener('change', event => chooseOldGamesCategory('year', event.target.value));
    document.getElementById('oldgames-filter-clear').addEventListener('click', () => chooseOldGamesCategory('', ''));
    document.getElementById('oldgames-refresh').addEventListener('click', refreshOldGamesIndex);
    document.getElementById('oldgames-grid').addEventListener('click', event => {
      const card = event.target.closest('.oldgame-card');
      if (!card) return;
      const item = state.oldGames.find(value => String(value.id) === card.dataset.oldgameId);
      void openOldGame(item);
    });
    document.getElementById('oldgames-grid').addEventListener('keydown', event => {
      if (!['Enter', ' '].includes(event.key)) return;
      const card = event.target.closest('.oldgame-card');
      if (!card) return;
      event.preventDefault();
      void openOldGame(state.oldGames.find(value => String(value.id) === card.dataset.oldgameId));
    });
    document.getElementById('oldgames-pagination').addEventListener('click', event => {
      const button = event.target.closest('[data-oldgames-page]');
      if (!button || button.disabled) return;
      void loadOldGames(Number(button.dataset.oldgamesPage || 1));
      document.getElementById('page-oldgames').scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    document.getElementById('oldgame-close').addEventListener('click', () => void closeOldGame());
    document.getElementById('oldgame-modal').addEventListener('click', event => {
      if (event.target.id === 'oldgame-modal') void closeOldGame();
    });
    document.getElementById('oldgame-shot-strip').addEventListener('click', event => {
      const button = event.target.closest('[data-oldgame-shot]');
      if (!button) return;
      const image = button.querySelector('img');
      if (image?.src) document.getElementById('oldgame-main-shot').src = image.src;
      button.parentElement.querySelectorAll('button').forEach(candidate => candidate.classList.toggle('active', candidate === button));
    });
    document.getElementById('oldgame-open-source').addEventListener('click', () => {
      if (state.selectedOldGame?.url) void call('open_old_game_page', state.selectedOldGame.url);
    });
    document.getElementById('oldgame-open-store').addEventListener('click', () => {
      if (state.selectedOldGame?.store_url) void call('open_old_game_store', state.selectedOldGame.store_url);
    });
    document.getElementById('oldgame-install').addEventListener('click', () => void installOldGame());
    document.getElementById('oldgame-add-steam').addEventListener('click', () => void addOldGameExeToSteam());
    document.getElementById('oldgame-cancel').addEventListener('click', () => void cancelOldGameInstall());
    const appSearch = document.getElementById('app-search');
    appSearch.addEventListener('input', handleCatalogInput);
    document.querySelector('.catalog-filter-panel').addEventListener('click', event => {
      const button = event.target.closest('[data-catalog-filter]');
      if (!button) return;
      const filter = button.dataset.catalogFilter;
      if (state.catalogFilters.has(filter)) state.catalogFilters.delete(filter);
      else state.catalogFilters.add(filter);
      state.discoverySection = 'browse';
      renderCatalogFilterState();
      void loadCatalogDiscovery('browse', 1);
    });
    document.getElementById('catalog-filter-clear').addEventListener('click', () => {
      state.catalogFilters.clear();
      state.discoverySection = 'browse';
      renderCatalogFilterState();
      void loadCatalogDiscovery('browse', 1);
    });
    document.getElementById('catalog-sort').addEventListener('change', event => {
      state.catalogSort = event.target.value || 'relevance';
      void loadCatalogDiscovery(state.catalogFilters.size ? 'browse' : state.discoverySection, 1);
    });
    appSearch.addEventListener('keydown', event => {
      if (event.key === 'Enter') {
        event.preventDefault();
        clearTimeout(state.catalogLocalSearchTimer);
        clearTimeout(state.catalogSearchTimer);
        const query = appSearch.value.trim();
        if (state.catalogFilters.size) loadCatalogDiscovery('browse', 1);
        else if (query) {
          const sequence = ++state.catalogSearchSequence;
          searchCatalog(query, sequence);
        }
        else loadCatalogSuggestions();
      } else if (event.key === 'Escape') {
        appSearch.value = '';
        handleCatalogInput();
      }
    });
    document.getElementById('app-search-button').addEventListener('click', () => {
      appSearch.value = '';
      appSearch.focus();
      handleCatalogInput();
    });
    document.getElementById('queue-refresh').addEventListener('click', loadInstallQueue);
    document.getElementById('steam-insights-refresh').addEventListener('click', () => loadCatalogInsights(true));
    document.getElementById('onlinefix-game').addEventListener('change', updateOnlineFixSelection);
    document.getElementById('onlinefix-toggle').addEventListener('click', toggleOnlineFix);
    document.getElementById('onlinefix-page').addEventListener('click', openOnlineFixPage);
    document.getElementById('onlinefix-remote').addEventListener('click', downloadOnlineFixFromPage);
    document.getElementById('onlinefix-archive').addEventListener('click', selectOnlineFixArchiveFromPage);
    document.getElementById('onlinefix-fix-install').addEventListener('click', installOnlineFixFromPage);
    document.getElementById('workshop-game').addEventListener('change', updateWorkshopSelection);
    document.getElementById('workshop-prepare').addEventListener('click', prepareWorkshop);
    document.getElementById('workshop-open-page').addEventListener('click', () => {
      const appId = document.getElementById('workshop-game').value;
      if (appId) call('open_workshop_page', appId);
    });
    document.getElementById('workshop-refresh').addEventListener('click', updateWorkshopSelection);
    document.getElementById('diagnostics-refresh').addEventListener('click', loadDiagnostics);
    document.getElementById('repair-directories').addEventListener('click', () => runRepair('repair_runtime_directories', 'Katalogi runtime'));
    document.getElementById('repair-legacy').addEventListener('click', () => runRepair('repair_legacy_lua_integration', 'Integracja LuaTools'));
    document.getElementById('repair-open-logs').addEventListener('click', () => call('open_opensteam_logs'));
    document.getElementById('repair-support-bundle').addEventListener('click', createSupportBundle);
    document.getElementById('recovery-export').addEventListener('click', () => runRecovery('export_library_recovery', 'Kopia biblioteki', 'Zapisywanie…'));
    document.getElementById('recovery-import').addEventListener('click', () => runRecovery('import_library_recovery', 'Przywracanie biblioteki', 'Wybieranie…'));
    document.getElementById('image-cache-clear').addEventListener('click', clearImageCache);
    document.getElementById('plugin-open-config').addEventListener('click', () => call('open_opensteam_config'));
    document.getElementById('plugin-open-logs').addEventListener('click', () => call('open_opensteam_logs'));
    document.getElementById('plugin-repair-legacy').addEventListener('click', () => runRepair('repair_legacy_lua_integration', 'Integracja LuaTools'));
    document.getElementById('hubcap-connect').addEventListener('click', connectHubcap);
    document.getElementById('hubcap-disconnect').addEventListener('click', disconnectHubcap);
    document.getElementById('google-drive-connect').addEventListener('click', connectGoogleDrive);
    document.getElementById('google-drive-disconnect').addEventListener('click', disconnectGoogleDrive);
    document.getElementById('library-profile-sync').addEventListener('click', () => syncLibraryProfile(false));
    document.getElementById('library-profile-later').addEventListener('click', () => document.getElementById('library-profile-modal').classList.remove('visible'));
    document.getElementById('library-profile-restore').addEventListener('click', restoreLibraryProfile);
    document.getElementById('cloud-use-local').addEventListener('click', useLocalCloudStorage);
    document.getElementById('cloud-save-refresh').addEventListener('click', loadCloudSaveOverview);
    document.getElementById('cloud-quota-manage').addEventListener('click', async () => {
      const result = parseJson(await call('open_google_storage'));
      if (!result.success) toast('error', 'Google Drive', result.message);
    });
    document.getElementById('cloud-save-migrate').addEventListener('click', () => migrateCloudSaves(false));
    document.getElementById('cloud-save-export').addEventListener('click', () => runCloudArchive('export_local_cloud_saves', 'Eksport zapisów', 'Tworzenie ZIP…'));
    document.getElementById('cloud-save-import').addEventListener('click', () => runCloudArchive('import_local_cloud_saves', 'Przywracanie zapisów', 'Wybieranie ZIP…'));
    document.getElementById('limits-refresh').addEventListener('click', loadProviderLimits);
    document.getElementById('license-gate-activate').addEventListener('click', () => activateLicense('license-gate-key', 'license-gate-activate'));
    document.getElementById('license-page-activate').addEventListener('click', () => activateLicense('license-page-key', 'license-page-activate'));
    document.getElementById('license-deactivate').addEventListener('click', deactivateLicense);
    document.getElementById('license-copy-installation').addEventListener('click', () => copyText(state.license?.installation_id, 'ID instalacji skopiowane'));
    document.getElementById('license-gate-copy').addEventListener('click', () => copyText(state.license?.installation_id, 'ID instalacji skopiowane'));
    document.getElementById('license-gate-key').addEventListener('keydown', event => {
      if (event.key === 'Enter' && (event.ctrlKey || event.metaKey)) activateLicense('license-gate-key', 'license-gate-activate');
    });
    document.getElementById('confirm-cancel').addEventListener('click', () => {
      state.pendingRemoval = null;
      document.getElementById('confirm-modal').classList.remove('visible');
    });
    document.getElementById('confirm-remove').addEventListener('click', () => { if (state.pendingRemoval) performRemoval(state.pendingRemoval); });
    document.getElementById('fix-location-auto').addEventListener('click', () => chooseFixLocation(true));
    document.getElementById('fix-location-manual').addEventListener('click', () => chooseFixLocation(false));
    document.getElementById('fix-location-cancel').addEventListener('click', closeFixLocationChoice);
    document.querySelectorAll('[data-setting]').forEach(control => control.addEventListener('change', () => saveSetting(control)));
  }

  function connect() {
    async function ready() {
      state.bridge = window.pywebview.api;
      bindUi();
      try {
        await loadSettings(false);
        const license = await loadLicenseStatus(false);
        await checkApplicationUpdate(false, false);
        if (license.valid) await initializeApplication();
      } catch (error) {
        toast('error', 'Błąd połączenia z backendem', error.message || String(error));
      }
    }
    if (window.pywebview && window.pywebview.api) ready();
    else window.addEventListener('pywebviewready', ready, { once: true });
  }

  document.addEventListener('DOMContentLoaded', connect);
})();

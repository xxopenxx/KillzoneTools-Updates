KillzoneTools is licensed under the GNU General Public License, version 3 or
any later version (GPL-3.0-or-later).

The complete license text is available at:
https://www.gnu.org/licenses/gpl-3.0.txt

Copyright (c) 2026 KillzoneTools contributors.
